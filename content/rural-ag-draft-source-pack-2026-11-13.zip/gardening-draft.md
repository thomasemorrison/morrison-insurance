# Backyard gardening captions — November 13–15, 2026

**Draft only.** For a Center/Shelby County, Texas backyard-garden audience served by Boles Feed; suitable for community-draft or Boles review. No posting, scheduling, or contact performed.

## Facebook caption

For Center and Shelby County gardeners, a useful November 13–15 weekend project is planning a soil test before the next planting. Texas A&M AgriLife says soil can be tested any time of year and recommends testing before buying or using fertilizer. A test can show nutrient levels and pH, helping you make decisions for your own garden rather than guessing. Follow the testing lab’s current sampling instructions before collecting soil, and keep the results with your garden notes. This is garden preparation—not a blanket recommendation to plant cool-season vegetables this weekend.

What are you hoping to grow next?

#ShelbyCountyTX #EastTexasGardening #SoilTesting

**Caption source:** Soil-test timing, nutrient and pH information, and following the lab’s sampling directions are supported by Texas A&M AgriLife’s [soil-testing guidance][1].

## Instagram caption

A simple November weekend garden project for Center and Shelby County: plan a soil test before buying fertilizer. Texas A&M AgriLife says testing can be done any time of year and helps identify nutrient levels and pH. Follow the lab’s sampling instructions before collecting soil. This is preparation for your next planting, not a recommendation to plant every cool-season crop now.

What are you hoping to grow next?

#ShelbyCountyTX #EastTexasGardening #SoilTesting

**Caption source:** Soil-test timing, nutrient and pH information, and following the lab’s sampling directions are supported by Texas A&M AgriLife’s [soil-testing guidance][1].

## Source caveat

A current crop-specific Center/Shelby County planting window for November 13–15, 2026 was not verified. AgriLife’s statewide fall vegetable guide supplies regional average planting dates; those are not a verified local recommendation for this particular weekend.[2] These captions therefore use the supported soil-testing/preparation alternative. They make no claim about local frost dates, current weather, soil zone, seedling availability, or Boles inventory. The soil-testing source is general guidance published March 27, 2025, not a local November 2026 bulletin.

## Rights-cleared photo direction

Use an original, permission-cleared photograph of a backyard garden bed with a plain notebook and clean hand trowel nearby, photographed in natural light. Keep the scene about garden planning, without identifiable people, brands, visible addresses, or staged seedling stock. Confirm the photographer grants permission for Facebook and Instagram use, including business/community-page use. Do not copy AgriLife article photos or assume attribution alone grants permission. No photo has been acquired or cleared as part of this draft.

## References

[1]: https://agrilifetoday.tamu.edu/2025/03/27/boost-plant-growth-with-a-simple-soil-test/ "Texas A&M AgriLife Today — Boost plant growth with a simple soil test"
[2]: https://agrilifeextension.tamu.edu/browse/featured-solutions/gardening-landscaping/fall-vegetable-gardening-guide-for-texas/ "Texas A&M AgriLife Extension — Fall Vegetable Gardening Guide for Texas"
