# Morrison Insurance measurement reference — November 13, 2026

**Primary outcome:** count genuine, deduplicated inquiries originating from https://morrison-ins.net, with qualified local inquiries reported separately. This is a proposed measurement specification, not authorization to implement tracking or change accounts.

## Count inquiries, not interaction totals

A genuine inquiry is an actual insurance request received by Morrison, excluding spam, tests, vendors and employment messages. For growth reporting, separate new-business requests from existing-customer service. A qualified local inquiry additionally has a documented Center/Shelby County location or insured risk and an insurance need Morrison can serve; browser geolocation alone does not establish qualification.

Deduplicate privately in HubSpot or an approved inquiry register: one contact plus the same insurance need is one inquiry, dated to first receipt. Merge repeated submissions and form-plus-phone follow-ups; count a distinct new request separately. Retain deduplication across reporting windows. Record website origin as confirmed, reported or unknown; never infer it from a nearby phone click. Google's `generate_lead` and `qualify_lead` represent lead generation and qualification, respectively—not automatic quality checks. [1]

Suggested event names and meanings are:

- `phone_click`: activation of the website's telephone link; not a connected call or inquiry.
- `directions_click`: activation of its directions/map link; not a visit or inquiry.
- `form_submission_success`: a HubSpot-accepted, persisted website submission; not necessarily genuine or qualified.
- `generate_lead`: one verified genuine inquiry, if subsequently authorized for measurement.
- `qualify_lead`: documented qualification of that inquiry, not another inquiry to add to the total.

These lowercase names follow Google's letter/number/underscore naming rules. [2] Deduplicate success signals for the same submission; a callback and redirect must not create two successes. GA4's once-per-event and once-per-session counting methods do not deduplicate people or requests across sessions. [3]

HubSpot legacy forms emit `onFormSubmitted` after persistence; `onFormSubmit` occurs before persistence. Google's automatic `form_submit` describes submission interaction, so do not assume it proves HubSpot acceptance. [4] [5] Neither a submit-button click nor an ordinary `/thank-you` pageview proves successful submission.

For a form created in HubSpot's updated editor, the documented global success event is instead `hs-form-event:on-submission:success`. Confirm the current embed/editor before selecting a mechanism; do not apply a legacy callback to a newer form. A successful submission remains distinct from staff-confirmed qualification. Listen only for needed success information and never forward the form's fields or entire event payload to Analytics. This is specification only, not an implemented listener. [10]

**October 26 historical risk:** the supplied history records no site callback/redirect, a GTM Google Ads conversion dependent on `/thank-you`, and a saved HubSpot redirect not verified. This is an unresolved measurement dependency, not a proven failure. Current capture and redirect behavior remain unverified; label affected counts accordingly rather than treating missing events as zero inquiries.

## Protect privacy and attribution

Keep names, emails, personal phone numbers, addresses, policy details, free-text messages and contact/deduplication identifiers out of GA4—including event parameters, URLs, titles and UTMs. Never forward HubSpot's complete callback payload. Proposed parameters should be controlled, nonpersonal labels such as `form_type`, `contact_method` and `page_group`. Google's policy prohibits personally identifiable information. [6]

For future authorized external links, use consistent `utm_source`, `utm_medium` and `utm_campaign` labels. Compare session-scoped source/medium and landing pages consistently; do not mix first-user acquisition with session acquisition. UTMs identify tagged campaigns, not an organic search query. [7] Report GA4 Google-organic inquiry signals alongside GSC clicks, impressions and queries, not as query-level lead attribution: GSC query reports cannot be broken down by GA4 dimensions, and some queries are omitted. Clicks and sessions are different measures. [8] [9]

## Compare matching 28-day windows

Use one common finalized end date: the latest 28 complete days versus the immediately preceding 28, with identical filters and definitions. Allow for Google's documented 48-hour Search Console integration lag; disclose GSC's Pacific Time versus the GA4 property's actual timezone. [8] [9] Overlapping weekly rolling windows are not independent tests.

Show counts, absolute changes and denominators. Report submission-session rate as sessions with at least one verified success divided by eligible measured sessions; keep CRM inquiry totals separate. For a zero baseline, percentage change is undefined. With fewer than ten baseline inquiries, prioritize absolute counts and flag percentages as unstable; this is a reporting convention, not a significance threshold. Annotate tracking gaps and compare only consistently measured periods. Observed change alone does not prove a website edit caused it or guarantee growth.

## References

[1]: https://developers.google.com/analytics/devguides/collection/ga4/reference/events "GA4 recommended lead events"
[2]: https://support.google.com/analytics/answer/13316687?hl=en "GA4 event naming rules"
[3]: https://support.google.com/analytics/answer/13366706?hl=en "GA4 key-event counting methods"
[4]: https://developers.hubspot.com/docs/cms/start-building/features/forms/legacy-forms "HubSpot legacy form callbacks and persistence"
[5]: https://support.google.com/analytics/answer/9216061?hl=en "GA4 enhanced measurement events"
[6]: https://support.google.com/analytics/answer/6366371?hl=en "GA4 privacy rules"
[7]: https://support.google.com/analytics/answer/11242870?hl=en "GA4 traffic attribution"
[8]: https://support.google.com/analytics/answer/10737381?hl=en "GA4 Search Console integration limitations"
[9]: https://support.google.com/webmasters/answer/17011259?hl=en "Search Console query limitations and timezones"
[10]: https://developers.hubspot.com/docs/api-reference/latest/marketing/forms/global-form-events "HubSpot updated-editor global form events"
