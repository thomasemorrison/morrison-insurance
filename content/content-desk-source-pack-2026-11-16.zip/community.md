# Two community topics for November 16–22, 2026

## 1. Community Thanksgiving Gathering — Friday, November 20

A Call To Help Ministry is hosting its Community Thanksgiving Gathering **Friday, November 20, 2026, from 5–7 p.m.**, at **The Burning Bush Venue, 1229 Southview Circle, Center, Texas 75935**. These are local event times in Center, CST. Shelby County Today published the notice November 9, 2026, submitted by Connie Buckley, and calls it the third annual gathering. The venue-affiliated Burning Bush Podcast account published a direct invitation November 3, 2026, confirming the same date, time and street address. Its invitation says “All are welcome” and “Everyone is welcome at the table.” This event occurs inside the Nov. 16–22 week, not on Thanksgiving Day or Nov. 28. [1] [2]

**Access and accuracy limits:** An all-welcome food and fellowship gathering is explicitly supported. Neither readable announcement states an admission fee, RSVP or registration requirement, residency limit, age limit, transportation provision, delivery/takeout option, menu or accessibility accommodations. Do not turn silence into “free,” “no registration required,” “no questions asked,” or a promised service. Avoid an annual-edition claim in the captions; the useful details are the date, time, location and open invitation. [1] [2]

### Facebook draft

There’s a community invitation to share in Center this week. A Call To Help Ministry is hosting its Community Thanksgiving Gathering on Friday, November 20, 2026, from 5–7 p.m. at The Burning Bush Venue, 1229 Southview Circle.

The hosts welcome everyone for food and fellowship, and their invitation encourages neighbors to bring a friend. If you’re making plans with family or passing along a local gathering to someone you know, keep the date and address handy.

Thank you to the people making time to bring our community together before Thanksgiving. We’re glad to share the invitation with our Shelby County neighbors. See the organizer’s announcement for the event details.

### Instagram draft

A Thanksgiving gathering to put on your local calendar: A Call To Help Ministry welcomes everyone on Friday, November 20, 2026, from 5–7 p.m. at The Burning Bush Venue, 1229 Southview Circle in Center.

The invitation is for food, fellowship and an evening together, and the hosts encourage bringing a friend. Share the details with a Shelby County neighbor who might enjoy going. Thank you to the hosts for welcoming our community.

### Local photo direction and rights gate

Use a real, agency-owned photograph of the Burning Bush Venue exterior with its recognizable sign, or an existing organizer-owned image of an actual table setup there. Keep the image welcoming and practical. Do not use a stock banquet, generic church interior, invented Thanksgiving crowd or AI-generated local venue. Do not imply a photograph depicts the Nov. 20, 2026 gathering before it happens; identify a prior-event image if one is approved.

**Image gate: not cleared.** No image was downloaded or licensed in this task. A public post or newspaper photo is not a reuse license. Before any use, the parent needs an existing agency-owned image with recorded usage rights, or documented permission covering Morrison's Facebook and Instagram use of an organizer's photograph or flyer. A request to share an organizer's Facebook post does not establish rights to download its image for a new cross-platform branded post. Do not feature identifiable diners, especially children or people receiving assistance, without appropriate consent; an exterior or empty-table image avoids that issue. Hold image-dependent publication until ownership, permission and any required credit are documented. No outreach was performed.

## 2. Free adult Crafternoons — Wednesday, November 18

The Fannie Brown Booth Memorial Library's own dated event page lists **Crafternoons on Wednesday, November 18, 2026, starting at 1 p.m. CST**, in the **Library Redditt Room, 619 Tenaha Street, Center, Texas 75935**. It describes an adult afternoon session featuring various crafts, painting and junk journals. The primary source explicitly states **“Free. Supplies are provided.”** The listed contact is Sandra Davis, **936-598-5522**. The library homepage also lists the Nov. 18 occurrence at 1 p.m. [3] [4]

**Access and accuracy limits:** This is an adult program, not a children's class. The page does not give a numerical age threshold, registration requirement, class size, accessibility details or the specific project planned for Nov. 18. Its human-readable event information gives only the start time. An internal timestamp runs to 23:59:59; that is not a credible class end time and must not appear in copy. Do not invent an ending, promise a particular holiday craft, or advertise “drop-in/no registration” without further organizer evidence. The contact number is suitable for readers' participation questions; this task did not contact the library. No holiday closure is asserted. [3]

### Facebook draft

A little time to make something can be a welcome break in a busy week. The Fannie Brown Booth Memorial Library has adult Crafternoons listed for Wednesday, November 18, 2026, starting at 1 p.m. in the Redditt Room at 619 Tenaha Street in Center.

The library describes the program as an afternoon of crafts, painting, junk journals and other projects. It’s free, and supplies are provided. The listing doesn’t name this week’s particular project, so keep an open mind about what’s on the craft table.

For questions about participating, call the library at 936-598-5522. We’re thankful for local places where our Shelby County neighbors can spend time learning and creating together.

### Instagram draft

Looking for a creative break in Center? The Fannie Brown Booth Memorial Library lists adult Crafternoons for Wednesday, November 18, 2026, starting at 1 p.m. in the Redditt Room, 619 Tenaha Street.

The program is free, and supplies are provided. The library describes activities such as crafts, painting and junk journals; the specific Nov. 18 project isn’t listed. Call 936-598-5522 with participation questions. Thank you to our library for offering a place to create together.

### Local photo direction and rights gate

Use a real, agency-owned exterior photograph of Fannie Brown Booth Memorial Library showing its name, or a previously approved library photograph of adult hands and craft materials in the Redditt Room. Prefer an unoccupied craft table or library exterior over recognizable patrons. Do not substitute a stock library or stage an AI-generated classroom as a real Center program. If using an earlier session's image, label it as a prior program rather than Nov. 18 coverage.

**Image gate: not cleared.** No image was downloaded or licensed in this task. Parent must document agency ownership or permission from the library/photographer for Morrison's Facebook and Instagram use, include required credit, and confirm consent for recognizable participants. The library's website images are not automatically reusable. Do not use copyrighted book cover art as the main visual unless the necessary rights are established. Hold image-dependent publication until those checks pass. No outreach was performed.

## Desk handoff

Both selected topics have current, explicitly dated events within Nov. 16–22, 2026. The Thanksgiving gathering has a readable venue-affiliated primary post plus the organizer-submitted SCTTX announcement; Crafternoons has a dated primary library listing. Facts were checked through search and fetch only on November 16, 2026, approximately 6:34–6:35 a.m. CST. These are drafts, not approved posts. No social posting dates or times were selected, and no Metricool activity, account change, email, outreach, publication or scheduling occurred. Parent retains approval, image-rights, current capacity and provider checks.

The paid SCOM Thanksgiving plate fundraiser was not selected: its Nov. 15 order deadline had already passed, and the notice did not establish walk-in or late-order access. The library's preschool listing was not selected because its age and end-time descriptions conflict across primary pages. No excluded athletics, awards, past Veterans Day/book-sale/blood-drive/theatre item, burn-ban lifting, politics, customer mention, sales pitch or fear framing appears in the drafts. No Nov. 28 reminder was needed because two in-week topics were verified.

## References

[1]: https://scttx.com/articles/call-help-ministry-hosting-community-thanksgiving-gathering "Shelby County Today: A Call to Help Ministry Hosting Community Thanksgiving Gathering, submitted by Connie Buckley, November 9, 2026"
[2]: https://www.facebook.com/61567687445413/posts/-a-community-thanksgiving-all-are-welcome-join-a-call-to-help-ministry-at-the-bu/122211539264589581/ "The Burning Bush Podcast: venue-affiliated Community Thanksgiving invitation, November 3, 2026"
[3]: https://www.centerlibrary.org/crafternoons/2026-11-18 "Fannie Brown Booth Memorial Library: dated Crafternoons event, November 18, 2026"
[4]: https://www.centerlibrary.org/ "Fannie Brown Booth Memorial Library: location and November 2026 upcoming events"
