#!/usr/bin/env python3
"""Render two self-contained HTML checklist articles locally at 1080 × 1350.

Requires Python Playwright, Pillow, and /usr/bin/chromium. No network access,
external assets, uploading, or scheduling is used. Fit adjustments affect only
normal-flow padding; no text or image is resized, clipped, or composited.
"""
import json
from pathlib import Path
from PIL import Image
from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parent
HTML = ROOT / 'checklist-cards.html'
CARD_IDS = ('feed-checklist', 'garden-checklist')
CSS_WIDTH = 540
CSS_TARGET_HEIGHT = 675
MARKER_START = '<!-- RENDER-FIT START -->'
MARKER_END = '<!-- RENDER-FIT END -->'


def main():
    report = {}
    text = HTML.read_text(encoding='utf-8')
    if MARKER_START in text:
        before, rest = text.split(MARKER_START, 1)
        _, after = rest.split(MARKER_END, 1)
        text = before + after
        HTML.write_text(text, encoding='utf-8')
    with sync_playwright() as p:
        browser = p.chromium.launch(executable_path='/usr/bin/chromium', headless=True,
                                    args=['--no-sandbox'])
        page = browser.new_page(viewport={'width': CSS_WIDTH, 'height': 900},
                                device_scale_factor=2)
        page.route('http://**/*', lambda route: route.abort())
        page.route('https://**/*', lambda route: route.abort())
        page.goto(HTML.as_uri(), wait_until='load')
        page.evaluate('document.fonts.ready')
        # Six row paddings distribute space naturally. The bottom padding then
        # absorbs Chromium's fractional layout rounding, rather than cropping.
        css_rules = []
        for card_id in CARD_IDS:
            card = page.locator(f'#{card_id}')
            height = card.bounding_box()['height']
            padding = page.evaluate('''id => {
                const li = document.querySelector('#' + id + ' li');
                return parseFloat(getComputedStyle(li).paddingTop);
            }''', card_id)
            fitted = padding + (CSS_TARGET_HEIGHT - height) / 6
            if fitted < 12:
                raise RuntimeError(f'{card_id}: insufficient content space')
            provisional = f'#{card_id} {{ --row-padding: {fitted:.8f}px; }}'
            page.add_style_tag(content=provisional)
            corrected_bottom = 27 + CSS_TARGET_HEIGHT - card.bounding_box()['height']
            rule = f'#{card_id} {{ --row-padding: {fitted:.8f}px; padding-bottom: {corrected_bottom:.8f}px; }}'
            page.add_style_tag(content=rule)
            css_rules.append(rule)
        fit_block = '\n' + MARKER_START + '\n<style>\n' + '\n'.join(css_rules) + '\n</style>\n' + MARKER_END + '\n'
        HTML.write_text(text.replace('</head>', fit_block + '</head>'), encoding='utf-8')
        page.reload(wait_until='load')
        page.evaluate('document.fonts.ready')
        for card_id in CARD_IDS:
            card = page.locator(f'#{card_id}')
            bounds = card.bounding_box()
            png = ROOT / f'{card_id}.png'
            jpg = ROOT / f'{card_id}.jpg'
            card.screenshot(path=str(png), animations='disabled')
            with Image.open(png) as image:
                if image.size != (1080, 1350):
                    raise RuntimeError(f'{card_id}: unexpected output dimensions {image.size}')
                image.convert('RGB').save(jpg, quality=95, subsampling=0, optimize=True,
                                          dpi=(144, 144))
            report[card_id] = {'css_bounds': bounds, 'pixels': [1080, 1350],
                               'png': str(png), 'jpeg': str(jpg),
                               'text': card.inner_text()}
        browser.close()
    (ROOT / 'render-verification.json').write_text(json.dumps(report, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')
    print(json.dumps(report, indent=2, ensure_ascii=False))


if __name__ == '__main__':
    main()
