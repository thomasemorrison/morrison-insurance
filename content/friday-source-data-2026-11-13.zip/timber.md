# East Texas Timber Price Trends — verification for 2026-11-13

**Status: No new report verified.** As of November 13, 2026, Texas A&M Forest Service’s official Timber Price Trends index lists **July–August 2026** as the newest 2026 bi-monthly East Texas issue. It does **not** list a September–October 2026 issue or any later 2026 issue. The official Timber archive and Data and Tools archive likewise show no September–October 2026 or later Timber Price Trends release.

The likely official URL for a September–October 2026 issue, `https://tfsweb.tamu.edu/elibrary-item/texas-timber-price-trends-september-october-2026/`, returned no extractable page/content. Public search found no official Texas A&M release for September–October 2026 or November–December 2026. Therefore, the saved July–August 2026 PDF/link remains the latest verified issue; the previously noted PDF URL 404 is not evidence of a newer report.

**Do not use fresh weekly-post values from a newer period:** no newer report values were verified, so no values are included here. Do not substitute older July–August values or paid TimberMart figures for a current September–October/later report.

## Verified definitions and units

Texas A&M says its published figures are **average stumpage prices** calculated from actual timber sales reported by up to 60 cooperators active in the East Texas market. Values are **volume-weighted averages**—the average price paid per unit of wood, not the average price per timber sale. The FAQ defines stumpage price as the price a buyer offers a landowner for the right to harvest standing trees; delivered price is the mill-gate value including stumpage, cut-and-haul, other operating expenses, and any supplier profit. The report collects price and volume data on a bimonthly survey form from forest-product companies, logging contractors, consulting foresters, federal forestry agencies, occasional non-industrial landowners, and financial institutions. No new report was available to verify current species/product units or values.

## Sources

[1]: https://tfsweb.tamu.edu/forest-land/forest-industry-economics/timber-price-trends/ "Texas A&M Forest Service Timber Price Trends index"
[2]: https://tfsweb.tamu.edu/elibrary-item/texas-timber-price-trends-july-august-2026/ "Texas Timber Price Trends July–August 2026"
[3]: https://tfsweb.tamu.edu/elibrary-item/texas-timber-price-trends-september-october-2026/ "Suspected Texas Timber Price Trends September–October 2026 URL"
[4]: https://tfsweb.tamu.edu/topics/timber/ "Texas A&M Forest Service Timber archive"
[5]: https://tfsweb.tamu.edu/topics/data-tools/ "Texas A&M Forest Service Data and Tools archive"
[6]: https://tfsweb.tamu.edu/forest-land/forest-industry-economics/timber-price-trends/timber-price-trends-frequently-asked-questions/ "Texas A&M Forest Service Timber Price Trends FAQ"
