# Friday cattle source findings — November 13, 2026

At approximately 6:33 AM CST, USDA's current PDF at https://www.ams.usda.gov/mnreports/ams_1955.pdf returned the Texas Weekly Cattle Auction Summary published **Friday November 6, 2026**, covering **November 1–7, 2026**. A direct request also retrieved the same PDF and its text was saved. This is newer than the October 30 report used last Friday, but it is not a November 13 release or November 8–14 market summary. No newer USDA Texas summary was verified in this early check.

The report's narrative says feeder steers and heifers were **mostly $4–$10 lower** against its previous week, with a few exceptions of weaned stocker heifers trading steady to $5 higher in places. Do not convert that to a claim that every class or Shelby County price fell.

Selected exact unmarked rows: **FEEDER CATTLE / Medium and Large 1 / Per Cwt / Actual Wt**:

- Steers, **500–545 lb**, **$350.00–$430.00/cwt**, page 1, 166 head.
- Heifers, **500–541 lb**, **$320.00–$376.00/cwt**, page 3, 58 head.
- Steers, **600–648 lb**, **$325.00–$387.50/cwt**, page 1, 228 head.

Do not merge Fancy, Unweaned, Full or Replacement rows. No new average calculated. Texas-wide reported auction ranges, not a Shelby County offer. All public copy must say **market snapshot—not a quote** and preserve actual weight bands.

The MMN latest-release landing page https://mymarketnews.ams.usda.gov/viewReport/1955 still labelled October 25–31, published October 30, at this check. That listing does not override the dated official current PDF's November 6 report header. Do not combine the older listing's dates/narrative with the newer PDF's numbers. Recheck both before any eventual approval/scheduling, particularly on release Friday; update period, values, narrative and visual together if a new release arrives.

Saved source: `usda-texas-cattle-current-retrieved-2026-11-13.pdf`; exact extracted layout: `usda-cattle.txt`. The public PDF alias can change after this retrieval, so the local dated snapshot is retained.

No schedule, post, source contact, import or external action was performed.
