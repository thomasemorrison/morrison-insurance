# Morrison Insurance — 24 factual social-card fallbacks

Four unique 1080 × 1350 standalone cards per week. PNG is the primary image; a JPEG and self-contained HTML source are also provided for every card. These finished factual static fallbacks are for Facebook and Instagram only, not GBP, and do not fulfill or replace the 12 authentic real-staff video deliverables. No post was scheduled or published.

Original verification is reused from the six supplied week files. No new research, website edits, provider/API calls or outreach. Destinations and their original release gates are recorded in the [manifest](/home/ubuntu/morrison-acquisition-assets/2026-11-16/topic-cards/manifest.json); no card promises that a website destination is live. Original three PDFs and six cards are unchanged.

## Week 01

### Topic 01 — Choose the one renewal question you want answered first

Original topic: `W1-MON` · Layout: question-checklist

![One question is a useful place to start.](/home/ubuntu/morrison-acquisition-assets/2026-11-16/topic-cards/week-01-topic-01.png)

[Download PNG](/home/ubuntu/morrison-acquisition-assets/2026-11-16/topic-cards/week-01-topic-01.png) · [Download JPEG](/home/ubuntu/morrison-acquisition-assets/2026-11-16/topic-cards/week-01-topic-01.jpg) · [HTML source](/home/ubuntu/morrison-acquisition-assets/2026-11-16/topic-cards/week-01-topic-01.html)

**Alt text:** Cream, green and amber typographic Morrison Insurance card with an unchecked question checklist. Hook: One question is a useful place to start. Central question: Which part of this renewal should I look at first? Follow-up questions: What would you need from me to talk through this? What information would be useful next? Next step: Write your first question in your own words. Begin a direct conversation with the general topic. Privacy reminder: Keep policy numbers and document photos out of public comments. Note: Original editorial prompts; not customer quotes. Footer: Morrison Insurance, (936) 598-2791, Center · Shelby County · Deep East Texas. General questions. Not a coverage determination. No people or policy documents pictured.

### Topic 02 — Ask what information is needed next before sending paperwork

Original topic: `W1-WED` · Layout: privacy-preparation

![Do I need to send all my paperwork first?](/home/ubuntu/morrison-acquisition-assets/2026-11-16/topic-cards/week-01-topic-02.png)

[Download PNG](/home/ubuntu/morrison-acquisition-assets/2026-11-16/topic-cards/week-01-topic-02.png) · [Download JPEG](/home/ubuntu/morrison-acquisition-assets/2026-11-16/topic-cards/week-01-topic-02.jpg) · [HTML source](/home/ubuntu/morrison-acquisition-assets/2026-11-16/topic-cards/week-01-topic-02.html)

**Alt text:** Cream, green and amber typographic Morrison Insurance card with a dark-green central-question panel and privacy preparation prompts. Hook: Do I need to send all my paperwork first? Central question: What information would be useful for our conversation? Follow-up questions: Which pages do you need? How should I share them? Next step: Keep paperwork with you. Ask what is needed before deciding what to send. Privacy reminder: No policy or identity details in comments or social messages. Do not assume a social inbox is the right place for documents. Note: Preparation prompts; no promise of a document-free quote or review. Footer: Morrison Insurance, (936) 598-2791, Center · Shelby County · Deep East Texas. General questions. Not a coverage determination. No people or policy documents pictured.

### Topic 03 — Find the coverages, limits and deductibles before asking a comparison question

Original topic: `W1-FRI` · Layout: compare-two-questions

![Where do I find the details I want explained?](/home/ubuntu/morrison-acquisition-assets/2026-11-16/topic-cards/week-01-topic-03.png)

[Download PNG](/home/ubuntu/morrison-acquisition-assets/2026-11-16/topic-cards/week-01-topic-03.png) · [Download JPEG](/home/ubuntu/morrison-acquisition-assets/2026-11-16/topic-cards/week-01-topic-03.jpg) · [HTML source](/home/ubuntu/morrison-acquisition-assets/2026-11-16/topic-cards/week-01-topic-03.html)

**Alt text:** Cream, green and amber typographic Morrison Insurance card with two side-by-side question panels. Hook: Where do I find the details I want explained? Central question: Where do I find the details I want explained? Follow-up questions: Can you help me understand this deductible? Which details should be lined up before comparing the price? Next step: Keep your declarations page for your own reference. Choose one heading to ask about. Privacy reminder: Do not post your declarations page or policy details. Ask how to share anything needed directly. Note: TDI: the declarations page summarizes coverages, dollar limits and deductibles. Footer: Morrison Insurance, (936) 598-2791, Center · Shelby County · Deep East Texas. General questions. Not a coverage determination. No people or policy documents pictured.

### Topic 04 — Ask who handles the next step and confirm timing in the real conversation

Original topic: `W1-SUN` · Layout: process-steps

![How will I know what happens next?](/home/ubuntu/morrison-acquisition-assets/2026-11-16/topic-cards/week-01-topic-04.png)

[Download PNG](/home/ubuntu/morrison-acquisition-assets/2026-11-16/topic-cards/week-01-topic-04.png) · [Download JPEG](/home/ubuntu/morrison-acquisition-assets/2026-11-16/topic-cards/week-01-topic-04.jpg) · [HTML source](/home/ubuntu/morrison-acquisition-assets/2026-11-16/topic-cards/week-01-topic-04.html)

**Alt text:** Cream, green and amber typographic Morrison Insurance card with two numbered conversation steps. Hook: How will I know what happens next? Central question: How will I know what happens next? Follow-up questions: What is the next step, and who should I speak with? When should I check back? Next step: Save these questions for the end of a first conversation. Confirm what information is useful next. Privacy reminder: Keep policy details and documents out of comments and social messages. Note: No office-hours, availability or response-time promise. Footer: Morrison Insurance, (936) 598-2791, Center · Shelby County · Deep East Texas. General questions. Not a coverage determination. No people or policy documents pictured.

## Week 02

### Topic 01 — What happens inside the shed? Describe use rather than rely on a building label.

Original topic: `W2-MON` · Layout: question-checklist

![A building name is only the beginning.](/home/ubuntu/morrison-acquisition-assets/2026-11-16/topic-cards/week-02-topic-01.png)

[Download PNG](/home/ubuntu/morrison-acquisition-assets/2026-11-16/topic-cards/week-02-topic-01.png) · [Download JPEG](/home/ubuntu/morrison-acquisition-assets/2026-11-16/topic-cards/week-02-topic-01.jpg) · [HTML source](/home/ubuntu/morrison-acquisition-assets/2026-11-16/topic-cards/week-02-topic-01.html)

**Alt text:** Cream, green and amber typographic Morrison Insurance card with an unchecked question checklist. Hook: A building name is only the beginning. Central question: What happens inside the shed? Follow-up questions: What is each separate building used for now? Has that use changed? Next step: Make a private list: the building, its current use and what changed. Bring one use question. Privacy reminder: Keep addresses, values, serial numbers and photos of belongings out of comments. Note: TDI: home coverages vary by company. These prompts do not assign an insurance category. Footer: Morrison Insurance, (936) 598-2791, Center · Shelby County · Deep East Texas. General questions. Not a coverage determination. No people or policy documents pictured.

### Topic 02 — When is the change happening? Separate a repair, a planned change and a new use.

Original topic: `W2-WED` · Layout: process-steps

![A plan and a completed change are different notes.](/home/ubuntu/morrison-acquisition-assets/2026-11-16/topic-cards/week-02-topic-02.png)

[Download PNG](/home/ubuntu/morrison-acquisition-assets/2026-11-16/topic-cards/week-02-topic-02.png) · [Download JPEG](/home/ubuntu/morrison-acquisition-assets/2026-11-16/topic-cards/week-02-topic-02.jpg) · [HTML source](/home/ubuntu/morrison-acquisition-assets/2026-11-16/topic-cards/week-02-topic-02.html)

**Alt text:** Cream, green and amber typographic Morrison Insurance card with two numbered conversation steps. Hook: A plan and a completed change are different notes. Central question: Is the work planned, underway or finished? Follow-up questions: Will the space be used differently afterward? What would you need to understand this change, and when should we talk? Next step: Separate planned, underway and finished work in a private note. Confirm the next step directly. Privacy reminder: Keep project addresses, contractor documents and financial details out of comments. Note: Editorial prompts; no policy requirement, deadline or coverage result is asserted. Footer: Morrison Insurance, (936) 598-2791, Center · Shelby County · Deep East Texas. General questions. Not a coverage determination. No people or policy documents pictured.

### Topic 03 — Who will use the space? Describe guests, stays and payment without labeling the answer.

Original topic: `W2-FRI` · Layout: compare-two-questions

![“Someone will stay here” leaves a few useful questions open.](/home/ubuntu/morrison-acquisition-assets/2026-11-16/topic-cards/week-02-topic-03.png)

[Download PNG](/home/ubuntu/morrison-acquisition-assets/2026-11-16/topic-cards/week-02-topic-03.png) · [Download JPEG](/home/ubuntu/morrison-acquisition-assets/2026-11-16/topic-cards/week-02-topic-03.jpg) · [HTML source](/home/ubuntu/morrison-acquisition-assets/2026-11-16/topic-cards/week-02-topic-03.html)

**Alt text:** Cream, green and amber typographic Morrison Insurance card with two side-by-side question panels. Hook: “Someone will stay here” leaves a few useful questions open. Central question: Is it an occasional visit or an ongoing arrangement? Follow-up questions: Is any payment involved? Has the plan started, or are you still considering it? Next step: Describe the plan privately before trying to label it. Ask what information to bring. Privacy reminder: Keep guest names, travel dates, addresses and payment details off social media. Note: Conversation prompts, not a rental classification or coverage answer. Footer: Morrison Insurance, (936) 598-2791, Center · Shelby County · Deep East Texas. General questions. Not a coverage determination. No people or policy documents pictured.

### Topic 04 — What is the land actually used for? Start with routines, not an acreage label.

Original topic: `W2-SUN` · Layout: privacy-preparation

![A rural address is not the whole description.](/home/ubuntu/morrison-acquisition-assets/2026-11-16/topic-cards/week-02-topic-04.png)

[Download PNG](/home/ubuntu/morrison-acquisition-assets/2026-11-16/topic-cards/week-02-topic-04.png) · [Download JPEG](/home/ubuntu/morrison-acquisition-assets/2026-11-16/topic-cards/week-02-topic-04.jpg) · [HTML source](/home/ubuntu/morrison-acquisition-assets/2026-11-16/topic-cards/week-02-topic-04.html)

**Alt text:** Cream, green and amber typographic Morrison Insurance card with a dark-green central-question panel and privacy preparation prompts. Hook: A rural address is not the whole description. Central question: What happens on the land now? Follow-up questions: Is it living, animals, growing, storage or an activity involving sales? What routine or recent change do I want to understand? Next step: List the uses privately; more than one can go on your note. Choose one question for your agent. Privacy reminder: Keep exact locations, animal counts, equipment details and documents out of comments and social messages. Note: Editorial prompts; acreage and activities do not determine policy fit here. Footer: Morrison Insurance, (936) 598-2791, Center · Shelby County · Deep East Texas. General questions. Not a coverage determination. No people or policy documents pictured.

## Week 03

### Topic 01 — Are the same coverage lines being compared?

Original topic: `W3-MON` · Layout: compare-two-questions

![Before comparing the total, compare the lines.](/home/ubuntu/morrison-acquisition-assets/2026-11-16/topic-cards/week-03-topic-01.png)

[Download PNG](/home/ubuntu/morrison-acquisition-assets/2026-11-16/topic-cards/week-03-topic-01.png) · [Download JPEG](/home/ubuntu/morrison-acquisition-assets/2026-11-16/topic-cards/week-03-topic-01.jpg) · [HTML source](/home/ubuntu/morrison-acquisition-assets/2026-11-16/topic-cards/week-03-topic-01.html)

**Alt text:** Cream, green and amber typographic Morrison Insurance card with two side-by-side question panels. Hook: Before comparing the total, compare the lines. Central question: Are the same coverage lines being compared? Follow-up questions: Which lines are different? What would those differences mean for this comparison? Next step: Compare coverage names, dollar limits and listed deductibles privately before comparing totals. Privacy reminder: Keep quote pages, names and identifying numbers out of comments and social messages. Note: TDI: a policy’s declarations page summarizes coverages, limits and deductibles; it does not prove quotes match. Footer: Morrison Insurance, (936) 598-2791, Center · Shelby County · Deep East Texas. General questions. Not a coverage determination. No people or policy documents pictured.

### Topic 02 — Does each quote describe the same drivers and car use?

Original topic: `W3-WED` · Layout: question-checklist

![Does this quote describe how your car is actually used?](/home/ubuntu/morrison-acquisition-assets/2026-11-16/topic-cards/week-03-topic-02.png)

[Download PNG](/home/ubuntu/morrison-acquisition-assets/2026-11-16/topic-cards/week-03-topic-02.png) · [Download JPEG](/home/ubuntu/morrison-acquisition-assets/2026-11-16/topic-cards/week-03-topic-02.jpg) · [HTML source](/home/ubuntu/morrison-acquisition-assets/2026-11-16/topic-cards/week-03-topic-02.html)

**Alt text:** Cream, green and amber typographic Morrison Insurance card with an unchecked question checklist. Hook: Does this quote describe how your car is actually used? Central question: Does this quote describe how my car is actually used? Follow-up questions: Who does the proposed policy cover? Is anyone excluded? Next step: Ask to check the driver and use information before comparing quotes. Keep the details in your own notes. Privacy reminder: Do not post names, driving records or vehicle details. Ask how to handle needed information privately. Note: TDI supports asking about car use, who is covered and exclusions; no answer is assumed. Footer: Morrison Insurance, (936) 598-2791, Center · Shelby County · Deep East Texas. General questions. Not a coverage determination. No people or policy documents pictured.

### Topic 03 — Is the displayed amount a comparable policy total or a payment?

Original topic: `W3-FRI` · Layout: process-steps

![What does the amount on the quote actually describe?](/home/ubuntu/morrison-acquisition-assets/2026-11-16/topic-cards/week-03-topic-03.png)

[Download PNG](/home/ubuntu/morrison-acquisition-assets/2026-11-16/topic-cards/week-03-topic-03.png) · [Download JPEG](/home/ubuntu/morrison-acquisition-assets/2026-11-16/topic-cards/week-03-topic-03.jpg) · [HTML source](/home/ubuntu/morrison-acquisition-assets/2026-11-16/topic-cards/week-03-topic-03.html)

**Alt text:** Cream, green and amber typographic Morrison Insurance card with two numbered conversation steps. Hook: What does the amount on the quote actually describe? Central question: What does the amount on the quote actually describe? Follow-up questions: Is it the policy total, an initial payment or an installment? Can you walk me through the full quoted cost and payment schedule for the same period? Next step: Use three private headings: policy period, total quoted premium and payment questions. Privacy reminder: Keep dollar amounts, account details and quote pages off social media. Note: TDI suggests asking whether paying in advance changes price. Ask; do not assume. Footer: Morrison Insurance, (936) 598-2791, Center · Shelby County · Deep East Texas. General questions. Not a coverage determination. No people or policy documents pictured.

### Topic 04 — What confirms the new effective date before canceling?

Original topic: `W3-SUN` · Layout: privacy-preparation

![A requested start date is something to confirm, not assume.](/home/ubuntu/morrison-acquisition-assets/2026-11-16/topic-cards/week-03-topic-04.png)

[Download PNG](/home/ubuntu/morrison-acquisition-assets/2026-11-16/topic-cards/week-03-topic-04.png) · [Download JPEG](/home/ubuntu/morrison-acquisition-assets/2026-11-16/topic-cards/week-03-topic-04.jpg) · [HTML source](/home/ubuntu/morrison-acquisition-assets/2026-11-16/topic-cards/week-03-topic-04.html)

**Alt text:** Cream, green and amber typographic Morrison Insurance card with a dark-green central-question panel and privacy preparation prompts. Hook: A requested start date is something to confirm, not assume. Central question: What confirms the effective date before cancellation? Follow-up questions: When does the current policy end, including any applicable time? When does new coverage begin, and what written document confirms it? Next step: Ask the relevant insurer to confirm the actual timing and written proof. A quote alone is not confirmation. Privacy reminder: Keep policy numbers and documents out of comments and social messages. Note: TDI: do not cancel the current policy until you get the new policy or a written statement proving coverage. Footer: Morrison Insurance, (936) 598-2791, Center · Shelby County · Deep East Texas. General questions. Not a coverage determination. No people or policy documents pictured.

## Week 04

### Topic 01 — A COI request arrived: what should I clarify first?

Original topic: `W4-MON` · Layout: question-checklist

![Start with the request, not a stack of paperwork.](/home/ubuntu/morrison-acquisition-assets/2026-11-16/topic-cards/week-04-topic-01.png)

[Download PNG](/home/ubuntu/morrison-acquisition-assets/2026-11-16/topic-cards/week-04-topic-01.png) · [Download JPEG](/home/ubuntu/morrison-acquisition-assets/2026-11-16/topic-cards/week-04-topic-01.jpg) · [HTML source](/home/ubuntu/morrison-acquisition-assets/2026-11-16/topic-cards/week-04-topic-01.html)

**Alt text:** Cream, green and amber typographic Morrison Insurance card with an unchecked question checklist. Hook: Start with the request, not a stack of paperwork. Central question: What information do you need to look at this request? Follow-up questions: Who is asking, and what did they request? What date did they give me? Next step: Keep the written certificate-of-insurance request available for a private conversation. Privacy reminder: Keep names, policy numbers and contract pages out of comments and social messages. Note: TDI: a certificate of insurance (COI) gives policy information; it does not change coverage. Footer: Morrison Insurance, (936) 598-2791, Center · Shelby County · Deep East Texas. General questions. Not a coverage determination. No people or policy documents pictured.

### Topic 02 — The business changed: how can I describe what is different?

Original topic: `W4-WED` · Layout: process-steps

![Describe the work now, not just the business name.](/home/ubuntu/morrison-acquisition-assets/2026-11-16/topic-cards/week-04-topic-02.png)

[Download PNG](/home/ubuntu/morrison-acquisition-assets/2026-11-16/topic-cards/week-04-topic-02.png) · [Download JPEG](/home/ubuntu/morrison-acquisition-assets/2026-11-16/topic-cards/week-04-topic-02.jpg) · [HTML source](/home/ubuntu/morrison-acquisition-assets/2026-11-16/topic-cards/week-04-topic-02.html)

**Alt text:** Cream, green and amber typographic Morrison Insurance card with two numbered conversation steps. Hook: Describe the work now, not just the business name. Central question: Does my business description still match the work I do? Follow-up questions: When did the change begin, or when is it expected? What else would you need to understand this change? Next step: On a private sheet, write: “We used to ____. Now we ____.” Keep the description general. Privacy reminder: No customer names, addresses, employee details or financial information in social messages. Note: Delivery work, equipment and customer visits are conversation topics, not coverage conclusions. Footer: Morrison Insurance, (936) 598-2791, Center · Shelby County · Deep East Texas. General questions. Not a coverage determination. No people or policy documents pictured.

### Topic 03 — Can requested certificate wording change the policy?

Original topic: `W4-FRI` · Layout: compare-two-questions

![A wording request is a question, not a coverage change.](/home/ubuntu/morrison-acquisition-assets/2026-11-16/topic-cards/week-04-topic-03.png)

[Download PNG](/home/ubuntu/morrison-acquisition-assets/2026-11-16/topic-cards/week-04-topic-03.png) · [Download JPEG](/home/ubuntu/morrison-acquisition-assets/2026-11-16/topic-cards/week-04-topic-03.jpg) · [HTML source](/home/ubuntu/morrison-acquisition-assets/2026-11-16/topic-cards/week-04-topic-03.html)

**Alt text:** Cream, green and amber typographic Morrison Insurance card with two side-by-side question panels. Hook: A wording request is a question, not a coverage change. Central question: Does this wording match what is actually in the policy? Follow-up questions: Can requested certificate wording change the policy? Does the business agreement meet my needs? Next step: Keep the exact wording request for a private conversation. Contract interpretation is a separate question. Privacy reminder: Do not paste contract pages, policy numbers or customer names into comments or social messages. Note: TDI: a COI cannot change or extend policy coverage. This card does not confirm contract compliance. Footer: Morrison Insurance, (936) 598-2791, Center · Shelby County · Deep East Texas. General questions. Not a coverage determination. No people or policy documents pictured.

### Topic 04 — Where should business documents go, and what belongs in a first message?

Original topic: `W4-SUN` · Layout: privacy-preparation

![Ask where to send it before attaching it.](/home/ubuntu/morrison-acquisition-assets/2026-11-16/topic-cards/week-04-topic-04.png)

[Download PNG](/home/ubuntu/morrison-acquisition-assets/2026-11-16/topic-cards/week-04-topic-04.png) · [Download JPEG](/home/ubuntu/morrison-acquisition-assets/2026-11-16/topic-cards/week-04-topic-04.jpg) · [HTML source](/home/ubuntu/morrison-acquisition-assets/2026-11-16/topic-cards/week-04-topic-04.html)

**Alt text:** Cream, green and amber typographic Morrison Insurance card with a dark-green central-question panel and privacy preparation prompts. Hook: Ask where to send it before attaching it. Central question: Where should I send business paperwork? Follow-up questions: What is the next step for this certificate request? What timing should I confirm for the requested date? Next step: Begin with the general topic. Ask Morrison’s team to confirm the document-sharing method before sending anything sensitive. Privacy reminder: No policy numbers, signatures, contract pages, customer lists or employee information in comments or social messages. Note: Editorial handoff prompts; no secure-channel or turnaround promise. Footer: Morrison Insurance, (936) 598-2791, Center · Shelby County · Deep East Texas. General questions. Not a coverage determination. No people or policy documents pictured.

## Week 05

### Topic 01 — Which one question would make a conversation useful?

Original topic: `W5-MON` · Layout: question-checklist

![Start with one question, not a stack of paperwork.](/home/ubuntu/morrison-acquisition-assets/2026-11-16/topic-cards/week-05-topic-01.png)

[Download PNG](/home/ubuntu/morrison-acquisition-assets/2026-11-16/topic-cards/week-05-topic-01.png) · [Download JPEG](/home/ubuntu/morrison-acquisition-assets/2026-11-16/topic-cards/week-05-topic-01.jpg) · [HTML source](/home/ubuntu/morrison-acquisition-assets/2026-11-16/topic-cards/week-05-topic-01.html)

**Alt text:** Cream, green and amber typographic Morrison Insurance card with an unchecked question checklist. Hook: Start with one question, not a stack of paperwork. Central question: What is one insurance question I want explained before year-end? Follow-up questions: Which word or date do I want to understand? What information would be useful next? Next step: Write the question on a blank sheet and leave room for the answer. Keep any auto page for your own reference. Privacy reminder: Do not post policy numbers, personal details or a photo of your declarations page. Note: For auto, TDI says the declaration page summarizes coverages, dollar limits and deductibles. Footer: Morrison Insurance, (936) 598-2791, Center · Shelby County · Deep East Texas. General questions. Not a coverage determination. No people or policy documents pictured.

### Topic 02 — What can I leave out of a first message?

Original topic: `W5-WED` · Layout: privacy-preparation

![A first message can explain the topic without exposing the paperwork.](/home/ubuntu/morrison-acquisition-assets/2026-11-16/topic-cards/week-05-topic-02.png)

[Download PNG](/home/ubuntu/morrison-acquisition-assets/2026-11-16/topic-cards/week-05-topic-02.png) · [Download JPEG](/home/ubuntu/morrison-acquisition-assets/2026-11-16/topic-cards/week-05-topic-02.jpg) · [HTML source](/home/ubuntu/morrison-acquisition-assets/2026-11-16/topic-cards/week-05-topic-02.html)

**Alt text:** Cream, green and amber typographic Morrison Insurance card with a dark-green central-question panel and privacy preparation prompts. Hook: A first message can explain the topic without exposing the paperwork. Central question: What can I leave out of a first message? Follow-up questions: I have a home insurance question. What is the best way to begin? How should I provide any needed paperwork? Next step: Start with the topic. Say whether it is a new decision or help with something you already have. Privacy reminder: Leave out policy numbers, driver’s license details, birth dates, VINs and document photos. No identifiers in comments or social messages. Note: Editorial privacy prompts; no document channel is described as secure. Footer: Morrison Insurance, (936) 598-2791, Center · Shelby County · Deep East Texas. General questions. Not a coverage determination. No people or policy documents pictured.

### Topic 03 — Can I get ready without arranging a conversation today?

Original topic: `W5-FRI` · Layout: process-steps

![Preparing a question does not have to become today’s appointment.](/home/ubuntu/morrison-acquisition-assets/2026-11-16/topic-cards/week-05-topic-03.png)

[Download PNG](/home/ubuntu/morrison-acquisition-assets/2026-11-16/topic-cards/week-05-topic-03.png) · [Download JPEG](/home/ubuntu/morrison-acquisition-assets/2026-11-16/topic-cards/week-05-topic-03.jpg) · [HTML source](/home/ubuntu/morrison-acquisition-assets/2026-11-16/topic-cards/week-05-topic-03.html)

**Alt text:** Cream, green and amber typographic Morrison Insurance card with two numbered conversation steps. Hook: Preparing a question does not have to become today’s appointment. Central question: Can I get ready without arranging a conversation today? Follow-up questions: What part do I want explained? What next step do I want to ask about? Next step: Make a private topic note and set it aside. If you have a deadline, discuss it and confirm timing when you contact the team. Privacy reminder: Keep identifying details out of comments and social messages. Note: Preparation is not a decision today. This is not an office-hours announcement. Footer: Morrison Insurance, (936) 598-2791, Center · Shelby County · Deep East Texas. General questions. Not a coverage determination. No people or policy documents pictured.

### Topic 04 — Which help route fits my question?

Original topic: `W5-SUN` · Layout: compare-two-questions

![Choose the situation first; the paperwork can wait.](/home/ubuntu/morrison-acquisition-assets/2026-11-16/topic-cards/week-05-topic-04.png)

[Download PNG](/home/ubuntu/morrison-acquisition-assets/2026-11-16/topic-cards/week-05-topic-04.png) · [Download JPEG](/home/ubuntu/morrison-acquisition-assets/2026-11-16/topic-cards/week-05-topic-04.jpg) · [HTML source](/home/ubuntu/morrison-acquisition-assets/2026-11-16/topic-cards/week-05-topic-04.html)

**Alt text:** Cream, green and amber typographic Morrison Insurance card with two side-by-side question panels. Hook: Choose the situation first; the paperwork can wait. Central question: Which starting point fits my question? Follow-up questions: Is it a renewal, property use, business paperwork or existing policy or claim help? Can you point me to the right starting place? Next step: Choose the situation first, then ask what information belongs in the next step. It is not a commitment to buy. Privacy reminder: Keep policy numbers, claim details and document photos out of comments and social messages. Note: Editorial routing prompts; no policy acceptance or claim outcome is promised. Footer: Morrison Insurance, (936) 598-2791, Center · Shelby County · Deep East Texas. General questions. Not a coverage determination. No people or policy documents pictured.

## Week 06

### Topic 01 — What has changed about how I use my car, and what should I ask about that change?

Original topic: `W6-MON` · Layout: question-checklist

![Same car. Different routine?](/home/ubuntu/morrison-acquisition-assets/2026-11-16/topic-cards/week-06-topic-01.png)

[Download PNG](/home/ubuntu/morrison-acquisition-assets/2026-11-16/topic-cards/week-06-topic-01.png) · [Download JPEG](/home/ubuntu/morrison-acquisition-assets/2026-11-16/topic-cards/week-06-topic-01.jpg) · [HTML source](/home/ubuntu/morrison-acquisition-assets/2026-11-16/topic-cards/week-06-topic-01.html)

**Alt text:** Cream, green and amber typographic Morrison Insurance card with an unchecked question checklist. Hook: Same car. Different routine? Central question: What has changed about how I use my car? Follow-up questions: What should we discuss about this change? What information do you need from me? Next step: Privately note a changed commute, who drives or possible work-related use. Ask how to share anything needed. Privacy reminder: Keep names, policy numbers, driver information and documents out of comments and social messages. Note: TDI supports asking about car use and exclusions. No coverage or pricing answer is assumed. Footer: Morrison Insurance, (936) 598-2791, Center · Shelby County · Deep East Texas. General questions. Not a coverage determination. No people or policy documents pictured.

### Topic 02 — Is a planned use of my home or rural-property space different from how it is used today?

Original topic: `W6-WED` · Layout: compare-two-questions

![What will that space be used for?](/home/ubuntu/morrison-acquisition-assets/2026-11-16/topic-cards/week-06-topic-02.png)

[Download PNG](/home/ubuntu/morrison-acquisition-assets/2026-11-16/topic-cards/week-06-topic-02.png) · [Download JPEG](/home/ubuntu/morrison-acquisition-assets/2026-11-16/topic-cards/week-06-topic-02.jpg) · [HTML source](/home/ubuntu/morrison-acquisition-assets/2026-11-16/topic-cards/week-06-topic-02.html)

**Alt text:** Cream, green and amber typographic Morrison Insurance card with two side-by-side question panels. Hook: What will that space be used for? Central question: What should I explain before we discuss my policy? Follow-up questions: How is the room, shed or other space used today? What use am I considering next? Next step: Make two private notes: current use and a possible new use. You do not need a finished plan to ask a question. Privacy reminder: Keep addresses, household details, property photos and documents out of comments and social messages. Note: TDI: home coverages vary by company. A general article does not answer your particular situation. Footer: Morrison Insurance, (936) 598-2791, Center · Shelby County · Deep East Texas. General questions. Not a coverage determination. No people or policy documents pictured.

### Topic 03 — What are my actual policy dates, and which detail needs explaining before a renewal or switch?

Original topic: `W6-FRI` · Layout: process-steps

![A new calendar. Your own policy dates.](/home/ubuntu/morrison-acquisition-assets/2026-11-16/topic-cards/week-06-topic-03.png)

[Download PNG](/home/ubuntu/morrison-acquisition-assets/2026-11-16/topic-cards/week-06-topic-03.png) · [Download JPEG](/home/ubuntu/morrison-acquisition-assets/2026-11-16/topic-cards/week-06-topic-03.jpg) · [HTML source](/home/ubuntu/morrison-acquisition-assets/2026-11-16/topic-cards/week-06-topic-03.html)

**Alt text:** Cream, green and amber typographic Morrison Insurance card with two numbered conversation steps. Hook: A new calendar. Your own policy dates. Central question: What are my actual policy dates? Follow-up questions: Which deductible or coverage-limit detail needs explaining? What confirms new coverage before I request cancellation? Next step: Use your actual paperwork for a private reminder—not a guess based on January 1. Confirm follow-up timing directly. Privacy reminder: Do not post policy dates, numbers or paperwork. This is not a holiday-hours notice. Note: TDI: do not cancel the current policy until you have the new policy or a written statement proving coverage. Footer: Morrison Insurance, (936) 598-2791, Center · Shelby County · Deep East Texas. General questions. Not a coverage determination. No people or policy documents pictured.

### Topic 04 — For a business paperwork conversation, which change is confirmed, which is tentative, and what should happen next?

Original topic: `W6-SUN` · Layout: privacy-preparation

![What is decided—and what is still a possibility?](/home/ubuntu/morrison-acquisition-assets/2026-11-16/topic-cards/week-06-topic-04.png)

[Download PNG](/home/ubuntu/morrison-acquisition-assets/2026-11-16/topic-cards/week-06-topic-04.png) · [Download JPEG](/home/ubuntu/morrison-acquisition-assets/2026-11-16/topic-cards/week-06-topic-04.jpg) · [HTML source](/home/ubuntu/morrison-acquisition-assets/2026-11-16/topic-cards/week-06-topic-04.html)

**Alt text:** Cream, green and amber typographic Morrison Insurance card with a dark-green central-question panel and privacy preparation prompts. Hook: What is decided—and what is still a possibility? Central question: What is decided—and what is still a possibility? Follow-up questions: What information do you need, and how should I share it? When should I follow up? Next step: Separate confirmed work changes from ideas in private notes. Add the general purpose of any paperwork request. Privacy reminder: Keep customer names, contracts, financial details and documents out of comments and social messages. Note: Editorial prompts; no certificate issuance, contractual acceptance or turnaround promise. Footer: Morrison Insurance, (936) 598-2791, Center · Shelby County · Deep East Texas. General questions. Not a coverage determination. No people or policy documents pictured.

