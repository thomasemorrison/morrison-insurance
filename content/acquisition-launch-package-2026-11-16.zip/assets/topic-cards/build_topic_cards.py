#!/usr/bin/env python3
"""Build only the 24 factual FB/IG fallback cards in this directory.
No web requests, provider calls, website writes, or generated people/media.
Pillow is used only to convert Chromium PNG screenshots to JPEG.
"""
from pathlib import Path
import hashlib
import html
import json
import re
from playwright.sync_api import sync_playwright
from PIL import Image

ROOT = Path(__file__).resolve().parent
ORIGINAL = ROOT.parent
SOURCE_DIR = Path('/home/ubuntu/research/acquisition-build-2026-11-16/weeks')
TEMPLATE = ORIGINAL / 'html/week-01-renewal-question.html'
COPY = ROOT / 'card-copy.json'

CSS = r'''
body{width:540px;background:#f7f1e5}
.card{width:540px;aspect-ratio:4/5;padding:24px 28px 21px;display:flex;flex-direction:column;gap:15px;background:#f7f1e5;border-top:7px solid #d4a04d}
.topline{display:flex;justify-content:space-between;align-items:center;gap:12px}
.card .eyebrow{font-size:9px;line-height:1.4;color:#65715b;letter-spacing:.11em}
.small-mark{display:flex;gap:4px;flex-shrink:0}.small-mark i{width:5px;aspect-ratio:1;border-radius:50%;background:#d4a04d}
.hook{font-size:15px;line-height:1.35;font-weight:700;color:#566b4c;margin-top:10px;letter-spacing:-.015em}
.hero{display:flex;flex-direction:column;gap:8px}
.hero-label{font-size:9px;text-transform:uppercase;letter-spacing:.14em;font-weight:700;color:#69765f}
h1{font:400 32px/1.12 'Reader Serif',serif;letter-spacing:-.035em}
.question-area{flex:1;display:flex;flex-direction:column;justify-content:center;gap:0;min-height:0}
.question-area h2{font-size:9px;text-transform:uppercase;letter-spacing:.12em;color:#66735e;margin-bottom:9px;line-height:1.4}
.questions{padding:0;margin:0;list-style:none;display:flex;flex-direction:column}
.question{font-size:18px;line-height:1.29;letter-spacing:-.02em;font-weight:700}
.checklist .questions li{display:grid;grid-template-columns:20px 1fr;gap:12px;padding:14px 0;border-top:1px solid #d2daca;align-items:center}
.checklist .questions li:last-child{border-bottom:1px solid #d2daca}
.check-box{width:17px;aspect-ratio:1;border:1.5px solid #6c7c63;border-radius:3px}
.compare .question-area{gap:10px}.compare-grid{display:grid;grid-template-columns:1fr 1fr;gap:11px}
.compare-panel{padding:15px 14px 17px;background:#edeadd;border-top:3px solid #7b8c6d;display:flex;flex-direction:column;gap:11px}
.compare-panel:last-child{background:#f0e3ca;border-color:#d4a04d}
.panel-label{font-size:9px;line-height:1.35;text-transform:uppercase;letter-spacing:.1em;color:#5a6e52;font-weight:700}
.compare .question{font-size:17px;line-height:1.32}
.process .hero{padding-left:14px;border-left:4px solid #d4a04d}
.steps{display:flex;flex-direction:column;gap:14px}
.step{display:grid;grid-template-columns:31px 1fr;gap:13px;align-items:start}
.step-index{width:29px;aspect-ratio:1;border-radius:50%;background:#e9b660;font-size:13px;font-weight:700;display:flex;align-items:center;justify-content:center}
.step-body{display:flex;flex-direction:column;gap:4px;border-bottom:1px solid #d2daca;padding-bottom:12px}
.step-body .question{font-size:17px}
.privacy .hero{background:#173e30;color:#f7f1e5;padding:18px 19px 20px;border-radius:2px}
.privacy .hero-label{color:#e9b660}
.privacy h1{font-size:30px;line-height:1.14}
.privacy .questions{gap:13px}
.privacy .questions li{border-left:3px solid #d4a04d;padding-left:13px}
.privacy .question{font-size:17px}
.notes{display:flex;flex-direction:column;gap:8px}
.next-step{font-size:12px;line-height:1.38;color:#3e5743;background:#edeadd;padding:10px 12px;border-left:3px solid #d4a04d}
.next-step strong{font-size:9px;letter-spacing:.09em;text-transform:uppercase;display:block;margin-bottom:3px;color:#173e30}
.privacy-note{font-size:10px;line-height:1.4;color:#53644f}
.source-note{font-size:9px;line-height:1.35;color:#66735e}
.footer{border-top:1px solid #cbd4c4;padding-top:10px;display:flex;flex-direction:column;gap:7px}
.brandrow{display:flex;justify-content:space-between;align-items:center;gap:10px}
.brand{font-size:11px;color:#375340}.contact{font-size:13px;font-weight:700;letter-spacing:-.02em;white-space:nowrap}
.footer-bottom{display:flex;justify-content:space-between;align-items:center;gap:12px}
.location{font-size:8px;line-height:1.4;color:#6a785f;max-width:178px}
.disclaimer{font-size:9px;line-height:1.35;color:#375340;font-weight:700;text-align:right}
'''

VARIANTS = {'question-checklist':'checklist','compare-two-questions':'compare','process-steps':'process','privacy-preparation':'privacy'}


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write_json(name, data):
    (ROOT / name).write_text(json.dumps(data, indent=2, ensure_ascii=False)+'\n')


def esc(value):
    return html.escape(str(value), quote=True)


def destination_for(week, topic):
    path = topic.get('destination_path')
    record = {}
    destinations = week.get('destinations', {})
    if isinstance(destinations, list):
        record = next((d for d in destinations if d.get('id') == topic.get('destination_id') or (path and d.get('path') == path)), {})
    elif isinstance(destinations, dict):
        record = destinations.get(topic.get('destination_key'), {})
        if not record and path:
            record = next((d for d in destinations.values() if isinstance(d, dict) and d.get('path') == path), {})
    path = path or record.get('path')
    url = topic.get('destination_url') or record.get('url') or ('https://morrison-ins.net'+path if path else None)
    status = topic.get('destination_status') or record.get('status') or record.get('state')
    if not status:
        status = 'planned_not_verified_live' if path in ['/start-here','/prepare-for-a-conversation','/what-to-expect'] else 'existing_live_per_supplied_brief_recheck_required'
    return {'original_destination_id':topic.get('destination_id'), 'original_destination_key':topic.get('destination_key'), 'path':path, 'url':url, 'status_in_original_handoff':status, 'fallback_path_in_original_handoff':topic.get('fallback_destination_path'), 'planned_path_after_release':topic.get('planned_destination_after_verified_release'), 'visible_card_destination':'Direct conversation; no website URL or profile-link promise appears on the card.', 'release_verified_in_this_task':False, 'activation_boundary':'Retain original copy, destination, approval, source-currency and capacity gates; no silent link swaps.'}


def render_html(card, topic, base_css):
    kind = VARIANTS[card['variant']]
    q = card['support_questions']
    if kind == 'compare':
        questions = '<section class="question-area" aria-label="Two questions to compare"><h2>Put both questions beside the main one</h2><div class="compare-grid">'+''.join(f'<div class="compare-panel"><p class="panel-label">{esc(label)}</p><p class="question">{esc(question)}</p></div>' for label, question in zip(card['compare_labels'],q))+'</div></section>'
    elif kind == 'process':
        questions = '<section class="question-area" aria-label="Two conversation steps"><h2>Two questions for the next step</h2><div class="steps">'+''.join(f'<div class="step"><span class="step-index" aria-hidden="true">{i}</span><div class="step-body"><p class="panel-label">{esc(label)}</p><p class="question">{esc(question)}</p></div></div>' for i,(label,question) in enumerate(zip(card['step_labels'],q),1))+'</div></section>'
    else:
        section_title = 'Ask before sharing details' if kind == 'privacy' else 'Keep two follow-up questions handy'
        questions = f'<section class="question-area"><h2>{section_title}</h2><ul class="questions">'+''.join(f'<li>{"<span class=\"check-box\" aria-hidden=\"true\"></span>" if kind == "checklist" else ""}<p class="question">{esc(question)}</p></li>' for question in q)+'</ul></section>'
    return f'''<!DOCTYPE html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>{esc(card['central_question'])}</title><style>{base_css}\n{CSS}</style></head>
<body><main class="card {kind}" aria-label="Morrison Insurance factual question card">
<header><div class="topline"><p class="eyebrow">{esc(card['category'])}</p><span class="small-mark" aria-hidden="true"><i></i><i></i><i></i></span></div><p class="hook">{esc(topic['hook'])}</p></header>
<section class="hero"><p class="hero-label">One central question</p><h1>{esc(card['central_question'])}</h1></section>
{questions}
<div class="notes"><aside class="next-step"><strong>A useful next step</strong>{esc(card['next_step'])}</aside><p class="privacy-note">{esc(card['privacy_note'])}</p><p class="source-note">{esc(card['source_line'])}</p></div>
<footer class="footer"><div class="brandrow"><p class="brand">Morrison Insurance</p><p class="contact">(936) 598-2791</p></div><div class="footer-bottom"><p class="location">Center · Shelby County · Deep East Texas</p><p class="disclaimer">General questions.<br>Not a coverage determination.</p></div></footer>
</main></body></html>\n'''


def main():
    assert ROOT.name == 'topic-cards'
    protected = sorted(f for f in ORIGINAL.rglob('*') if f.is_file() and ROOT not in f.parents)
    before = {str(p):sha(p) for p in protected}
    copy_data = json.loads(COPY.read_text())
    cards = copy_data['cards']
    assert len(cards) == 24 and len({(c['week'],c['topic_index']) for c in cards}) == 24
    template_html = TEMPLATE.read_text()
    template_style = re.search(r'<style>(.*?)</style>', template_html, re.S).group(1)
    base_css = template_style.split('body{width:540px}')[0]
    assert "Reader Sans" in base_css and "Reader Serif" in base_css and base_css.count('@font-face') == 3
    weeks = {w:json.loads((SOURCE_DIR/f'week-{w}.json').read_text()) for w in range(1,7)}
    results = []
    manifest_cards = []
    with sync_playwright() as p:
        browser = p.chromium.launch(executable_path='/usr/bin/chromium', headless=True, args=['--no-sandbox', '--disable-dev-shm-usage'])
        context = browser.new_context(viewport={'width':540,'height':675}, device_scale_factor=2)
        context.route('**/*', lambda route: route.continue_() if route.request.url.startswith(('file:','data:','about:')) else route.abort())
        page = context.new_page()
        for card in cards:
            w,t = card['week'],card['topic_index']
            week = weeks[w]
            topic = week['topic_pairs'][t-1]
            name = f'week-{w:02d}-topic-{t:02d}'
            html_path,png_path,jpeg_path = [ROOT / (name+ext) for ext in ['.html','.png','.jpg']]
            html_path.write_text(render_html(card,topic,base_css))
            page.goto(html_path.as_uri(), wait_until='load')
            page.evaluate('document.fonts.ready')
            page.wait_for_function("document.fonts.check('400 32px \"Reader Serif\"') && document.fonts.check('400 18px \"Reader Sans\"') && document.fonts.check('700 18px \"Reader Sans\"')")
            metrics = page.evaluate('''() => {
              const card=document.querySelector('.card'), r=card.getBoundingClientRect();
              const errors=[];
              if(Math.abs(r.width-540)>0.1 || Math.abs(r.height-675)>0.1) errors.push('Card dimensions not 540 × 675 CSS px');
              if(card.scrollHeight>card.clientHeight+1 || card.scrollWidth>card.clientWidth+1) errors.push('Card scroll overflow');
              for(const e of card.querySelectorAll('*')) {
                const b=e.getBoundingClientRect();
                if(b.width && b.height && (b.left<r.left-0.5 || b.right>r.right+0.5 || b.top<r.top-0.5 || b.bottom>r.bottom+0.5)) errors.push('Element beyond card: '+e.className);
                if(e.scrollWidth>e.clientWidth+1) errors.push('Horizontal overflow: '+e.className);
              }
              const sections=[...card.children].map(e=>({name:e.tagName+'.'+e.className,rect:e.getBoundingClientRect()}));
              for(let i=1;i<sections.length;i++) if(sections[i].rect.top<sections[i-1].rect.bottom-0.5) errors.push('Section overlap: '+sections[i].name);
              const qa=document.querySelector('.question-area').getBoundingClientRect(), note=document.querySelector('.notes').getBoundingClientRect();
              for(const e of document.querySelectorAll('.question')) {const b=e.getBoundingClientRect();if(b.top<qa.top-0.5 || b.bottom>qa.bottom+0.5 || b.bottom>note.top+0.5)errors.push('Question exceeds allocated layout');}
              return {width:r.width,height:r.height,scrollHeight:card.scrollHeight,clientHeight:card.clientHeight,errors,font_status:document.fonts.status,fonts:[...document.fonts].map(f=>({family:f.family,weight:f.weight,status:f.status})),text:card.innerText};
            }''')
            errors = metrics['errors']
            assert not errors, f'{name}: {errors}'
            page.locator('main.card').screenshot(path=str(png_path),animations='disabled')
            with Image.open(png_path) as image:
                assert image.size == (1080,1350), (name,image.size)
                image.convert('RGB').save(jpeg_path,format='JPEG',quality=95,subsampling=0,optimize=True)
            sources = topic.get('source_ids',topic.get('sources',[]))
            refs = [s for s in week.get('sources',[]) if s.get('id') in sources]
            original_title = topic.get('topic') or topic.get('reader_question')
            all_q = [card['central_question']]+card['support_questions']
            variant_alt = {'question-checklist':'an unchecked question checklist','compare-two-questions':'two side-by-side question panels','process-steps':'two numbered conversation steps','privacy-preparation':'a dark-green central-question panel and privacy preparation prompts'}[card['variant']]
            alt = f'Cream, green and amber typographic Morrison Insurance card with {variant_alt}. Hook: {topic["hook"]} Central question: {all_q[0]} Follow-up questions: {" ".join(all_q[1:])} Next step: {card["next_step"]} Privacy reminder: {card["privacy_note"]} Note: {card["source_line"]} Footer: Morrison Insurance, (936) 598-2791, Center · Shelby County · Deep East Texas. General questions. Not a coverage determination. No people or policy documents pictured.'
            manifest_cards.append({
                'asset_id':name,'week':w,'topic_index':t,'original_topic_id':topic['id'],'original_topic_title':original_title,'original_title_field':'topic' if 'topic' in topic else 'reader_question','original_reader_hook':topic['hook'],'source_file':str(SOURCE_DIR/f'week-{w}.json'),'source_file_sha256':sha(SOURCE_DIR/f'week-{w}.json'),'variant':card['variant'],'exact_questions':all_q,'exact_support_questions':card['support_questions'],'exact_next_step':card['next_step'],'exact_privacy_note':card['privacy_note'],'exact_visible_source_note':card['source_line'],'source_ids':sources,'source_ids_are_scoped_to_original_week':True,'source_references':refs,'original_source_boundary':topic.get('source_note') or topic.get('evidence_note'),'destination':destination_for(week,topic),'channels':['Facebook','Instagram'],'excluded_channels':['Google Business Profile','LinkedIn'],'asset_role':'Finished factual static fallback only; not a replacement for authentic staff video deliverables.','status':'Finished locally; not approved, scheduled or published.','dimensions_px':{'width':1080,'height':1350},'paths':{'png':str(png_path),'jpeg':str(jpeg_path),'html':str(html_path)},'sha256':{'png':sha(png_path),'jpeg':sha(jpeg_path),'html':sha(html_path)},'alt_text':alt,'render_validation':{'font_readiness':'loaded','overflow_test':'pass','css_dimensions':[540,675],'device_scale_factor':2},'visual_inspection':'pending_one_pass'
            })
            results.append({'asset_id':name,**metrics,'png_dimensions':[1080,1350],'jpeg_dimensions':[1080,1350]})
            print(f'Rendered {name}: 1080 × 1350 PNG/JPEG, fonts loaded, overflow PASS',flush=True)
        browser.close()
    after = {str(p):sha(p) for p in protected}
    assert after == before, 'Original assets changed'
    write_json('preservation-check.json',{'status':'PASS','all_original_files_unchanged':True,'protected_files_sha256':before,'original_pdfs_preserved':3,'original_social_cards_preserved':6})
    write_json('render-validation.json',{'renderer':'Playwright /usr/bin/chromium','network_requests_allowed':False,'device_scale_factor':2,'cards':results})
    manifest = {'created_on':'2026-11-16','scope':'24 unique factual static FB/IG fallback cards, four per week','asset_count':24,'formats':['PNG','JPEG','HTML'],'size_px':[1080,1350],'source_verification':'Reused original writers’ verification in six supplied week files. No new research or external verification.','template':str(TEMPLATE),'template_sha256':sha(TEMPLATE),'font_and_head_css_reuse':'Three original embedded font faces and original base typography/palette; four new deterministic layouts.','visible_contact_source':'Original supplied HTML template: (936) 598-2791. Not newly verified.','boundaries':['No website edits.','No API/provider calls, outreach, cloud browser or new research.','No generated or pretend staff, customers, policy documents, claims or videos.','No price, savings, policy-specific coverage, issuance, turnaround or claim-outcome promises.','No GBP use.','Planned destinations are metadata only; cards make no live-page or clickable Instagram caption-link claims.','Retain source-currency, exact-copy, format, destination, capacity and separate publication gates.','These are factual still-card FALLBACKS, not substitutes for the 12 real-staff video deliverables.'],'original_preservation':'All pre-existing files outside topic-cards verified unchanged; original 3 PDFs and 6 social cards preserved.','cards':manifest_cards}
    write_json('manifest.json',manifest)
    gallery = ['# Morrison Insurance — 24 factual social-card fallbacks','', 'Four unique 1080 × 1350 standalone cards per week. PNG is the primary image; a JPEG and self-contained HTML source are also provided for every card. These finished factual static fallbacks are for Facebook and Instagram only, not GBP, and do not fulfill or replace the 12 authentic real-staff video deliverables. No post was scheduled or published.','', 'Original verification is reused from the six supplied week files. No new research, website edits, provider/API calls or outreach. Destinations and their original release gates are recorded in the [manifest]('+str(ROOT/'manifest.json')+'); no card promises that a website destination is live. Original three PDFs and six cards are unchanged.','']
    for w in range(1,7):
        gallery += [f'## Week {w:02d}','']
        for c in manifest_cards:
            if c['week'] != w: continue
            gallery += [f'### Topic {c["topic_index"]:02d} — {c["original_topic_title"]}', '', f'Original topic: `{c["original_topic_id"]}` · Layout: {c["variant"]}', '', f'![{c["original_reader_hook"]}]({c["paths"]["png"]})', '', f'[Download PNG]({c["paths"]["png"]}) · [Download JPEG]({c["paths"]["jpeg"]}) · [HTML source]({c["paths"]["html"]})', '', f'**Alt text:** {c["alt_text"]}', '']
    (ROOT/'gallery.md').write_text('\n'.join(gallery)+'\n')
    print('Complete: 24 standalone PNGs, 24 JPEGs, 24 HTML files, manifest, validation, preservation record and gallery.',flush=True)


if __name__ == '__main__':
    main()
