# Morrison acquisition launch package

Review-ready, not an active Metricool schedule. Website is live and independently verified November 16; social campaign activation remains separate. Start with documents/acquisition-launch-guide-2026-11-16.md, then the calendar and full copy.

assets/topic-cards contains 24 JPEGs, 24 PNGs and their self-contained editable HTML sources. assets/pdf contains three one-page preparation aids. Staff videos are 12 recording scripts in the copy packet, not filmed clips. Saturday/sports/fishing content retains fresh-source gates.

This is not a Metricool import ZIP/CSV; the schedule includes preserved commitments and reservations that must never be imported as duplicate posts. Workspace links in Markdown work inside Manus; after extraction use the corresponding files in these folders. No private credentials or customer documents are included.
