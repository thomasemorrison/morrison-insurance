# Morrison question-to-conversation acquisition campaign

Current status: 48 approved Facebook/Instagram placements are actively scheduled for November 23, 2026–January 3, 2027: 24 per channel. All have independent provider readback, exact media/copy/date/settings checks and PENDING status. PENDING means scheduled, not published. Existing commitments remain unchanged; two placements per channel per local calendar day is the hard ceiling.

Start with documents/acquisition-social-scheduled-2026-11-16.md for the actual schedule, exact planner links, per-channel weekly counts and remaining holds. The planner JSON is the canonical exact-ID receipt. The six-week calendar also contains reserved and conditional rows which are not active schedules; weekly minimums have not been artificially filled.

Seven selected Google Updates are inactive text-only drafts pending approved authentic topical photos and individually verified separate destination buttons. They have no generic building-image fallback. LinkedIn is manual/copy-only. Staff scripts, optional Stories, school/fishing reservations and conditional Saturday material are not extra scheduled posts.

The three new website utilities are already live and verified. No new Website Publish action is required for this scheduling batch. The package retains exact approved copy, finished/editable graphics, three ungated preparation PDFs, team handling guidance and the source/release evidence. Real inquiry delivery, conversion tracking and lead results remain separate measurement gates.

The reusable morrison-acquisition-campaign skill is delivered separately through its skill card. No credentials, private configuration, customer records or standing future publication approval are included here.
