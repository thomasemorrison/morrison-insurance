# Week 3 — December 7–13, 2026

**Theme:** Compare auto quote details and effective dates without promising savings.

**Status:** Review-ready copy only. Nothing is approved, scheduled, published or recorded. All dates below are proposed days; parent assigns actual times after fresh per-channel capacity checks. Website production and release belong to parent. This bundle owns no website files and uses no user images, customer documents, external social posts, generated staff, finished footage or delegated agents.

Four independent questions anchor the week: Monday compares coverage lines; Wednesday checks drivers and car use; Friday clarifies policy totals and payment terms; Sunday asks what confirms effective dates before cancellation. These are new useful questions, not four versions of the same post.

## Placement and release gates

Tuesday December 8 five-school sports and Thursday December 10 fishing remain preserved, separate anchors. Their future results, conditions and event details are not written here; their existing research and approval processes apply close to delivery. Preserve all committed awards/community content and the review-ready library. The Saturday prompt below is eligible only if no award or community commitment occupies that placement.

Four acquisition pairs, the two preserved anchors and one eligible Saturday placement would make seven FB/IG posts per channel before other approved content. Parent reconciles the full 7–10 weekly plan with actual commitments. Maximum two posts per channel per day applies independently to Facebook and Instagram and includes the old library. Do not add these items blindly or delete approved material. Videos replace their corresponding acquisition placement if selected; they are not automatically additional posts. The optional three-frame Story sequence replaces Friday's Instagram acquisition placement, not extra volume.

**G1 — Separate approval.** Obtain explicit approval for exact copy, channel, selected destination and visual or authentic recording before scheduling or manual publication. This bundle grants none.

**G2 — Fresh capacity.** Read back current commitments separately for Facebook and Instagram before assigning times. Count sports, fishing, awards and the library. Enforce maximum two per channel per day and reconcile the full weekly plan. A substitute removes or defers the displaced placement.

**G3 — Public destination and preview.** Existing guide routes are live according to the supplied brief, not independently tested in this subtask. Parent verifies each exact public URL, correct content, crawler metadata, mobile delivery and channel preview before release. Hold the item if its selected destination fails; do not redirect readers to an unrelated page.

**G4 — Unreleased utility pages.** `/start-here`, `/prepare-for-a-conversation` and `/what-to-expect` are planned only. Do not link to them, claim they are available or silently substitute them until parent verifies the real public release and approves revised copy and destination. All copy below uses existing guides instead.

**G5 — TDI recheck.** Both official sources were opened and read November 16, 2026. Recheck close to the December 7–13 placements and resolve changed wording before approval. Do not infer a reader's coverage or treat a requested start date as proof of coverage.

**G6 — Authentic media and privacy.** Still photos and staff videos described here require new authentic capture, consent and approval. No customer names, faces, documents, plates, addresses, policy numbers, screens, staged outcomes, generated staff or unapproved collaborators. Question cards are educational aids, not fabricated quote documents. Check final backgrounds, crops, audio and captions. Use warm green, cream and small amber accents, ordinary clothing and natural office light; no suits or captive-carrier imagery.

**G7 — Provider readback.** Only after separately authorized scheduling, verify exact copy, correct brand/channel, intended local date/time, destination, media and final provider status. A draft is not a scheduled or published post. Verify the actual public post after release.

**G8 — Conditional lanes and manual holds.** Check Saturday against committed awards/community content first. Keep sports and fishing untouched. GBP requires an approved authentic photo and verified button destination. LinkedIn stays manual hold pending individual approval. No invented office hours, holiday availability or response timing.

**G9 — Privacy-safe contact and attribution.** Public replies and social DMs do not request documents or identifiers. Verify the existing website contact route before using it to arrange an appropriate next step; actual staff confirms timing. Do not modify profile links, forms, GA4, GTM, Ads or HubSpot without approval. Link clicks, saves and followers are not leads.

### Destinations

- **D1:** `/resources/car-insurance-quotes-center-tx` — https://morrison-ins.net/resources/car-insurance-quotes-center-tx
- **D2:** `/resources/car-insurance-quote-checklist-center-tx` — https://morrison-ins.net/resources/car-insurance-quote-checklist-center-tx
- **D3:** `/resources/car-insurance-companies-center-tx` — https://morrison-ins.net/resources/car-insurance-companies-center-tx
- **D4:** `/resources/switch-car-insurance-texas-without-gap` — https://morrison-ins.net/resources/switch-car-insurance-texas-without-gap
- **D5, moderation fallback only:** `/contact` — https://morrison-ins.net/contact. The brief authorizes an existing contact route but does not independently establish this exact pathname. Parent must verify it before using it; no caption below promises this link.

D1–D4 are existing live guides per the brief, subject to G3. Instagram destinations are metadata, not a claim that a bio link is set. Its exact captions are self-contained and make no link-in-bio promise. A bio/website link requires separate approval and verification; this task changes no profile configuration.

## Monday, December 7 — Are the same coverage lines being compared?

**ID:** W3-MON. **Hook:** Before comparing the total, compare the lines. **Destination:** D1. **Reply:** R1. **Gates:** G1–G7 and G9.

### Facebook — exact copy, 145 words

> Before comparing two auto quote totals, ask a smaller question: are the same coverage lines being compared?
>
> Set the pages side by side privately. Look for the coverage names, the dollar limits shown, and any deductibles listed. Circle an unfamiliar word on your own copy, then write one question on a separate blank sheet. You do not have to understand every line before asking for help.
>
> The Texas Department of Insurance explains that a policy's declarations page summarizes coverages, limits and deductibles. Use that summary as a starting point, not a reason to assume two quotes are identical.
>
> A useful opening question is: “Which lines are different, and what would those differences mean for this comparison?”
>
> Our auto quote guide is here: https://morrison-ins.net/resources/car-insurance-quotes-center-tx
>
> Keep policy pages, names and identifying numbers out of comments and social messages. One general question is enough to begin a conversation.

### Instagram — exact copy, 78 words

> Before comparing auto quote totals, compare the lines.
>
> Look for coverage names, dollar limits and listed deductibles. TDI says a policy's declarations page summarizes those details. On a separate blank sheet, write: “Which lines differ, and what do those differences mean?”
>
> You do not have to understand every term before asking a question. Keep the actual pages private; please do not share documents or identifying numbers in comments or social messages.
>
> Save this question for your next conversation.

**Visual brief:** Newly capture an authentic overhead office photo of three cream question cards handwritten “Coverage names,” “Limits” and “Deductibles” on a plain green desk mat. A staff hand may point if consented. No printed quote, declarations page, customer file, screen or carrier logo. Warm natural light and a small amber pencil; no staged client scene. No asset supplied.

**Alt text:** Three handwritten question cards on an office desk: coverage names, limits and deductibles.

**Source support:** TDI's auto guide supports the declarations-page summary; its shopping checklist supports coverage and deductible questions. Side-by-side comparison is an editorial preparation suggestion, not a claim that particular quotes match. [1] [2]

## Wednesday, December 9 — Does each quote describe the same drivers and car use?

**ID:** W3-WED. **Hook:** Does this quote describe how your car is actually used? **Destination:** D2. **Reply:** R2. **Gates:** G1–G7 and G9.

### Facebook — exact copy, 148 words

> A useful auto quote question is not only “What is the total?” It is also “Does this describe how my car is actually used?”
>
> Before your next conversation, make a private note of the questions you want to ask about drivers and car use. You might ask who the proposed policy covers, whether anyone is excluded, and whether the use described in the quote matches your situation. Do not put names, driving records or vehicle details in a public comment.
>
> TDI's shopping checklist asks whether a policy covers how you use your car and whether there are exclusions. Its auto guide also recommends asking your agent or reading the policy to understand who is covered.
>
> Try this opener: “Can we check the driver and use information before comparing these quotes?”
>
> Our preparation guide: https://morrison-ins.net/resources/car-insurance-quote-checklist-center-tx
>
> Bring the question first. Ask the team how to handle any needed details privately.

### Instagram — exact copy, 79 words

> Does an auto quote describe how your car is actually used?
>
> TDI's shopping checklist suggests asking about car use and exclusions. Its auto guide recommends checking who the policy covers.
>
> Write one question: “Can we check the driver and use information before comparing these quotes?” You can ask that without posting anyone's name, driving record or vehicle details.
>
> Keep your notes private. A general question can start the conversation; ask the team how to handle any needed information next.

**Visual brief:** Newly capture an authentic staff-prepared note at an uncluttered office desk with only “Who is covered?” and “How is the car used?” handwritten. Photograph the question aid without a person if consent is unavailable. No vehicles, plates, identifiable driver, real application or invented mileage figure. No asset supplied.

**Alt text:** A handwritten office note asks who is covered and how the car is used.

**Source support:** TDI's auto guide supports asking who is covered and whether anyone is excluded. Its shopping checklist explicitly asks about car use and exclusions. No claim that any particular driver, activity or vehicle is covered. [1] [2]

## Friday, December 11 — Is the displayed amount a comparable policy total or a payment?

**ID:** W3-FRI. **Hook:** What does the amount on the quote actually describe? **Destination:** D3. **Reply:** R3. **Gates:** G1–G7 and G9.

### Facebook — exact copy, 150 words

> When two auto quotes show different amounts, first ask what each amount describes. Is it the total for the stated policy period, an initial payment, or an installment?
>
> On a blank sheet, write three headings: policy period, total quoted premium, and payment questions. Ask the person explaining the quote to identify those items and any charges included in the payment arrangement. Leave the dollar amounts and account details off social media.
>
> TDI's shopping checklist includes a useful question: is the price different if you pay in advance? That is a question to ask, not a promise that a particular payment choice changes your price.
>
> Try: “Can you walk me through the full quoted cost and payment schedule for the same period?”
>
> Our guide to comparing auto insurance companies: https://morrison-ins.net/resources/car-insurance-companies-center-tx
>
> The goal is to understand what you are comparing. You can take that question into a conversation without choosing anything today.

### Instagram — exact copy, 78 words

> What does the amount on an auto quote describe: the policy total, an initial payment, or an installment?
>
> Write three headings on a blank sheet: policy period, total quoted premium, and payment questions. Ask someone to walk through them with you.
>
> TDI's checklist asks whether price differs when paying in advance. Ask; do not assume.
>
> Keep dollar amounts, account information and quote pages out of comments or social messages. Understanding the comparison does not require a decision today.

**Visual brief:** Newly capture an authentic desk still of a staff-written blank comparison aid with only “Policy period,” “Total quoted premium” and “Payment questions” headings. No amounts, dates, filled cells, insurer branding or financial documents. The aid must not resemble a fabricated customer quote. Green and cream paper with a small amber tab. No asset supplied.

**Alt text:** A blank question sheet with headings for policy period, total quoted premium and payment questions.

**Source support:** TDI's checklist supports asking whether paying in advance changes price. Questions about periods, initial payments, installments and charges are original preparation prompts for the actual terms, not claims that every quote has fees or a particular payment arrangement. [2]

## Sunday, December 13 — What confirms the new effective date before canceling?

**ID:** W3-SUN. **Hook:** A requested start date is something to confirm, not assume. **Destination:** D4. **Reply:** R4. **Gates:** G1–G7 and G9.

### Facebook — exact copy, 148 words

> If you are considering changing auto policies, put the date questions beside the quote questions. A requested start date is something to confirm, not assume.
>
> Ask the relevant insurer to confirm when the current policy ends and when the new coverage actually begins, including any applicable time. Ask what document shows that the new coverage is in place and what steps are needed for the current policy.
>
> TDI's shopping guide says not to cancel your current policy until you get your new policy or a written statement proving you have coverage. A quote alone is not that confirmation.
>
> A useful opener is: “What confirms the new coverage and its effective date before I make any cancellation request?”
>
> Read our policy-change guide: https://morrison-ins.net/resources/switch-car-insurance-texas-without-gap
>
> Please keep policy numbers and documents out of comments and social messages. Save the question for a direct conversation; confirm next-step timing with the actual team.

### Instagram — exact copy, 81 words

> Comparing auto policies? Compare the timing questions, too.
>
> Ask when the current policy ends, when the new coverage begins, and what written document confirms that coverage. Confirm any applicable time with the insurer rather than assuming dates match.
>
> TDI says not to cancel the current policy until you get the new policy or a written statement proving coverage. A quote alone is not that confirmation.
>
> Keep documents and policy numbers private. Save this question: “What confirms the effective date before cancellation?”

**Visual brief:** Newly capture an authentic office photo of two cream cards labeled “Current policy ends?” and “New coverage begins?” beside a third labeled “Written confirmation?” No filled dates, policy papers, real calendar appointments or customer details. Photograph the question cards only; do not imply a particular transition is approved. No asset supplied.

**Alt text:** Three question cards ask when the current policy ends, when new coverage begins and what confirms it in writing.

**Source support:** TDI directly advises getting the new policy or a written statement proving coverage before canceling the current policy. Date/time checks are practical questions, not a claim of a prescribed effective time or a guarantee of continuous coverage. A quote is not the policy or written proof identified by that guidance. [2]

## GBP Update candidates — authentic photos required

The exact Update bodies below contain no phone number, URL, domain or hashtag. Destination links belong only in the separately approved **Learn more** button. Character counts include spaces and paragraph breaks, exclude metadata/button URL, and remain below 1,500. Do not publish without a newly captured authentic photo and approval. **Gates:** G1, G3–G9.

### W3-GBP-1 — proposed Monday, December 7

**Hook:** Compare the coverage lines before the totals. **Destination:** D1. **Button:** Learn more. **Reply:** R1. **Body:** 747 characters.

> Comparing auto quotes? Start with the coverage lines before the totals.
>
> Look for coverage names, dollar limits and listed deductibles. The Texas Department of Insurance explains that a policy's declarations page summarizes those details. Use that summary to prepare questions rather than assuming two quotes are identical.
>
> Write this on a separate blank sheet: “Which lines differ, and what do those differences mean for my comparison?” You do not need to understand every term before asking.
>
> Keep your actual quote pages and identifying information private. Please do not put documents, policy numbers or driver details in public comments or social messages. A general question is a useful first step.
>
> Use Learn more for our auto quote guide.

**Authentic image brief:** New office photo of the question cards “Coverage names,” “Limits” and “Deductibles” on a cream-and-green desk. No customer material, staff portrait without consent, logo, stock photo or generated image. Photo required before approval; no asset supplied.

**Alt text:** Handwritten question cards for coverage names, limits and deductibles on a desk.

**Source support:** Declarations-page summary and coverage/deductible shopping questions. [1] [2]

### W3-GBP-2 — proposed Sunday, December 13

**Hook:** Ask what confirms the effective date. **Destination:** D4. **Button:** Learn more. **Reply:** R4. **Body:** 824 characters.

> A proposed auto policy start date is a question to confirm.
>
> If you are considering a change, ask the relevant insurer when your current policy ends, when the new coverage actually begins and whether an applicable time needs to be checked. Ask which written document confirms that coverage is in place.
>
> The Texas Department of Insurance says not to cancel your current policy until you get your new policy or a written statement proving you have coverage. Do not treat a quote alone as that confirmation.
>
> Try this question: “What confirms the new coverage and effective date before I request cancellation?”
>
> Keep actual policy papers and identifying numbers private. Confirm next-step timing in a direct conversation; this post does not establish coverage or an effective date.
>
> Use Learn more for our policy-change guide.

**Authentic image brief:** New close-up office still of the cards “Current policy ends?”, “New coverage begins?” and “Written confirmation?” No actual dates, appointments, policy documents, customer identity or invented timeline. Check reflections and background. Original photography required; no asset supplied.

**Alt text:** Blank timing-question cards on an office desk beside a pencil.

**Source support:** Written coverage confirmation before canceling; no prescribed time or effective-date guarantee. [2]

## LinkedIn — two manual holds

Each candidate needs individual manual approval; proposed days do not authorize scheduling. **Gates:** G1, G3–G9. Text-only is preferred. No collaboration tags, customer identity or invented service results.

### W3-LI-1 — proposed Wednesday, December 9

**Hook:** A useful first message can be one general question. **Destination:** D2. **Reply:** R2. **Exact copy:** 89 words.

> A useful first message about an auto quote can be one general question, not a packet of personal documents.
>
> For example: “Can we check whether the driver and car-use information matches before comparing these quotes?” TDI's shopping checklist asks about vehicle use and exclusions; its auto guide recommends checking who is covered.
>
> Keep names, driving records, policy numbers and quote pages out of public comments and social messages. Ask the team how to handle any details privately and confirm the next step during that conversation.
>
> Our preparation guide: https://morrison-ins.net/resources/car-insurance-quote-checklist-center-tx

**Visual brief:** Text-only manual candidate preferred. If separately approved, use a new authentic office photo of an unfilled question card. No customer, stock client scene or generated staff. No asset supplied.

**Source support:** TDI questions on car use, exclusions and who is covered. [1] [2]

### W3-LI-2 — proposed Friday, December 11

**Hook:** Clarify the payment terms before drawing a conclusion. **Destination:** D3. **Reply:** R3. **Exact copy:** 93 words.

> An auto quote comparison gets clearer when the payment questions are named.
>
> Ask which amount is the total quoted premium, what policy period it covers, and how the proposed payment schedule works. Ask which charges, if any, are included. TDI's shopping checklist also asks whether paying in advance changes the price; it does not establish the answer for your quote.
>
> A useful next step is to write those questions on a blank sheet and have the actual terms explained before drawing a conclusion. Keep financial details and documents private.
>
> Our comparison guide: https://morrison-ins.net/resources/car-insurance-companies-center-tx

**Visual brief:** Text-only manual candidate preferred. Optional approved authentic office still of blank “Policy period,” “Total quoted premium” and “Payment questions” headings. No filled amounts, invented example, client story or corporate-suit stock image. No asset supplied.

**Source support:** TDI supports the advance-payment question; the other wording asks about actual terms without asserting a fee or payment benefit. [2]

## Two authentic staff-video scripts — awaiting recording

These are verbatim scripts and precise recording plans, not finished footage. Only a consented authentic Morrison staff member records them in the real office, ordinary clothing, natural warm light and clear live speech, vertical 9:16. No generated staff/avatar, client, customer document, real policy example, screen or license claim. No music is needed. No improvised coverage, price, response-time or availability promises.

Use each as a replacement for its corresponding acquisition placement, not an automatic addition. If selected, use the exact corresponding FB/IG caption above as its companion caption. **Gates:** G1–G7 and G9.

### W3-VIDEO-1 — proposed Monday, December 7

**Hook:** Compare three lines, not just the total. **Destination:** D1. **Reply:** R1. **Placement:** Optional replacement for W3-MON on each independently approved channel. **Target:** 36 seconds; 74 spoken words.

**Verbatim spoken script:**

> Comparing auto quotes? Start with three things: coverage names, dollar limits, and listed deductibles. TDI says your policy's declarations page summarizes those details. Keep the actual pages private. On a blank sheet, write: Which lines are different, and what do those differences mean? You do not have to understand every term before asking. Please do not send policy pages or identifying numbers through social messages. One general question is enough to start a conversation.

**Shot and caption plan:**

- **0–7 seconds:** Eye-level medium staff shot addressing camera. Optional unspoken title above the subtitle zone: “Compare three lines.” Exact speech/subtitles: “Comparing auto quotes? Start with three things: coverage names, dollar limits, and listed deductibles.”
- **7–12 seconds:** Overhead cut to handwritten cards “Coverage names,” “Limits,” “Deductibles,” retaining authentic staff audio. Exact speech/subtitles: “TDI says your policy's declarations page summarizes those details.”
- **12–20 seconds:** Staff hand sets down a blank sheet and points to the question card; no filled personal information. Exact speech/subtitles: “Keep the actual pages private. On a blank sheet, write: Which lines are different, and what do those differences mean?”
- **20–27 seconds:** Return to medium staff shot with relaxed framing, no sales gesture or phone graphic. Exact speech/subtitles: “You do not have to understand every term before asking.”
- **27–36 seconds:** Same shot for privacy boundary and close; end on speaker, not a contact form. Exact speech/subtitles: “Please do not send policy pages or identifying numbers through social messages. One general question is enough to start a conversation.”

**Caption/recording delivery:** Split these exact segment words into readable two-line cues synchronized to the actual spoken words within the shot windows. Cream text on an opaque dark-green panel, middle-lower safe area clear of platform buttons. Retain “TDI” as spoken. Planned natural pauses make the 36-second target. Measure the authentic take and accept only 25–40 seconds; trim silence, not required script wording, and rerecord if needed. Check closed captions and burned-in captions against the verbatim script before approval.

**Source support:** TDI's declarations-page summary and shopping questions. [1] [2]

### W3-VIDEO-2 — proposed Sunday, December 13

**Hook:** What confirms the new start date? **Destination:** D4. **Reply:** R4. **Placement:** Optional replacement for W3-SUN on each independently approved channel. **Target:** 38 seconds; 76 spoken words.

**Verbatim spoken script:**

> Thinking about changing auto policies? Ask when the current policy ends and when the new coverage actually begins, including any applicable time. TDI says not to cancel your current policy until you get your new policy or a written statement proving coverage. A quote alone is not that confirmation. Ask: What confirms the new effective date before cancellation? Keep documents and policy numbers out of comments and social messages. Confirm next-step timing directly with the team.

**Shot and caption plan:**

- **0–10 seconds:** Medium staff shot, then simple cut to “Current policy ends?” and “New coverage begins?” cards. Optional unspoken title: “Confirm, do not assume.” Exact speech/subtitles: “Thinking about changing auto policies? Ask when the current policy ends and when the new coverage actually begins, including any applicable time.”
- **10–21 seconds:** Return to staff for the full TDI sentence, then show “Written confirmation?” card. No document props. Exact speech/subtitles: “TDI says not to cancel your current policy until you get your new policy or a written statement proving coverage. A quote alone is not that confirmation.”
- **21–28 seconds:** Close-up educational question card with authentic voice retained. Exact speech/subtitles: “Ask: What confirms the new effective date before cancellation?”
- **28–38 seconds:** Medium staff shot for privacy boundary and close. No Sunday availability implication. Exact speech/subtitles: “Keep documents and policy numbers out of comments and social messages. Confirm next-step timing directly with the team.”

**Caption/recording delivery:** Repeat the exact segment wording as subtitles synchronized to recorded words, in readable two-line cues on a cream-on-dark-green panel within the middle-lower safe area. Shot windows include natural pauses. Measure the final authentic take and accept only 25–40 seconds. Rerecord rather than speed up or drop the written-coverage sentence. Check burned-in and closed captions, including “effective date” and “written statement,” before approval. Educational cards contain no actual dates, customer timeline or cancellation request. The script does not establish coverage.

**Source support:** Written coverage confirmation before cancellation; dates and applicable times are questions to confirm with the relevant insurer. [2]

## Optional three-frame Story — substitute, not extra volume

**ID:** W3-STORY. **Proposed day:** Friday, December 11. **Hook:** What does that quote amount describe? **Destination:** D3. **Reply:** R3. **Gates:** G1–G7 and G9.

One Instagram Story sequence may replace the Friday Instagram W3-FRI acquisition placement. Do not run the Friday IG feed acquisition post alongside it by default. Facebook keeps its independently approved placement. Parent accounts for the substitution and daily capacity, including other Stories, before release. Each frame is six seconds. Photos require new authentic capture and approval; no assets supplied.

### Frame 1 — exact on-screen copy

> What does the amount on your auto quote describe?
> The policy total, an initial payment, or an installment?

**Visual:** New authentic office close-up of a cream “Payment questions” card. No amount or customer page. Green overlay with a small amber rule, within Story safe areas.

**Alt text:** A payment-question card introduces the question of what a quoted amount describes.

### Frame 2 — exact on-screen copy

> Ask about the policy period, total quoted premium and payment schedule.
> TDI also suggests asking whether paying in advance changes the price. Ask; do not assume.

**Visual:** New authentic blank question sheet with three headings only. Large readable overlay, no pricing graphic.

**Alt text:** A blank question sheet lists policy period, total quoted premium and payment schedule.

### Frame 3 — exact on-screen copy

> Save the question, not a screenshot of your policy.
> Keep documents and account details out of comments and social messages.
> Read our comparison guide.

**Visual:** New authentic office close-up of a closed plain notebook. No person or personal material. **Approved link-sticker label:** “Comparison guide.” **Sticker destination:** D3, only after G3 verification.

**Alt text:** A closed notebook accompanies a reminder to keep policy and account information private.

No poll, question box or document-request sticker. Hold the whole sequence if the guide or sticker fails verification; do not imply an unverified bio link. Source support for the advance-payment question: [2]

## Saturday, December 12 — conditional local-engagement prompt

**ID:** W3-SAT. **Eligibility:** Only if parent confirms no existing award/community commitment occupies the placement and both channels have capacity. Otherwise omit entirely; never replace a committed award with this prompt. **Hook:** A small check before a community outing. **Reply:** R5. **Gates:** G1, G2, G6–G9.

**Destination:** On-platform discussion only; no external destination is needed. D5 is solely a verified private-contact moderation fallback, not an event listing or promised public link.

### Facebook — exact copy, 140 words

> Center and Shelby County neighbors: where do you check the official details before heading to a community event?
>
> One useful habit is to check the organizer's own information for the date, location and any instructions before leaving. If accessibility or entry details matter to your plans, ask the organizer rather than guessing from an old flyer.
>
> If you have a helpful answer, share the name of an official public information source and what you check there. Please skip private addresses, personal contact details, children's information and photos of people who have not agreed to be shared.
>
> This is a place to exchange a practical habit, not an event calendar. We are not announcing an event, changed hours or a closure. Confirm any current details with the organizer. A reliable starting point can be useful to someone making their own plans.

### Instagram — exact copy, 78 words

> Center and Shelby County neighbors: where do you check official details before a community outing?
>
> Check the organizer's own information for the date, location and instructions. Ask the organizer about accessibility or entry questions rather than guessing from an old flyer.
>
> Share an official public source's name and what you check there—not private addresses, children's information or personal contact details.
>
> This is a practical-habit prompt, not an event announcement. Confirm current details with the organizer before making plans.

**Visual brief:** New authentic desk photo of a blank cream card handwritten “Check the organizer's details.” No event flyer, award graphic, community partner, school logo, child, street scene or implied local happening. No asset supplied.

**Alt text:** A handwritten card reminds readers to check details with the event organizer.

**Evidence:** Original timeless process suggestion and open question only. No factual claim about any event, organizer, award, closure, office hours or local condition. No external posts consulted.

## Privacy-safe response templates — exact wording

Use the relevant template only after the factual/contact checks in G3, G5 and G9. Do not append requests for documents, identifiers, private addresses or account details. Replies do not establish coverage or promise timing.

### R1 — Comparing coverage lines

> A useful first question is which coverage lines, limits or deductibles differ. Please keep the actual pages and identifying information out of comments and social messages. The team can explain the next step in a direct conversation; ask how to handle any documents privately.

**Destination:** D1 for the guide; verified D5 only for arranging contact.

### R2 — Driver or car-use question

> That is a question to discuss directly, not something we can determine from a comment. Please do not post names, driving records, vehicle details or policy pages here or in social messages. Ask the team how to confirm the driver and use information privately, and what the next step should be.

**Destination:** D2 for preparation; verified D5 only for arranging contact.

### R3 — Price, payments or comparing amounts

> It helps to ask what policy period the amount covers, which amount is the total quoted premium and how the payment schedule works. We cannot determine your terms from a comment. Please keep amounts, account details and documents private, and ask the team to explain the actual quote in a direct conversation.

**Destination:** D3 for the guide; verified D5 only for arranging contact.

### R4 — Effective date or cancellation

> Please confirm the actual end and start details with the relevant insurer, including any applicable time and the written confirmation of new coverage. TDI advises getting the new policy or a written statement proving coverage before canceling the current one. A comment or social message does not confirm coverage. Please keep policy numbers and documents private.

**Destination:** D4 for the guide; verified D5 only for arranging contact. **Source:** [2]

### R5 — Community-prompt reply

> Thank you for sharing a useful way to check. Please stick to official public sources and leave out private addresses, personal contact information and children's details. Anyone planning an outing should confirm the current information directly with the organizer.

**Destination:** No link needed; do not endorse or repeat unverified current event details.

### R6 — Social DM asking to send documents

> Thanks for reaching out. Please do not send policy pages, identification, account information or other personal documents through social messages. A general question about comparing quotes is enough here. Use our verified website contact route to arrange the next step, and ask the team how any needed information should be handled privately and when to expect that next step.

**Destination:** Verified D5 only. Do not request files in the DM or claim it is a secure document channel.

### R7 — Public disclosure of personal information

> For your privacy, please remove the personal information from this comment. We will not repeat it here. Please do not add documents or identifying details in social messages. Use the verified website contact route to ask how to handle your question privately.

**Moderation:** Do not quote, screenshot, forward or copy the disclosed data into notes. Use only authorized moderation controls; ask parent or authorized staff to handle hiding/removal under their policy if needed. Do not promise deletion from every system. **Destination:** Verified D5 only.

### R8 — Request for savings or guarantees

> We cannot promise a lower price, a particular coverage result or an effective date. A useful next step is to ask about the coverage details, payment terms and timing for the actual quotes. Please keep personal documents out of comments and social messages, and confirm policy-specific answers directly with the team and relevant insurer.

**Destination:** D1 for general preparation; verified D5 only for arranging contact.

### R9 — Immediate help or office timing

> A social reply does not establish coverage or confirm an effective date. Please use the verified contact route and ask the actual team to confirm availability and next-step timing. If your question concerns current policy status, ask the relevant insurer directly. Please do not post policy numbers or documents here.

**Destination:** Verified D5 only. No invented holiday hours, availability or response deadline.

## Measurement boundary

Parent may document the page/source, attempted contact and real qualified new-business conversations through already authorized systems. A click, save, follower or comment is not a lead. Accepted forms count only if separately verified. No tracking configuration changes or artificial submissions were made or authorized by this bundle.

## References

Both official TDI pages were read November 16, 2026 and need recheck close to release. Only these auto sources support insurance facts here. No small-business, workers' compensation or COI source claims are used. Source citations and production metadata are not extra text to paste into the exact channel bodies above.

[1]: https://www.tdi.texas.gov/pubs/consumer/cb020.html "Texas Department of Insurance — Automobile insurance guide"
[2]: https://www.tdi.texas.gov/consumer/auto-insurance-shopping-guide.html "Texas Department of Insurance — How to shop smart for auto insurance"
