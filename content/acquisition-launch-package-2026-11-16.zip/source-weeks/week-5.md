# Week 5 — December 21–27, 2026

**Theme:** Easy preparation before year-end; privacy and low-pressure human help

**State:** Review-ready copy only. Nothing is scheduled, published, released or recorded. Proposed days are editorial slots, not capacity-approved placements; the parent assigns all times in America/Chicago.

The four independent questions are choosing a useful question, keeping personal details out of a first message, preparing without arranging a conversation today, and choosing the right help route. This is not a date-shifted set of auto, rural-property or business sales posts. Preparation suggestions are original editorial prompts, not coverage advice or a claim that TDI approves Morrison's process.

Week 5 only. No website files, images, assets, external posts, provider drafts, schedules or delegated agents created. Staff videos await authentic recording. Proposed days are editorial slots, not approved calendar placements.

## Release and capacity holds

- Current approval is required for the exact copy, channels, authentic media and final placement. This bundle grants no scheduling, publishing, outreach, review-solicitation or automation authority.
- Parent assigns times only after fresh per-channel inventory includes all active, already-published, approved-library and reserved placements. Count Facebook and Instagram independently; maximum two per channel per local day, with a total weekly target of 7–10 per channel only where capacity genuinely permits. This assignment has not checked inventory.
- Preserve Tuesday five-school sports, Thursday fishing, all committed awards/community placements and the review-ready library. Do not invent future game, catch, award, event or holiday information; do not remove existing placements to fit this bundle.
- Planned /start-here, /prepare-for-a-conversation and /what-to-expect remain unverified and not live for this handoff. Verify the actual exact public content and destination metadata on both public hostnames before activating linked copy. Hold rather than silently substitute or pretend a page is live.
- For Instagram, verify the real profile website route and named page navigation before using the exact caption CTA. Caption URLs are not treated as clickable; no profile-link change is authorized here.
- Recheck the narrow TDI declaration-page fact and all destination links close to release. The privacy, preparation and timing prompts are original editorial guidance requiring staff review, not TDI coverage determinations.
- No office holiday hours or closures are announced. Normal posted weekday hours do not establish December 21–27 availability. Confirm any reader's next-step timing directly; verify any separate hours announcement before publishing it.
- Use only newly staff-recorded or genuinely authentic, rights-cleared agency photos/footage after approval. Obtain staff consent, remove customer information, keep screens and paperwork blank, and avoid identifying customers or third parties. No assets are supplied or generated here.
- GBP candidates must remain Updates with an authentic photo and complete visible body under 1,500 characters, with no phone, URL, domain or hashtags. A Learn more destination belongs only in a supported separate CTA field. If the tool cannot separate it, hold; no URL-to-button exception is approved.
- LinkedIn stays copy-only on manual hold. Recheck the actual account, the established 50-plus follower threshold and explicit approval; meeting a follower threshold alone does not authorize posting.
- Videos and the optional Story are substitute formats for named acquisition placements, not extra FB/IG volume. Saturday is a conditional reserve only if there is no committed award/community post and capacity and exact-copy approval both pass.
- After any separately authorized activation, the parent must independently read back exact provider text, media, CTA, channel, date/time/timezone and status, then distinguish scheduled/PENDING from published and inspect accessible live output. No activation or provider readback has occurred in this task.

## Destination status

### `/resources/car-insurance-quote-checklist-center-tx`

**Target:** [https://morrison-ins.net/resources/car-insurance-quote-checklist-center-tx](https://morrison-ins.net/resources/car-insurance-quote-checklist-center-tx)

**Status:** existing live per production brief

Recheck the exact public guide, mobile rendering and link/preview before use. Existing live status is supplied by the parent; this assignment did not perform a new production-site verification.

### `/prepare-for-a-conversation`

**Target:** [https://morrison-ins.net/prepare-for-a-conversation](https://morrison-ins.net/prepare-for-a-conversation)

**Status:** planned not verified live

Hold every linked placement until the parent verifies the exact public utility page, its no-data-collection checklist behavior, print layout and destination-specific metadata. A preview, push or generic HTTP 200 is not a public release.

### `/what-to-expect`

**Target:** [https://morrison-ins.net/what-to-expect](https://morrison-ins.net/what-to-expect)

**Status:** planned not verified live

Hold linked placements until the parent verifies the exact public page and staff approves the first-message, privacy and handoff wording. Do not promise staff availability or response speed.

### `/start-here`

**Target:** [https://morrison-ins.net/start-here](https://morrison-ins.net/start-here)

**Status:** planned not verified live

Hold linked placements until the parent verifies the exact public situation-routing page and all existing-customer, claim and contact routes.

## Preserved weekly lanes

**Tuesday, 2026-12-22 — Existing five-school sports.** Preserve; separate near-delivery research and approval. No sports copy or future results written here.

**Thursday, 2026-12-24 — Existing fishing.** Preserve; separate near-delivery research and approval. No fishing report or future conditions written here.

**Saturday, 2026-12-26 — Committed award/community placement, if any.** Commitment status unknown in this assignment. Preserve any commitment; the conditional reserve below cannot displace it.

Four acquisition pairs plus the preserved Tuesday/Thursday anchors and a genuinely available Saturday lane can form seven daily placements per channel; this is not a verified inventory count. The 7–10 target is not a reason to displace existing approved content, exceed two per channel/day or add every optional format. GBP and LinkedIn remain separate held candidates.

## Four independent Facebook/Instagram topic pairs

### Monday, 2026-12-21 — Which one question would make a conversation useful?

**ID:** W5-MON

**Hook:** Start with one question, not a stack of paperwork.

**Proposed day only:** Monday; time unassigned, subject to fresh capacity.

**Destination:** `/resources/car-insurance-quote-checklist-center-tx` — existing live per brief recheck required

**Supporting utility:** `/prepare-for-a-conversation` remains planned and unverified; it is not the caption destination.

#### Facebook — exact copy, 139 words

What is the one insurance question you would like to understand before the year ends? It can be small: a word on a renewal, a date you want to confirm, or what information to have nearby when you talk with someone.

Write that question on a blank sheet and leave room for the answer. If it is an auto question, TDI notes that the declaration page summarizes your coverages, dollar limits and deductibles. You can keep that page nearby for your own reference; please do not post a photo of it here.

Our existing auto conversation checklist is a useful starting point: https://morrison-ins.net/resources/car-insurance-quote-checklist-center-tx

You do not have to turn this into a whole paperwork project. Start with what you want explained, then ask the team what would be useful next. Keep policy numbers and personal details out of comments.

#### Instagram — exact copy, 82 words

What is one insurance question you would like explained before year-end? Write it on a blank sheet and leave room for the answer.

For an auto question, TDI says the declaration page summarizes coverages, dollar limits and deductibles. Keep it nearby for your own reference, not in a public photo.

From our profile’s website link, find the auto quote checklist in Resources. Start with one question; ask the team what would be useful next. No policy numbers or personal details in comments.

**Authentic visual/filming brief:** Authentic staff-taken 4:5 still at a tidy Morrison desk. Photograph a plain cream sheet with only the editorial heading ‘One question’ and three empty lines; green pen beside it. No real question, policy, envelope, screen, calendar or identifiable customer material in frame. Warm natural light, plain clothes if hands appear, no suits or carrier signage. This is a preparation prop, not a customer document. No image created in this task.

**Draft alt text:** A blank question sheet and green pen on a tidy desk, with space to write a question and answer.

**Reply templates:** GENERAL, POLICY_DETAIL, DOCUMENT; exact wording appears at the end of this bundle.

**Source links:** [https://www.tdi.texas.gov/pubs/consumer/cb020.html](https://www.tdi.texas.gov/pubs/consumer/cb020.html) · [https://morrison-ins.net/resources/car-insurance-quote-checklist-center-tx](https://morrison-ins.net/resources/car-insurance-quote-checklist-center-tx)

**Verified factual support:** TDI’s declaration-page description supports the narrow auto-policy sentence in both captions. No other coverage claim is made. [1]

**Release/recheck/approval gates:**

- Approve the TDI paraphrase and privacy wording; recheck the actual official source before release.
- Recheck the existing guide and actual Instagram Resources navigation; do not link the planned supporting page until verified.
- Authentic media approval and fresh separate FB/IG capacity required. Video W5-V1 may replace this format, not add another acquisition placement.

### Wednesday, 2026-12-23 — What can I leave out of a first message?

**ID:** W5-WED

**Hook:** A first message can explain the topic without exposing the paperwork.

**Proposed day only:** Wednesday; time unassigned, subject to fresh capacity.

**Destination:** `/what-to-expect` — planned not verified live

#### Facebook — exact copy, 133 words

What belongs in a first message—and what can stay off social media?

A general topic is enough to start: “I have a home insurance question. What is the best way to begin?” You can also say whether you are asking about a new decision or help with something you already have. That gives the conversation a direction without putting your paperwork on display.

Please leave out policy numbers, driver’s license details, birth dates, VINs and photos of documents. Do not send those through comments or social messages. Before sharing paperwork, ask the team how it should be provided.

Our what-to-expect page explains the first-message approach: https://morrison-ins.net/what-to-expect

It is fine to begin with a question about the process itself. You can ask what happens next and confirm timing directly with the person helping you.

#### Instagram — exact copy, 84 words

What can stay out of your first message? Your policy number, driver’s license details, birth date, VIN and document photos. Please do not put them in comments or social messages.

A general topic works: “I have a home insurance question. What is the best way to begin?” Before sharing paperwork, ask the team how to provide it.

From our profile’s website link, choose What to expect. You can start by asking about the process and confirming next-step timing, without putting your paperwork on display.

**Authentic visual/filming brief:** Authentic staff-taken 4:5 photo of an approved staff member at a cleared desk holding an unmarked closed folder, with a separate cream card reading only ‘Start with the topic.’ Natural expression and ordinary work clothes; frame out all monitors, forms, desk-name plates and background customer identifiers. Do not stage a customer exchange or imply this is a secure document channel. No image created in this task.

**Draft alt text:** A staff member holds a plain closed folder beside a card that says Start with the topic.

**Reply templates:** GENERAL, SOCIAL_MESSAGE, DOCUMENT, POLICY_DETAIL; exact wording appears at the end of this bundle.

**Evidence:** Original editorial privacy and first-message prompts; no insurance-coverage claim. Destination is planned, not an independently verified public source.

**Source scope:** Original editorial prompts; no external insurance factual claim. Planned destinations are not evidence of public release.

**Release/recheck/approval gates:**

- Staff must approve the real document-handoff language; do not call comments, DMs, general forms or ordinary email secure.
- Hold until /what-to-expect is verified public and Instagram navigation actually exists.
- Authentic staff consent/media approval and fresh FB/IG capacity required. Video W5-V2 may replace this format, not add another acquisition placement.

### Friday, 2026-12-25 — Can I get ready without arranging a conversation today?

**ID:** W5-FRI

**Hook:** Preparing a question does not have to become today’s appointment.

**Proposed day only:** Friday; time unassigned, subject to fresh capacity.

**Destination:** `/prepare-for-a-conversation` — planned not verified live

#### Facebook — exact copy, 142 words

Can you get ready for an insurance conversation without arranging it today? Yes: start with a note for yourself, not a message you feel you have to send.

Try three short lines: “My topic is…” “The part I want explained is…” “The next step I want to ask about is…” Keep the note private and leave identifying details out. You can set it aside and return to it when it is useful.

Our preparation page gives you a place to organize those general questions: https://morrison-ins.net/prepare-for-a-conversation

If you already have a deadline, share the date when you contact the team and confirm next-step timing directly. This post is not an office-hours announcement.

You are allowed to ask what information is needed before gathering everything. A useful question is a reasonable place to begin, and it does not have to become a decision today.

#### Instagram — exact copy, 84 words

Want to prepare without arranging a conversation today? Make a private note:

“My topic is…”
“The part I want explained is…”
“The next step I want to ask about is…”

From our profile’s website link, choose Prepare for a conversation. Keep identifying details out of comments and social messages.

If you have a deadline, share the date when you contact the team and confirm timing directly. This is not an office-hours announcement. You can begin with a question about the process, not a decision.

**Authentic visual/filming brief:** Authentic staff-taken 4:5 close-up of a blank cream notepad on a clear table. Only the three generic sentence starters from the caption appear; no filled answers, personal dates, document details or holiday-hours sign. Green pen and small amber accent, without seasonal claims or staged customer material. No image created in this task.

**Draft alt text:** A notepad with three unfinished prompts about a topic, an explanation and a next step.

**Reply templates:** GENERAL, TIMING, POLICY_DETAIL; exact wording appears at the end of this bundle.

**Evidence:** Original private-note preparation prompts; no claim about December 25 opening, closure, availability, response time or coverage.

**Source scope:** Original editorial prompts; no external insurance factual claim. Planned destinations are not evidence of public release.

**Release/recheck/approval gates:**

- Hold until the preparation page is verified public, ungated and free of personal-data entry or collection.
- Keep the copy independent of any holiday-hours claim. Actual deadlines and availability must be discussed directly; do not imply the office is open or closed.
- Approve the exact copy, authentic photo and real Instagram navigation, then check separate FB/IG capacity.

### Sunday, 2026-12-27 — Which help route fits my question?

**ID:** W5-SUN

**Hook:** Choose the situation first; the paperwork can wait.

**Proposed day only:** Sunday; time unassigned, subject to fresh capacity.

**Destination:** `/start-here` — planned not verified live

#### Facebook — exact copy, 145 words

Which starting point fits the question you have right now?

Maybe you are comparing a renewal, trying to describe how a property is used, or figuring out what to ask about business paperwork. Maybe you already have insurance and need help finding the right contact for an existing policy or claim. Those are different conversations; you do not need to squeeze them into the same first message.

Our start-here page lets you choose the situation that sounds closest: https://morrison-ins.net/start-here

If none fits neatly, a plain question works: “I am not sure which route to use. Can you point me to the right starting place?”

Keep your first message general. Leave policy numbers, claim details and document photos off social media, then ask the team what information belongs in the next step. Choosing a route is a way to begin asking, not a commitment to buy.

#### Instagram — exact copy, 85 words

Which starting point sounds like your question: comparing a renewal, a property-use question, business paperwork, or help with an existing policy or claim?

From our profile’s website link, choose Start here and pick the situation that fits. Not sure? Ask: “Can you point me to the right starting place?”

Keep the first message general. No policy numbers, claim details or document photos in comments or social messages. Ask the team what belongs in the next step. Choosing a route is not a commitment to buy.

**Authentic visual/filming brief:** Authentic staff-taken 4:5 overhead photo of four cream cards on a clear desk, reading ‘Renewal question,’ ‘Property use,’ ‘Business paperwork’ and ‘Existing help.’ No customer documents or logos from other businesses. Include a green pen pointing between cards rather than at a recommended insurance product. This is an editorial routing prop, not evidence of a customer outcome. No image created in this task.

**Draft alt text:** Four plain cards list renewal question, property use, business paperwork and existing help.

**Reply templates:** ROUTE, EXISTING_HELP, POLICY_DETAIL, DOCUMENT; exact wording appears at the end of this bundle.

**Evidence:** Situations come from the approved utility-page production brief, not coverage findings or contractual promises. /start-here is not yet verified live.

**Source scope:** Original editorial prompts; no external insurance factual claim. Planned destinations are not evidence of public release.

**Release/recheck/approval gates:**

- Hold until the exact public routing page and its existing-help/contact destinations are verified.
- Staff must approve routing language without promising a licensed review, response time, policy acceptance or claim outcome.
- Optional Story W5-STORY may substitute for this Instagram placement only after confirmed capacity; do not add it on top of the pair.

## Two GBP Update candidates

The following visible-body blocks contain no phone number, URL, domain or hashtags. Destination URLs are metadata outside those blocks, not instructions to paste links into the body. No photo, draft or CTA preview exists yet.

### W5-GBP-1 — A small private preparation note

**Proposed day only:** Monday, 2026-12-21; time unassigned

**Type/status:** Update; hold for approval release authentic photo and capacity

**Hook:** One question is a useful place to start.

#### Exact visible body — 657 characters including line breaks

What would you like explained before year-end? Start with one general question on a private sheet of paper. It might be a term you want explained, information you want to have nearby, or the next step you want to ask about.

Leave space for an answer rather than trying to gather every document at once. Keep policy numbers, identifying details and document photos out of public comments and social messages. Before sharing paperwork, ask the team how to provide it.

You can begin by asking about the process itself. If there is a deadline, discuss the date and confirm next-step timing directly. This update does not announce office hours or availability.

**Separate CTA metadata:** Learn more → `/prepare-for-a-conversation` → https://morrison-ins.net/prepare-for-a-conversation

Supported separate CTA field only; never append this URL to the visible body or composer text without separately approved method.

**Authentic image brief:** Have an approved Morrison staff member take a real horizontal 4:3 desk photo with a blank cream preparation sheet headed ‘My question’ and a green pen. No filled answers, personal data, screens, paperwork, customers, generated imagery or stock photo. Capture two crops on site for later selection; no image made in this task.

**Draft alt text:** A blank preparation sheet headed My question with a green pen on a clear desk.

**Reply templates:** GENERAL, DOCUMENT, TIMING; exact wording appears at the end of this bundle.

**Evidence:** Original editorial preparation prompt; no insurance fact or opening-hours claim requiring a TDI citation.

**Source scope:** Original editorial prompts; no external insurance factual claim. Planned destinations are not evidence of public release.

**Release/recheck/approval gates:**

- Authentic image, accurate final alt text and staff approval required.
- Verify /prepare-for-a-conversation public release and separate CTA rendering with the full body intact; if separate CTA is unsupported, hold.
- Recheck exact visible-body character count including line breaks and ensure no phone, URL, domain or hashtags. Parent checks GBP and total calendar capacity independently.

### W5-GBP-2 — A first message without private documents

**Proposed day only:** Wednesday, 2026-12-23; time unassigned

**Type/status:** Update; hold for approval release authentic photo and capacity

**Hook:** Explain the topic, not the identifying details.

#### Exact visible body — 656 characters including line breaks

What belongs in a first message? A general topic and a question about where to begin. For example: “I have an insurance question and would like to know the best next step.” You can say whether this is a new decision or help with something you already have.

Keep policy numbers, driver’s license details, birth dates, VINs, claim details and document photos out of comments and social messages. Ask the team how paperwork should be provided before sending it.

You do not need to know the right insurance term to ask about the process. It is reasonable to ask what information would be useful and to confirm next-step timing during the actual conversation.

**Separate CTA metadata:** Learn more → `/what-to-expect` → https://morrison-ins.net/what-to-expect

Supported separate CTA field only; no URL in visible body or unapproved URL-to-button input.

**Authentic image brief:** A different genuine horizontal 4:3 Morrison photo: a consenting staff member holding an unmarked closed folder at a completely cleared desk. Frame out monitors, files, customer names and other businesses. Plain clothes and natural light; no staged client, stock/generated person, or suggestion that the photo shows an actual private consultation. No image made in this task.

**Draft alt text:** A staff member holds a plain closed folder at a cleared desk.

**Reply templates:** SOCIAL_MESSAGE, DOCUMENT, POLICY_DETAIL; exact wording appears at the end of this bundle.

**Evidence:** Original editorial first-message and privacy guidance. Staff must approve the actual handoff process; no claim that ordinary messages or email are secure.

**Source scope:** Original editorial prompts; no external insurance factual claim. Planned destinations are not evidence of public release.

**Release/recheck/approval gates:**

- Authentic staff consent, image review and accurate final alt text required.
- Hold until /what-to-expect is verified public and the separate Learn more CTA is verified without a URL appearing in body text.
- Recheck character count and prohibited body elements; fresh provider capacity and current exact-copy approval required.

## Two LinkedIn manual-hold candidates

### W5-LI-1 — A useful first message does not need private paperwork

**Proposed day only:** Wednesday, 2026-12-23; time unassigned; manual hold, copy only

**Hook:** Start with the topic and the next-step question.

**Destination:** `/what-to-expect`; planned, not verified public

#### Exact copy — 93 words

What makes a useful first message before year-end? Start with the topic and what you want explained—not a document attachment.

“I have a business paperwork question. What is the best way to begin?” gives the conversation a direction without exposing policy numbers or personal details. Before providing paperwork, ask the team how it should be shared.

Our what-to-expect page outlines that first-message approach: https://morrison-ins.net/what-to-expect

You can ask what information would be useful and confirm next-step timing directly. A first question does not have to be a decision, and social messages should stay general.

**Visual brief:** Text-only manual candidate. If an image is later approved, use an authentic blank-folder desk photograph, never real business paperwork or another business's identity. No image created or attached here.

**Reply templates:** GENERAL, SOCIAL_MESSAGE, DOCUMENT; exact wording appears at the end of this bundle.

**Evidence:** Original editorial prompt; no COI, contractual, coverage or workers' compensation claims.

**Source scope:** Original editorial prompts; no external insurance factual claim. Planned destinations are not evidence of public release.

**Release/recheck/approval gates:**

- Keep manual hold until actual account/follower gate and explicit current approval pass; follower count alone is not authority.
- Hold linked copy until /what-to-expect is verified public and staff approves document-handoff language.
- Parent assigns time only after fresh LinkedIn and overall inventory checks.

### W5-LI-2 — Choose the situation before gathering paperwork

**Proposed day only:** Sunday, 2026-12-27; time unassigned; manual hold, copy only

**Hook:** Different questions need different starting routes.

**Destination:** `/start-here`; planned, not verified public

#### Exact copy — 99 words

Which starting point fits the question on your list: a renewal comparison, property use, business paperwork, or help with an existing policy or claim?

Those are different conversations. Choosing the situation first can help you ask a clearer next-step question without sending documents through social media.

Our start-here page groups those starting routes: https://morrison-ins.net/start-here

If you are unsure, ask the team where to begin and what information would be useful. Keep identifying details out of comments and messages, and confirm timing in the actual conversation. This is a preparation step, not a promise about coverage, availability or an outcome.

**Visual brief:** Text-only manual candidate. An optional later authentic photo may show four generic routing cards, with no customer identity, filled paperwork or implied case result. No image created or attached here.

**Reply templates:** ROUTE, EXISTING_HELP, TIMING; exact wording appears at the end of this bundle.

**Evidence:** Routes are defined by the approved production brief; no coverage or contractual claim. Planned page remains release-held.

**Source scope:** Original editorial prompts; no external insurance factual claim. Planned destinations are not evidence of public release.

**Release/recheck/approval gates:**

- Manual hold: verify the actual LinkedIn account, established 50-plus follower threshold and separate current approval.
- Verify /start-here public release, exact routing content and existing-help destinations.
- Fresh LinkedIn/overall capacity and parent-assigned time required; no provider draft created here.

## Two authentic staff-recording scripts

These are verbatim scripts awaiting real staff recording, not generated staff, footage, voice-over or a finished video. Use the relevant topic pair’s exact FB/IG caption on the chosen channel. Each video replaces its named acquisition format; it does not add another placement. Target timing is an edit plan and must be measured against the real recording.

### W5-V1 — Start with one question.

**Proposed day only:** Monday, 2026-12-21; time unassigned

**Substitution:** W5-MON Facebook and/or Instagram visual format, channel by channel; reuse that channel's exact caption, not an additional post.

**Duration:** 34-second target; final real recording must be 25–40 seconds. 70 spoken words.

**Format:** Vertical 9:16, 1080x1920, real consenting Morrison staff member, quiet room tone and real staff voice; no generated face, voice, customer or testimonial.

**Destination:** `/resources/car-insurance-quote-checklist-center-tx` — https://morrison-ins.net/resources/car-insurance-quote-checklist-center-tx

#### Verbatim spoken script

What is one question you want explained before year-end? Write it on a blank sheet and leave room for the answer. You can ask what information would be useful before gathering a stack of paperwork. Keep policy numbers and document photos out of comments and social messages. If you want to talk, ask the team about the next step and confirm timing directly. Start with the question, not a decision.

#### Precise shot plan

**0–5 seconds.** Locked eye-level medium close-up. Staff member gently places a blank cream sheet in frame while looking toward the camera; no other person visible.

**Sound:** Staff speaks script opening; clean room tone, no music needed.

**Separate editorial overlay:** One question is a start.

**Subtitle cues:** 1–2

**Cut point:** Cut at the end of year-end?

**5–11 seconds.** Locked overhead B-roll of the same blank sheet and pen. Staff hand points to an empty line without writing personal information.

**Sound:** Continue the same authentic staff take under B-roll.

**Separate editorial overlay:** None; use the verbatim subtitles only.

**Subtitle cues:** 3–4

**Cut point:** Cut after answer.

**11–24 seconds.** Return to eye-level medium close-up, with only a plain closed folder at edge of desk. Staff speaks calmly; a small gesture on paperwork, no folder opened.

**Sound:** Continue the verbatim script; no extra spoken claims.

**Separate editorial overlay:** Keep personal details off social media.

**Subtitle cues:** 5–8

**Cut point:** Cut after messages.

**24–34 seconds.** Slightly tighter locked framing of same staff member; end on a relaxed expression, not a sales gesture.

**Sound:** Finish the complete script, preserving the final word and natural breath.

**Separate editorial overlay:** Ask about the next step.
Auto checklist: Resources

**Subtitle cues:** 9–11

**Cut point:** End after decision.; no added appointment or availability claim.

#### Verbatim subtitle cues — planned timing

1. **0–2.5s:** What is one question
2. **2.5–5s:** you want explained before year-end?
3. **5–8s:** Write it on a blank sheet
4. **8–11s:** and leave room for the answer.
5. **11–14s:** You can ask what information would be useful
6. **14–18s:** before gathering a stack of paperwork.
7. **18–21s:** Keep policy numbers and document photos
8. **21–24s:** out of comments and social messages.
9. **24–28s:** If you want to talk, ask the team / about the next step
10. **28–30.5s:** and confirm timing directly.
11. **30.5–34s:** Start with the question, not a decision.

Exact spoken words, cream text on a dark-green high-contrast strip, maximum two short lines per cue. Place captions in the middle-lower safe area, above bottom controls; keep the face and props clear. CTA overlay is separate from verbatim subtitles. Planned times are edit targets, not measured recording timestamps; re-time to the real take without changing words.

**Reply templates:** GENERAL, DOCUMENT, TIMING; exact wording appears at the end of this bundle.

**Evidence:** Script is original preparation guidance and contains no TDI factual claim. Reused Monday caption has its own TDI citation in the handoff.

**Source scope:** Original editorial prompts; no external insurance factual claim. Planned destinations are not evidence of public release.

**Release/recheck/approval gates:**

- Record a real consenting staff member; inspect every frame and background for identifiers. Do not use customer documents, synthetic staff or generated audio.
- Measure the genuine take and final export; final duration must be 25–40 seconds. Re-time captions to real speech, and preserve this script verbatim.
- Approve media and exact reused channel caption, verify the existing guide/profile navigation, and count this as a replacement on each chosen channel.

### W5-V2 — What can stay out of the first message?

**Proposed day only:** Wednesday, 2026-12-23; time unassigned

**Substitution:** W5-WED Facebook and/or Instagram visual format, channel by channel; reuse that channel's exact caption, not an additional post.

**Duration:** 36-second target; final real recording must be 25–40 seconds. 76 spoken words.

**Format:** Vertical 9:16, 1080x1920, real consenting Morrison staff member in ordinary work clothes, natural staff voice, quiet room tone; no synthetic staff or generated footage.

**Destination:** `/what-to-expect` — https://morrison-ins.net/what-to-expect

#### Verbatim spoken script

Not sure what to put in a first message? Start with the topic, like, ‘I have a home insurance question. What is the best way to begin?’ Keep policy numbers, birth dates, driver’s license details, VINs and document photos out of comments and social messages. Before sending paperwork, ask the team how to provide it. You can ask about the process first, then confirm next-step timing during the conversation. That is a useful place to start.

#### Precise shot plan

**0–4 seconds.** Locked eye-level medium close-up of staff member at cleared desk, hands visible and no device or document in use.

**Sound:** Authentic staff voice delivers opening question.

**Separate editorial overlay:** Start with the topic.

**Subtitle cues:** 1

**Cut point:** Cut after message?

**4–12 seconds.** Locked overhead view of a cream editorial card containing only ‘I have a home insurance question. What is the best way to begin?’ Staff hand gently sets it beside an unmarked closed folder.

**Sound:** Same real staff take continues under B-roll, quoting the generic prompt exactly.

**Separate editorial overlay:** None; use the verbatim subtitles only.

**Subtitle cues:** 2–4

**Cut point:** Cut after begin?

**12–25 seconds.** Return to medium close-up. Staff leaves the folder shut and makes one small open-hand gesture; no real file, screen or customer in frame.

**Sound:** Speak the full privacy list and document-handoff sentence without edits to meaning.

**Separate editorial overlay:** No personal details in comments or DMs.

**Subtitle cues:** 5–8

**Cut point:** Cut after it.

**25–36 seconds.** Locked slightly tighter framing. Staff finishes calmly; maintain space for captions and a brief final overlay while the sentence ends.

**Sound:** Finish the complete verbatim script; no invented response-time line or background conversation.

**Separate editorial overlay:** What to expect
Use the website link in our profile.

**Subtitle cues:** 9–11

**Cut point:** End after start.; no extra hours announcement.

#### Verbatim subtitle cues — planned timing

1. **0–4s:** Not sure what to put in a first message?
2. **4–6s:** Start with the topic, like,
3. **6–9s:** ‘I have a home insurance question.
4. **9–12s:** What is the best way to begin?’
5. **12–15s:** Keep policy numbers, birth dates,
6. **15–18.5s:** driver’s license details, VINs / and document photos
7. **18.5–21s:** out of comments and social messages.
8. **21–25s:** Before sending paperwork, / ask the team how to provide it.
9. **25–28s:** You can ask about the process first,
10. **28–32s:** then confirm next-step timing / during the conversation.
11. **32–36s:** That is a useful place to start.

Verbatim captions in high-contrast cream on green, maximum two short lines, above platform bottom controls and below the face. Keep the editorial card readable in its shot. CTA is a separate overlay, not invented speech. Re-time these target cues to the actual staff recording; verify real speech and final duration.

**Reply templates:** SOCIAL_MESSAGE, DOCUMENT, POLICY_DETAIL, TIMING; exact wording appears at the end of this bundle.

**Evidence:** Generic editorial first-message prompt, not a case story, testimonial, coverage conclusion or guarantee.

**Source scope:** Original editorial prompts; no external insurance factual claim. Planned destinations are not evidence of public release.

**Release/recheck/approval gates:**

- Obtain authentic staff consent and approve the practical document-handoff language. Use no customers or identifying material.
- Hold until /what-to-expect is public and the actual profile route exists; use the exact Wednesday channel caption as the post caption.
- Measure and re-time the real take; require a 25–40-second final export and verbatim subtitles. Count as a substitute per channel, with separate capacity and approval.

## Optional three-frame Story — substitute, not extra

**ID:** W5-STORY

**Proposed day only:** Sunday, 2026-12-27; time unassigned; optional substitute hold

**Hook:** Pick the starting point, not an insurance product.

**Substitution:** W5-SUN Instagram acquisition placement only. Do not run the Sunday IG feed caption plus this sequence as extra volume. Facebook remains separately subject to capacity.

**Destination:** `/start-here` — https://morrison-ins.net/start-here; planned, not verified live

### Frame 1 — 7 seconds

**Exact on-frame copy:**

> Which question is on your list?
> A renewal comparison
> Property use
> Business paperwork
> Existing policy or claim help

**Authentic visual brief:** Authentic vertical overhead staff photo of the four generic cream routing cards. No filled paperwork or customer details. Green/cream/amber styling; no generated asset.

**Draft alt text:** Four cards name different starting topics for an insurance question.

**Interaction:** None. Do not use a question box that invites personal policy or claim details.

### Frame 2 — 7 seconds

**Exact on-frame copy:**

> Not sure where to begin?
> Ask: ‘Can you point me to the right starting place?’
> Keep policy numbers, claim details and document photos off social media.

**Authentic visual brief:** Different authentic close crop of a cream card with the generic question only, beside a closed unmarked folder. Keep all background identifiers out.

**Draft alt text:** A general starting-place question beside a plain closed folder.

**Interaction:** None; no request for a private story or document.

### Frame 3 — 7 seconds

**Exact on-frame copy:**

> Choose a starting route.
> Ask what belongs in the next step.
> Confirm timing with the person helping you.
> Choosing a route is not a commitment to buy.

**Authentic visual brief:** Authentic staff photo of a green pen beside the blank routing cards, with a clean lower-middle area for an approved link sticker. No hours notice or appointment claim.

**Draft alt text:** A green pen beside plain routing cards on a clear desk.

**Interaction:** Use a Start here link sticker only if supported, approved and tested against the verified public /start-here page; otherwise hold this linked sequence.

**Exact sticker label:** Start here

**Reply templates:** ROUTE, POLICY_DETAIL, EXISTING_HELP; exact wording appears at the end of this bundle.

**Source scope:** Original editorial prompts; no external insurance factual claim. Planned destinations are not evidence of public release.

**Release/recheck/approval gates:**

- Optional substitute only; approve the complete three-frame sequence and remove the named IG acquisition feed placement from the proposal, not from a committed calendar without permission.
- Parent must verify actual Story accounting/provider behavior; count every provider placement conservatively. If the three frames cannot fit the daily cap, hold the sequence rather than treat it as free volume.
- Hold until /start-here is verified live, the supported sticker and exact target work, authentic photos are approved and privacy-safe replies are staffed without an availability promise.

## Saturday conditional community reserve

**ID:** W5-SAT-RESERVE

**Proposed day only:** Saturday, 2026-12-26; time unassigned

**Do not use unless the condition is verified:** Use only if fresh inventory and the parent's commitment record establish that no award/community placement is committed for Saturday, and separate channel capacity and approval pass. Otherwise omit this reserve entirely. It never replaces a committed award.

**Hook:** What small organizing habit would you pass along to a neighbor?

**Destination:** On-platform general community discussion only; no website or outside business destination, tag, outreach or collaboration implied.

### Facebook — exact copy, 124 words

For our neighbors in Center and Shelby County: what small organizing habit would you pass along to someone trying to finish the year with a shorter to-do list?

Maybe it is keeping one blank question sheet by the phone, writing the next step on a calendar, or putting a general reminder where the household can find it. Share the habit, not a photo of your paperwork. Please leave out addresses, account numbers, personal dates and anything that identifies someone else.

This is a place for practical ideas, not a request for policy details or a customer story. There is no need to name a business or another person. A small habit that makes the next question easier to remember is useful on its own.

### Instagram — exact copy, 76 words

Neighbors in Center and Shelby County: what small organizing habit would you pass along?

A blank question sheet by the phone, a calendar note, or a general household reminder can be a place to start. Share the habit, not a photo of paperwork. No addresses, account numbers, personal dates or someone else’s details.

We are asking for practical ideas, not policy information or customer stories. There is no need to name a business or another person.

**Authentic visual brief:** If approved, staff takes an authentic close-up of a blank household-style note sheet and pen on a clear table. No actual dates, address, customer identity, local-event signage or other business name. Do not reuse an award photo or imply an award winner. No image created here.

**Draft alt text:** A blank note sheet and pen with space for a general reminder.

**Reply templates:** COMMUNITY, DOCUMENT, POLICY_DETAIL; exact wording appears at the end of this bundle.

**Evidence:** A timeless general question addressed to the service area's neighbors, not a claim about a local event, schedule, business, award or holiday closure.

**Source scope:** Original editorial prompts; no external insurance factual claim. Planned destinations are not evidence of public release.

**Release/recheck/approval gates:**

- Committed award/community status must be checked first; unknown is not empty.
- No invented future award, winner, closure, event, collaboration or testimonial. Do not identify or tag customers, including Boles Feed.
- Approve exact copy and authentic media, verify separate channel capacity, and moderate identifying details without repeating them.

## Privacy-safe exact response templates

Use these only for real inbound comments or messages within the approved moderation process. They are not outbound outreach, a promise that someone is monitoring a holiday, a secure intake channel or a way to make an artificial lead. No customer identity is approved for public use.

### GENERAL

**Use when:** A reader asks where to begin without personal information.

**Exact reply:**

A general topic is a good place to start. Are you asking about a new decision or help with something you already have? Please keep policy numbers and personal details out of this thread. You can ask the team what information would be useful before gathering paperwork.

**Moderation boundary:** Do not ask for a phone number, address, date of birth, policy number, VIN, claim narrative or document upload in public or social messages. Do not turn this reply into an outreach lead.

### POLICY_DETAIL

**Use when:** A reader asks whether a specific situation is covered, accepted, cheaper or guaranteed.

**Exact reply:**

That needs a conversation about your own situation; we cannot determine coverage, price or an outcome in a comment. Please leave identifying details and documents out of this thread. Use the office’s published contact options and ask what information belongs in the next step.

**Moderation boundary:** Do not speculate, quote, promise savings, imply acceptance or claim licensed review occurred. Do not solicit detailed follow-up in a DM.

### DOCUMENT

**Use when:** Someone posts or offers a policy image, document or identifying details.

**Exact reply:**

Please remove the document or identifying details from this thread if you can. We will not repeat them here. Before sharing paperwork anywhere else, use the office’s published contact options to ask how it should be provided. Please do not resend it through social messages.

**Moderation boundary:** Do not quote, download into a content file, screenshot for a public example or repost the material. Follow the approved moderation/privacy process promptly; do not promise complete removal from the internet.

### SOCIAL_MESSAGE

**Use when:** A DM begins a private policy discussion or asks to send documents.

**Exact reply:**

Thanks for reaching out. Please keep this message to a general topic, such as an auto, property or business question, or existing-policy help. Do not send policy numbers, birth dates, license details, VINs, claim details or document photos here. Use the office’s published contact options to ask how to provide anything needed and to confirm next-step timing.

**Moderation boundary:** No claim that DMs, general intake forms or ordinary email are secure; no promise about availability, turnaround or outcome. No artificial lead submission.

### TIMING

**Use when:** A reader asks about December 21–27 opening hours, holiday closures, a response time or a deadline.

**Exact reply:**

This post does not confirm holiday hours, closures or response times. Please check the office’s current posted information and confirm next-step timing directly through its published contact options. If you have a deadline, mention the date during that conversation; please do not put personal documents or policy details here.

**Moderation boundary:** Do not repeat normal Monday–Friday hours as a holiday guarantee. Before any specific availability reply, staff must verify the actual day and approved announcement. Do not invent a closure or imply someone is monitoring today.

### ROUTE

**Use when:** A reader is unsure which situation route fits.

**Exact reply:**

You do not have to know the right insurance term. A general topic and whether this is a new decision or existing-policy help can guide the first question. Please keep identifying details off social media, then ask the team which starting route and information make sense for the next step.

**Moderation boundary:** Only send a utility-page link after its public release is verified. Do not make coverage or contractual conclusions from the selected route.

### EXISTING_HELP

**Use when:** An existing customer asks about policy service or a claim.

**Exact reply:**

For an existing-policy or claim question, use the contact instructions on your policy or the office’s published contact options to ask about the next step. Please do not put policy numbers, claim details or document photos in comments or social messages. This thread cannot confirm coverage, claim handling or an outcome.

**Moderation boundary:** Do not ask for public claim details, invent an insurer instruction, promise claim results or imply this thread is emergency or claims intake.

### COMMUNITY

**Use when:** Someone responds to Saturday's conditional general organizing prompt.

**Exact reply:**

Thank you for sharing a practical habit. Please keep the example general, without names, addresses, account details or photos of paperwork. A simple idea is useful without identifying another person or business.

**Moderation boundary:** Do not turn the comment into a testimonial, case story, review solicitation, customer tag or outside-business collaboration. No customer identity is approved for public use.

## Measurement and source handoff

Parent may draft attribution after release. Useful outcomes are relevant entry traffic, attempted contact, separately verified accepted forms and real qualified conversations; clicks or followers alone are not leads. This task makes no analytics, consent, Ads, GA4, GTM or CRM change and submits no test lead.

Checked source: November 16, 2026. Read the actual TDI auto guide, not a search snippet. Its “Deductibles and dollar limits” section says the declaration page contains a summary of coverages, dollar limits and deductibles. This supports only Monday’s narrow sentence. [1]

The parent corrected cb030.html to TDI's Workers' compensation guide. It is not a general small-business or certificate-of-insurance source and is not used here. No legal minimums, coverage conclusions, price predictions, savings, testimonials or case outcomes appear in this bundle.

All other questions and privacy/timing suggestions are original editorial prompts requiring staff approval of the real service process. They are not statements of coverage, contractual compliance or TDI endorsement. The existing guide is live per the supplied production brief; all new utility-page destinations remain release-held. No office holiday hours, closure, local event, game result, fishing condition, award winner or customer story was fabricated.

**Mechanical checks:** Four FB captions are 139, 133, 142 and 145 words; four IG captions are 82, 84, 84 and 85 words. LinkedIn candidates are 93 and 99 words. GBP bodies are 657 and 656 characters, including line breaks. Staff scripts are 70 and 76 words; their real durations remain unmeasured until recording. The Saturday reserve is 124 FB words and 76 IG words. Counts use whitespace-delimited words and include caption URLs as one word.

## References

[1]: https://www.tdi.texas.gov/pubs/consumer/cb020.html "Texas Department of Insurance — Auto insurance guide"
