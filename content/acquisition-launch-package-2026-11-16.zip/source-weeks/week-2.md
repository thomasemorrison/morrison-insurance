# Week 2 · November 30–December 6, 2026

**Theme:** Home/rural property use and changes worth discussing, not coverage conclusions. **Status:** Review-ready only. Proposed days below are not assigned times or scheduled posts. Author: Manus AI.

## Calendar protection and routing

Four acquisition topic pairs proposed for Monday, Wednesday, Friday and Sunday. Tuesday five-school sports and Thursday fishing remain existing separate anchors. Saturday remains an existing award/community commitment if present. This gives seven weekly placements per FB/IG if each preserved lane is present; the parent reconciles the actual calendar toward the brief's 7–10 total per channel, rather than adding more automatically.

Fresh read of scheduled, approved and queued content separately for Facebook and Instagram; maximum two posts per channel per local calendar day. Old review-ready library remains intact and uses capacity when assigned. Do not assume a free Facebook slot means Instagram is free.

- **2026-12-01 · Tuesday five-school sports:** Preserve the existing Center, Joaquin, Tenaha, Timpson and Shelbyville lane. Research close to delivery in its own workflow; no invented future scores, schedules or results in this bundle.

- **2026-12-03 · Thursday fishing:** Preserve the existing fishing lane; no new forecasts, catches, conditions or closures written here.

- **2026-12-05 · Saturday award/community:** Keep any committed award or community placement. The optional local prompt below is eligible only if no committed award/community content occupies that placement.

The two staff-video options and three-frame Story are format substitutes for a parent-selected acquisition placement, not extra volume. Only approved, authentic recorded video can replace its matching text/static placement. The Story replaces one selected scheduled acquisition placement for the selected channel; do not also publish that placement's feed caption on that channel merely because Stories do not appear in the feed.

GBP and LinkedIn are candidates, not additions to the FB/IG quota. LinkedIn remains manual-hold. Parent assigns times only after capacity and all gates pass.

`/start-here`, `/prepare-for-a-conversation`, and `/what-to-expect` are **not live until verified**. Primary Facebook copy that promises one of those pages is release-held. The complete existing-guide alternatives below avoid pretending a new page has shipped. The existing guide is [Home and rural-property background](https://morrison-ins.net/resources/farm-insurance-vs-homeowners-insurance), supplied as already live in the production brief; it still needs a public recheck before scheduling.

Link-bearing primary captions are held until the exact destination is live and the profile link actually reaches it. Each pair also contains complete no-profile-link fallback copy. No invented live bio link.

Only a separately verified Learn more button may carry a destination. Candidate text contains no phone, URL, domain, or hashtag. If the new destination is unreleased, use only the approved existing-guide fallback button or omit the button; never expose a dead new-page link.

## Four independent acquisition topic pairs

### Monday · 2026-11-30 · W2-MON

**Topic:** What happens inside the shed? Describe use rather than rely on a building label.

**Hook:** A building name is only the beginning.

**Useful question:** What is each separate building used for now, and has that use changed?

**Destination path:** `/resources/farm-insurance-vs-homeowners-insurance`. Existing live guide supplied in the production brief; recheck before use.

**Facebook — exact primary copy (131 words)**

```text
What happens inside the shed?

A building name is only the beginning. A detached space might hold garden tools, be a place for a personal hobby, or have a different use than it did last year. You do not have to decide what insurance category fits before asking a question.

For a first conversation, make a short private list: the building, what happens there now, and what has changed. Leave out serial numbers, addresses, values, and photos of your belongings when commenting online.

TDI notes that home coverages vary by company. Your own policy and a conversation with your agent matter.

Our home and rural-property guide is a general starting point, not an answer about your particular shed. Bring one use question, not your whole filing cabinet.

Read the guide: https://morrison-ins.net/resources/farm-insurance-vs-homeowners-insurance
```

**Instagram — exact primary copy (80 words) · actual profile destination must be verified**

```text
What happens inside the shed?

Try three short notes for yourself: the building, its current use, and anything that changed. A name like “workshop” does not explain whether it is a personal hobby space or used for something else.

You can bring that question without deciding an insurance category first. Open our home and rural-property guide through the profile link for a general starting point.

Keep addresses, belongings, and documents out of comments. One useful question is enough to begin.
```

**Instagram — complete no-profile-link fallback (75 words)**

```text
What happens inside the shed?

Try three short notes for yourself: the building, its current use, and anything that changed. A name like “workshop” does not explain whether it is a personal hobby space or used for something else.

You can bring that question without deciding an insurance category first. Save these three prompts for a conversation with your agent.

Keep addresses, belongings, and documents out of comments. One useful question is enough to begin.
```

**Authentic visual brief:** Authentic staff-made photo only after approval: an unfilled cream note card on a clear office desk, with the heading “Building / Current use / What changed.” Staff hand may point to the headings. No actual property photo or personal details; no claims that a shed pictured belongs to a customer. Green border and small amber underline; readable text with generous margins. This task supplies no image.

**Reply templates:** `general`, `coverage`, `documents`.

Official source: [1]. The practical prompts are original editorial wording; no policy-specific conclusion is made.

**Source boundary:** TDI's policy-specific guidance supports the explicit sentence in Facebook copy. Shed-use examples are editorial conversation prompts, not coverage rules.

**Item gates:** G1, G2, G4, G5, G6, G10 (defined below).

### Wednesday · 2026-12-02 · W2-WED

**Topic:** When is the change happening? Separate a repair, a planned change and a new use.

**Hook:** A plan and a completed change are different notes.

**Useful question:** Is the work planned, underway or finished, and will the space be used differently?

**Destination path:** `/prepare-for-a-conversation`. PRIMARY HOLD — not live until verified

**Existing-guide fallback:** `/resources/farm-insurance-vs-homeowners-insurance`. Use only the complete approved fallback caption or verified separate button; never silently swap a destination while keeping an inaccurate page promise.

**Facebook — exact primary copy (125 words)** · RELEASE HOLD

```text
Planning a repair or changing how a room is used? Start with the timeline, not a stack of paperwork.

On a private note, separate three things: what is planned, what is underway, and what is already finished. Then add whether the space will be used differently afterward. A roof repair and turning a room into a workspace are different questions to describe, not conclusions to make online.

Ask your agent: “What would you need to understand this change, and when should we talk?” Confirm the next step during that conversation rather than assuming a deadline or an answer.

Our preparation page offers general prompts you can use without entering personal information. Keep project addresses, contractor documents, and financial details out of comments.

Start here: https://morrison-ins.net/prepare-for-a-conversation
```

**Facebook — complete existing-guide fallback (123 words)**

```text
Planning a repair or changing how a room is used? Start with the timeline, not a stack of paperwork.

On a private note, separate three things: what is planned, what is underway, and what is already finished. Then add whether the space will be used differently afterward. A roof repair and turning a room into a workspace are different questions to describe, not conclusions to make online.

Ask your agent: “What would you need to understand this change, and when should we talk?” Confirm the next step during that conversation rather than assuming a deadline or an answer.

Our home and rural-property guide is a general starting point. Keep project addresses, contractor documents, and financial details out of comments.

Read the guide: https://morrison-ins.net/resources/farm-insurance-vs-homeowners-insurance
```

**Instagram — exact primary copy (83 words) · actual profile destination must be verified**

```text
A plan and a completed change are different notes.

If you are repairing a roof or changing a room's use, jot down: planned, underway, or finished. Then note what the space will be used for afterward. Keep this list private.

A useful question is: “What would you need to understand this change, and when should we talk?”

Our preparation page is available through the profile link. It offers general prompts, not a coverage decision. Please leave addresses and project documents out of comments.
```

**Instagram — complete no-profile-link fallback (81 words)**

```text
A plan and a completed change are different notes.

If you are repairing a roof or changing a room's use, jot down: planned, underway, or finished. Then note what the space will be used for afterward. Keep this list private.

A useful question is: “What would you need to understand this change, and when should we talk?”

Save these prompts for your next conversation. They help describe a change, not decide coverage. Please leave addresses and project documents out of comments.
```

**Authentic visual brief:** New authentic staff photo of three blank index cards headed “Planned,” “Underway,” and “Finished” on an office table. A fourth unfilled card reads “Will the use change?” No fabricated project dates, contractor paperwork or customer story. Cream cards, green lettering and one amber tab; no promotional product imagery.

**Reply templates:** `general`, `timing`, `documents`.

Official source: [1]. The practical prompts are original editorial wording; no policy-specific conclusion is made.

**Source boundary:** Original preparation prompts. No assertion that a repair or change triggers a particular policy requirement, deadline or coverage result.

**Item gates:** G1, G2, G3, G4, G5, G6, G10 (defined below).

### Friday · 2026-12-04 · W2-FRI

**Topic:** Who will use the space? Describe guests, stays and payment without labeling the answer.

**Hook:** “Someone will stay here” leaves a few useful questions open.

**Useful question:** Is a planned stay occasional or ongoing, and is any payment involved?

**Destination path:** `/what-to-expect`. PRIMARY HOLD — not live until verified

**Existing-guide fallback:** `/resources/farm-insurance-vs-homeowners-insurance`. Use only the complete approved fallback caption or verified separate button; never silently swap a destination while keeping an inaccurate page promise.

**Facebook — exact primary copy (129 words)** · RELEASE HOLD

```text
“Someone will stay here” can mean several different things.

If you are thinking about a guest room, a separate space, or letting someone stay for a while, describe the plan in plain language. Is it an occasional visit or an ongoing arrangement? Is any payment involved? Has the plan started, or are you still considering it?

Those are questions to bring privately to your agent, not a way to decide coverage from a social post. You do not need to share a guest's name, travel dates, address, or payment details here.

For an opening message, try: “I have a question about a planned change in who uses part of my property.” Then ask what information to bring and confirm next-step timing.

Our what-to-expect page explains the conversation handoff: https://morrison-ins.net/what-to-expect
```

**Facebook — complete existing-guide fallback (131 words)**

```text
“Someone will stay here” can mean several different things.

If you are thinking about a guest room, a separate space, or letting someone stay for a while, describe the plan in plain language. Is it an occasional visit or an ongoing arrangement? Is any payment involved? Has the plan started, or are you still considering it?

Those are questions to bring privately to your agent, not a way to decide coverage from a social post. You do not need to share a guest's name, travel dates, address, or payment details here.

For an opening message, try: “I have a question about a planned change in who uses part of my property.” Then ask what information to bring and confirm next-step timing.

For general background, read our home and rural-property guide: https://morrison-ins.net/resources/farm-insurance-vs-homeowners-insurance
```

**Instagram — exact primary copy (81 words) · actual profile destination must be verified**

```text
Thinking about someone staying in part of your property?

Describe the plan before trying to label it: occasional or ongoing, payment or no payment, already happening or still being considered. These are conversation prompts, not coverage answers.

A first message can be simple: “I have a question about who will use part of my property.” Ask what to bring and confirm next-step timing.

Our what-to-expect page is through the profile link. Keep guest names, travel dates, addresses, and payment details private.
```

**Instagram — complete no-profile-link fallback (82 words)**

```text
Thinking about someone staying in part of your property?

Describe the plan before trying to label it: occasional or ongoing, payment or no payment, already happening or still being considered. These are conversation prompts, not coverage answers.

A first message can be simple: “I have a question about who will use part of my property.” Ask what to bring and confirm next-step timing.

Save this wording for a private conversation. Keep guest names, travel dates, addresses, and payment details out of comments.
```

**Authentic visual brief:** Authentic staff-made office photograph of a blank notebook with one handwritten general question: “Who will use the space?” Keep the rest of the page empty. No staged guest scene, house keys with address labels, booking screenshots, rental listings or implied real customer case. Staff consent and clean background required.

**Reply templates:** `general`, `coverage`, `away_dates`, `documents`.

Official source: [1]. The practical prompts are original editorial wording; no policy-specific conclusion is made.

**Source boundary:** TDI separately discusses short-term rentals, but this copy does not restate or apply a coverage exclusion. Guest/payment prompts are editorial questions for a policy-specific conversation.

**Item gates:** G1, G2, G3, G4, G5, G6, G10 (defined below).

### Sunday · 2026-12-06 · W2-SUN

**Topic:** What is the land actually used for? Start with routines, not an acreage label.

**Hook:** A rural address is not the whole description.

**Useful question:** What happens on the land now: personal use, animals, growing, storage or an activity involving sales?

**Destination path:** `/start-here`. PRIMARY HOLD — not live until verified

**Existing-guide fallback:** `/resources/farm-insurance-vs-homeowners-insurance`. Use only the complete approved fallback caption or verified separate button; never silently swap a destination while keeping an inaccurate page promise.

**Facebook — exact primary copy (135 words)** · RELEASE HOLD

```text
A rural address is not the whole description of a property.

For a useful first conversation, think about what happens on the land now. Is it mainly a place to live? Do you keep animals, grow something for your household, store equipment, or have an activity that involves sales? You can describe more than one use without trying to decide which insurance label belongs on it.

Make a private list of the routines, any recent changes, and one thing you want to understand. Acreage by itself is not the question we are asking you to answer here, and this post cannot determine a policy fit.

Our start-here page offers a home and rural-property route for that first question. Keep exact locations, animal counts, equipment details, and documents off social media.

Choose your starting point: https://morrison-ins.net/start-here
```

**Facebook — complete existing-guide fallback (133 words)**

```text
A rural address is not the whole description of a property.

For a useful first conversation, think about what happens on the land now. Is it mainly a place to live? Do you keep animals, grow something for your household, store equipment, or have an activity that involves sales? You can describe more than one use without trying to decide which insurance label belongs on it.

Make a private list of the routines, any recent changes, and one thing you want to understand. Acreage by itself is not the question we are asking you to answer here, and this post cannot determine a policy fit.

Our home and rural-property guide offers general background for that first question. Keep exact locations, animal counts, equipment details, and documents off social media.

Read the guide: https://morrison-ins.net/resources/farm-insurance-vs-homeowners-insurance
```

**Instagram — exact primary copy (83 words) · actual profile destination must be verified**

```text
A rural address is not the whole description.

Try listing what happens on the land: living there, keeping animals, growing for your household, storage, or an activity involving sales. More than one use can go on your private list.

Then choose one question about a routine or a recent change. You do not have to assign an insurance label first.

Our start-here page has a home and rural-property route through the profile link. Keep exact locations, animal counts, equipment details, and documents private.
```

**Instagram — complete no-profile-link fallback (81 words)**

```text
A rural address is not the whole description.

Try listing what happens on the land: living there, keeping animals, growing for your household, storage, or an activity involving sales. More than one use can go on your private list.

Then choose one question about a routine or a recent change. You do not have to assign an insurance label first.

Save that question for a conversation with your agent. Keep exact locations, animal counts, equipment details, and documents out of comments.
```

**Authentic visual brief:** New authentic photograph of an unfilled staff-created paper checklist headed “What happens on the land?” with unchecked prompts “Daily use,” “Recent change,” and “One question.” Photograph at a cleared office desk. No aerial map, livestock counts, equipment inventory, branded supplier/customer identity or scenic stock image presented as Shelby County property.

**Reply templates:** `general`, `coverage`, `documents`.

Official source: [1]. The practical prompts are original editorial wording; no policy-specific conclusion is made.

**Source boundary:** Original editorial prompts. TDI has a separate farm/ranch discussion, but acreage, animal counts and sales are not used here to classify a property or recommend a product.

**Item gates:** G1, G2, G3, G4, G5, G6, G10 (defined below).

## Two Google Business Profile Update candidates

### W2-GBP-A · proposed Monday, 2026-11-30

**Status:** Candidate hold — exact copy, authentic image, button destination and separate GBP approval required

**Hook:** Describe the building's use, not just its name.

**Exact Update text — 539 characters including spaces and line breaks. No phone, URL, domain or hashtags.**

```text
A shed, detached garage, or workshop may need more description than its name. Before a conversation about your home or rural property, write down what happens in each space now and what has changed. Keep the list for yourself; please do not post addresses, belongings, or documents here.

A useful opening question is: “What information would help you understand how I use this space?” You do not have to choose an insurance category before asking. A general guide can help you prepare, but it cannot determine what your own policy covers.
```

**Destination path:** `/resources/farm-insurance-vs-homeowners-insurance`. Existing live guide supplied in the production brief; recheck before use.

**Button gate:** Optional Learn more, separate from text, only after public destination and preview verification

**Authentic image required:** Staff must later take a real photo at a cleared office desk: blank cream card with “Space / Use / What changed” headings, green pen and no filled personal details. No user assets, customer property, policy documents, generated office scene or stock photograph. Confirm staff and location consent; crop out screens, paperwork and identifiable visitors. No photo supplied by this task.

**Reply templates:** `general`, `coverage`, `documents`.

Reply templates are separate replies, not additions to GBP Update text. If replying on GBP, use a no-phone reply variant below.

Official source: [1]. The practical prompts are original editorial wording; no policy-specific conclusion is made.

**Item gates:** G1, G4, G5, G6, G7, G10 (defined below).

### W2-GBP-B · proposed Friday, 2026-12-04

**Status:** Candidate hold — authentic image and separate GBP approval required; new-page button release-held

**Hook:** Bring the timeline and one question.

**Exact Update text — 521 characters including spaces and line breaks. No phone, URL, domain or hashtags.**

```text
A planned home project is easier to describe when you separate what is planned, what is underway, and what is finished. Add whether the space will be used differently afterward. These notes are for a conversation, not a coverage conclusion.

Ask your agent: “What information should I bring, and when should we talk about this change?” Confirm the next step during that conversation. You can begin with the general topic instead of sharing a project address, contractor documents, or financial details in public comments.
```

**Destination path:** `/prepare-for-a-conversation`. Not live until verified

**Existing-guide fallback:** `/resources/farm-insurance-vs-homeowners-insurance`. Use only the complete approved fallback caption or verified separate button; never silently swap a destination while keeping an inaccurate page promise.

**Button gate:** Optional Learn more separate from text; use the new page only after release verification, or the existing guide only after approval and public recheck. Omit button if neither verified.

**Authentic image required:** Staff must later photograph three unfilled paper cards at the real office, headed “Planned,” “Underway,” and “Finished.” Include no project dates, names, contractors, customer paperwork or actual house pictures. Warm cream/green with a small amber marker. Staff/location consent and final frame inspection required. This task creates no image.

**Reply templates:** `general`, `timing`, `documents`.

Reply templates are separate replies, not additions to GBP Update text. If replying on GBP, use a no-phone reply variant below.

Official source: [1]. The practical prompts are original editorial wording; no policy-specific conclusion is made.

**Item gates:** G1, G3, G4, G5, G6, G7, G10 (defined below).

## Two LinkedIn manual-hold candidates

### W2-LI-A · proposed Wednesday, 2026-12-02

**Status:** MANUAL HOLD — separate channel approval; do not schedule automatically

**Topic:** Explain a home workspace by activity rather than job title.

**Hook:** “I work from home” is a starting point, not the whole description.

**Exact manual-post copy — 102 words**

```text
“I work from home” is a starting point, not the whole description of a space.

For a conversation about your home, separate where you sit from what actually happens there. Is it desk work, storing materials, or a place where someone visits for an appointment? Is that use new or established?

These are preparation questions, not a statement about what any policy covers. Write a general description for yourself, then ask your agent what additional information is appropriate to bring.

Keep employer details, client names, addresses, and documents off social media. You can start with one question without publishing your working life.
```

**Destination path:** `/prepare-for-a-conversation`. Optional future routing only; not live until verified. No link claimed in exact copy.

**Existing-guide fallback:** `/resources/farm-insurance-vs-homeowners-insurance`. Use only the complete approved fallback caption or verified separate button; never silently swap a destination while keeping an inaccurate page promise.

**Visual brief:** Optional authentic staff desk photo of a blank note card titled “What happens in this space?” No live laptop screen, employer logo, client paperwork or invented home-business scene. Text-only is acceptable after manual approval; no asset supplied.

**Reply templates:** `general`, `coverage`, `documents`.

Official source: [1]. The practical prompts are original editorial wording; no policy-specific conclusion is made.

**Item gates:** G1, G3, G5, G6, G8, G10 (defined below).

### W2-LI-B · proposed Friday, 2026-12-04

**Status:** MANUAL HOLD — separate channel approval; do not schedule automatically

**Topic:** Separate a property decision from the information handoff.

**Hook:** Keep the question list separate from the document pile.

**Exact manual-post copy — 104 words**

```text
A property change can involve several people: someone in the household, a person doing the work, and the person you contact with an insurance question. Keep the question list separate from the document pile.

Try a short private note: what is changing, whether it is planned or underway, and what you want to understand. Ask your agent which details are needed and how to share them appropriately. Do not assume a contractor's paperwork answers an insurance question.

The next step is a conversation, not a conclusion in a comment thread. Confirm timing directly, and keep addresses, contracts, financial details, and other people's names private.
```

**Destination path:** `/what-to-expect`. Optional future routing only; not live until verified. No link claimed in exact copy.

**Existing-guide fallback:** `/resources/farm-insurance-vs-homeowners-insurance`. Use only the complete approved fallback caption or verified separate button; never silently swap a destination while keeping an inaccurate page promise.

**Visual brief:** Optional authentic office photo of a blank folder beside a general handwritten card reading “What changed? What is my question?” No contract, customer document or fake case story. Text-only is acceptable after manual approval; no asset supplied.

**Reply templates:** `general`, `timing`, `documents`.

Official source: [1]. The practical prompts are original editorial wording; no policy-specific conclusion is made.

**Item gates:** G1, G3, G5, G6, G8, G10 (defined below).

## Two authentic-staff video scripts — format substitutes only

### W2-VIDEO-A · proposed Monday, 2026-11-30

**Status:** Script only — awaiting voluntary authentic Morrison staff recording, consent, review and separate approval

**Substitution:** W2-MON static/text acquisition placement on the selected channel; not an extra post.

**Hook:** What happens inside the shed?

**Delivery:** Natural 145–155 words per minute with brief pauses; target 32 seconds, acceptable final 25–40 seconds. Record a real staff member in their own voice. No assumed name, title, licensing statement, generated person or fabricated client scenario.

**Verbatim script — 78 words; about 31.2 seconds at 150 words per minute**

```text
What happens inside the shed? For a useful first conversation, start with the space and what you use it for now. Is it storage, a personal hobby, or something else? Then note what has changed. You do not have to pick an insurance label first. Keep addresses, belongings, and documents off social media. Ask your agent what information to bring and how to share it. One clear use question is a place to begin, not a coverage answer.
```

**Precise shot and caption plan — target 32 seconds**

- **0–3 seconds:** Vertical 9:16, chest-up real staff member at a cleared office wall; natural light, no visitors or screens.

  Spoken segment: “What happens inside the shed?”

  Exact overlay: "What happens inside the shed?"

- **3–12 seconds:** Cut to the same staff member's hand pointing to three blank printed headings on a desk. Voice remains the real recorded speaker; no fake completed example.

  Spoken segment: “For a useful first conversation, start with the space and what you use it for now. Is it storage, a personal hobby, or something else?”

  Exact overlay: "Space • Current use"

- **12–18 seconds:** Return to chest-up staff; small relaxed pause between sentences.

  Spoken segment: “Then note what has changed. You do not have to pick an insurance label first.”

  Exact overlay: "What changed?"

- **18–25 seconds:** Close-up of unfilled card; no document or real inventory. Keep the frame still and easy to read.

  Spoken segment: “Keep addresses, belongings, and documents off social media. Ask your agent what information to bring and how to share it.”

  Exact overlay: "Keep personal details private"

- **25–32 seconds:** Back to real staff; hold final frame long enough to read the overlay. Adjust final edit within 25–40 seconds without altering script meaning.

  Spoken segment: “One clear use question is a place to begin, not a coverage answer.”

  Exact overlay: "A question, not a coverage answer"

**Accessibility captions:** Burn in verbatim spoken words, synchronized by phrase, maximum two short lines. The listed overlays are separate short headings, not substitutes for accessibility captions. Keep captions above the bottom interface area and clear of the speaker's face. No music needed; keep natural voice intelligible.

**Exact short accompanying caption if the approved video substitutes for the static placement:**

```text
What happens inside the shed? Describe the space, its current use, and what changed. These are prompts for a private conversation, not a coverage answer. Please keep addresses, belongings, and documents out of comments.
```

**Destination path:** `/resources/farm-insurance-vs-homeowners-insurance`. Existing live guide supplied in the production brief; recheck before use.

**Reply templates:** `general`, `coverage`, `documents`.

Official source: [1]. The practical prompts are original editorial wording; no policy-specific conclusion is made.

**Item gates:** G1, G2, G4, G5, G6, G10 (defined below).

### W2-VIDEO-B · proposed Friday, 2026-12-04

**Status:** Script only — awaiting voluntary authentic Morrison staff recording, consent, review and separate approval

**Substitution:** W2-FRI static/text acquisition placement on the selected channel; not an extra post.

**Hook:** Thinking about someone staying in part of your property?

**Delivery:** Natural 145–155 words per minute with brief pauses; target 34 seconds, acceptable final 25–40 seconds. Real staff, real voice and consent only. No guest footage, rental listing, customer identity or generated staff.

**Verbatim script — 83 words; about 33.2 seconds at 150 words per minute**

```text
Thinking about someone staying in part of your property? Start by describing the plan. Is it an occasional visit or an ongoing arrangement? Is payment involved? Has it started, or are you still considering it? Those details are questions for a private conversation, not a coverage decision in a comment. You can begin with, I have a question about who will use part of my property. Ask what information to bring and confirm next-step timing. Keep guest names, addresses, and travel dates private.
```

**Precise shot and caption plan — target 34 seconds**

- **0–5 seconds:** Vertical chest-up real staff member at the approved office; no external guest scene.

  Spoken segment: “Thinking about someone staying in part of your property? Start by describing the plan.”

  Exact overlay: "Describe the plan"

- **5–13 seconds:** Cut to unfilled cards held by the same staff member: no actual dates, names or booking amounts.

  Spoken segment: “Is it an occasional visit or an ongoing arrangement? Is payment involved? Has it started, or are you still considering it?”

  Exact overlay: "Occasional or ongoing?\nStarted or considering?"

- **13–21 seconds:** Return to staff; use a calm conversational tone, not a sales pitch.

  Spoken segment: “Those details are questions for a private conversation, not a coverage decision in a comment.”

  Exact overlay: "Private questions, not online conclusions"

- **21–28 seconds:** Same framing; speaker reads the exact opening-message wording without adding a response-time promise.

  Spoken segment: “You can begin with, I have a question about who will use part of my property.”

  Exact overlay: "“I have a question about who will use part of my property.”"

- **28–34 seconds:** Hold staff framing; final short privacy overlay. Extend within the allowed window if delivery needs a pause.

  Spoken segment: “Ask what information to bring and confirm next-step timing. Keep guest names, addresses, and travel dates private.”

  Exact overlay: "Ask what to bring. Confirm timing.\nKeep personal details private."

**Accessibility captions:** Burn in the complete verbatim speech by synchronized phrase, maximum two readable lines. Keep listed headings separate from captions, within central safe margins. Do not use automatic captions without a human correction pass. No music required.

**Exact short accompanying caption if the approved video substitutes for the static placement:**

```text
Describe a planned stay in plain language, then take the question to a private conversation. Occasional or ongoing, payment or no payment, planned or already happening: these prompts do not decide coverage. Keep guest names, addresses, and travel dates out of comments.
```

**Destination path:** `/what-to-expect`. Optional future routing only; not live until verified. No link is asserted by the script or publish caption.

**Existing-guide fallback:** `/resources/farm-insurance-vs-homeowners-insurance`. Use only the complete approved fallback caption or verified separate button; never silently swap a destination while keeping an inaccurate page promise.

**Reply templates:** `general`, `coverage`, `away_dates`.

Official source: [1]. The practical prompts are original editorial wording; no policy-specific conclusion is made.

**Item gates:** G1, G2, G3, G4, G5, G6, G10 (defined below).

## Optional three-frame Story — substitute, not extra

**Proposed day:** Wednesday, 2026-12-02. **Status:** Optional three-frame substitute, not additional volume; parent selects channel and removes that channel's selected W2-WED acquisition placement.

**Hook:** Before the project conversation, sort the timeline.

**Destination path:** `/prepare-for-a-conversation`. Link sticker held until exact public page and sticker destination verified

**Existing-guide fallback:** `/resources/farm-insurance-vs-homeowners-insurance`. Use only the complete approved fallback caption or verified separate button; never silently swap a destination while keeping an inaccurate page promise.

### Frame 1 · suggested hold 7 seconds

```text
Planning a home change?

For your private notes:
What is planned, underway, or finished?
```

**Authentic visual:** Authentic staff photo of three empty labeled cards on a clean desk; no actual project or filled details.

### Frame 2 · suggested hold 7 seconds

```text
Will the space be used differently afterward?

Ask: “What would you need to understand this change?”
```

**Authentic visual:** Second authentic angle of an unfilled card with no customer information. No poll or question sticker requesting project details.

### Frame 3 · suggested hold 8 seconds

```text
Ask what to bring and confirm timing.

Keep addresses and documents private.
These prompts do not decide coverage.
```

**Authentic visual:** Authentic staff hand beside a blank notebook; green/cream text treatment with high contrast.

**Verified new-page link sticker label:** `Conversation prompts`. **Verified existing-guide fallback sticker label:** `Home & rural guide`. Omit the link sticker; frame wording remains exactly as supplied and does not claim a page is live.

**Reply templates:** `general`, `timing`, `documents`.

Official source: [1]. The practical prompts are original editorial wording; no policy-specific conclusion is made.

**Item gates:** G1, G2, G3, G4, G5, G6, G10 (defined below).

## Saturday local-engagement prompt — only if no committed award/community placement

**Proposed day:** Saturday, December 5. **Status:** INACTIVE unless no committed award/community placement; never displaces an award.

**Hook:** What public information would you point a new neighbor toward?

**Destination:** On-platform community discussion only; no outbound destination, contact solicitation or implied partner endorsement.

**Facebook — exact copy**

```text
For someone new to Shelby County, what kind of public information would you help them find first: county notices, library programs, or gardening education?

If you have a public resource you have actually used, share its name and one sentence about what made it useful. A clear starting point can be more helpful than a long list.

Please leave home addresses, private groups, personal contact details, and photos of other people out of the replies. This is a neighbor-friendly resource conversation, not an endorsement or a request for anyone's property information. Check a resource's own current information before relying on dates or hours.
```

**Instagram — exact copy**

```text
New to Shelby County? Which public information would you look for first: county notices, library programs, or gardening education?

Share a public resource name you have actually found useful and why. No home addresses, private contact details, or photos of other people, please.

This is a neighbor-friendly resource conversation, not an endorsement. Check the resource's own current information before relying on dates or hours.
```

**Visual brief:** Optional authentic staff photo of a blank note card headed “A useful public starting point,” photographed at the cleared office. No institutional logo, named partner, event flyer, customer identity or fabricated local scene. Text-only if the approved format permits. No image created here.

**Reply templates:** `community`, `public_sensitive_detail`.

**Source boundary:** Original community question, with no claim that a particular program exists or is open. Any later factual resource reply must be verified from that resource's official information before the team adds dates, hours or links.

**Item gates:** G1, G2, G6, G9, G10 (defined below).

## Privacy-safe exact response templates

Do not ask readers to post a policy, address, inventory, guest schedule, financial details or identifiers. Social messages are not represented as secure intake. Phone wording is permitted in these separate FB/IG/LinkedIn replies, not in GBP Update text; the no-phone GBP variants follow. Never repeat a sensitive comment while answering it.

### `general` · Reader asks how to begin

```text
A general topic is enough to begin: what kind of space or use you have a question about, without an address or personal details. You can contact Morrison at (936) 598-2791 and ask what information to bring, how to share it appropriately, and when the next step can happen.
```

### `coverage` · Reader asks whether a shed, rental, animal activity or change is covered

```text
We cannot determine your coverage or policy fit in a comment thread. The actual use and your own policy need a private conversation. Please keep addresses, documents, and financial details off social media. Contact your agent, or call Morrison at (936) 598-2791 to ask about an appropriate next step.
```

### `documents` · Reader offers declarations, contracts, photos, inventories or policy numbers

```text
Please do not attach policy pages, contracts, inventories, or photos with personal details here or in social messages. Start with the general topic only. Contact the office directly and ask which information is needed and how it should be shared. We do not need those details in this thread.
```

### `timing` · Reader asks for response timing or an assumed project deadline

```text
Please confirm next-step timing directly with the office or your agent. We are not setting a response promise or a project deadline in this thread. You can begin with the general change and ask when to discuss it, without posting an address or documents.
```

### `away_dates` · Reader starts describing travel, guest dates, occupancy or an empty home

```text
Please keep travel dates, guest names, addresses, and details about when a property is empty private. You can describe the general question directly to your agent and ask what information is needed. We cannot answer a policy question from those details in a public thread.
```

### `direct_message` · Reader enters social DMs expecting a secure intake channel

```text
Thanks for reaching out. Please keep this message to the general topic; do not send policy numbers, birth dates, financial details, documents, or property addresses in social messages. For an appropriate next step, contact Morrison at (936) 598-2791 and ask what information to bring, how to share it, and when to expect the next conversation.
```

### `community` · Reader recommends a public resource in the optional Saturday discussion

```text
Thank you for naming a public starting point and explaining what you found useful. Anyone planning to use it should check the resource's own current information for details. Please keep private contact information and home addresses out of this thread.
```

### `public_sensitive_detail` · Reader posts sensitive information; team must not repeat it

```text
For your privacy, please remove the personal details from your comment. We will not repeat them here. Contact the office directly to ask how any needed information should be shared.
```

**Moderation gate:** Follow the account's authorized moderation procedure for hiding/removing sensitive content. Do not claim it was deleted or secured unless that action has actually been completed. Do not screenshot, quote, export or reuse the sensitive material for content.

### `claim_or_emergency` · Reader raises an active claim or urgent safety issue

```text
If anyone is in immediate danger, contact emergency services. For a claim question, use your insurer's official claim contact or contact the office directly to ask about the next step. Please do not post claim numbers, addresses, photos of people, or documents here. We cannot determine coverage or an outcome in this thread.
```

### GBP no-phone response variants

**`general`**

```text
A general topic is enough to begin: what kind of space or use you have a question about, without an address or personal details. Contact the office directly and ask what information to bring, how to share it appropriately, and when the next step can happen.
```

**`coverage`**

```text
We cannot determine your coverage or policy fit in a comment thread. The actual use and your own policy need a private conversation. Please keep addresses, documents, and financial details off social media. Contact your agent or the office directly to ask about an appropriate next step.
```

**`direct_message`**

```text
Thanks for reaching out. Please keep this message to the general topic; do not send policy numbers, birth dates, financial details, documents, or property addresses in social messages. Contact the office directly and ask what information to bring, how to share it, and when the next conversation can happen.
```

Other templates above without phone/URL/domain/hashtags may be used as separate GBP replies after approval; none are appended to an Update.

## Release, recheck and approval gates

1. **G1:** No authority to schedule or publish is granted by this bundle. Parent must obtain explicit approval of exact copy, chosen format, destination and any final authentic photo/video before a provider action.

2. **G2:** Parent assigns times only after a fresh per-channel calendar check that includes existing library posts, approvals, sports, fishing and awards; maximum two daily posts separately on Facebook and Instagram. Preserve existing commitments and the 7–10 weekly planning target without filling blindly.

3. **G3:** Before using any planned utility-page primary copy or link, verify public release of that exact path, meaningful page content matching the promise, desktop/mobile behavior and correct contact routing. A local preview, repository change or sitemap entry alone is not release verification. Until then hold the primary or choose the complete existing-guide fallback with approval.

4. **G4:** Before any existing-guide fallback or Monday link ships, recheck the public guide resolves and remains relevant. Before Instagram says profile link, verify the actual profile link and exact destination; otherwise choose the complete no-link fallback.

5. **G5:** Recheck the official TDI source close to delivery if retaining a sourced statement. Reviewer must keep all property examples as questions, with no automatic coverage, product, rate, claim or classification conclusion.

6. **G6:** No user/customer assets collected. Staff must supply new authentic recordings/photos later with consent and permission to use the location. No AI staff, stock customer scenes, external social posts, real paperwork, names, screens, plates, addresses, children or identifiable customer property in the visuals.

7. **G7:** For GBP, use Update only; authentic final image required, final text under 1,500 characters and no phone, URL, domain or hashtags. Verify any separate button destination and final provider preview/readback; draft is not scheduled or published.

8. **G8:** LinkedIn candidates remain MANUAL HOLD regardless of FB/IG approval. A separate channel-specific decision and final human preview are required; do not automate them.

9. **G9:** Saturday prompt stays inactive unless the parent confirms no committed award/community content for that placement and fresh channel capacity. Never invent local events, operating hours, closures, results or endorsements.

10. **G10:** After an authorized scheduling action, verify provider readback for account, channel, exact approved copy, media, destination, local date/time and status. Keep website release, post approval, scheduling and publication as separate gates.

**Scope:** Only week 2 authored. No website files owned or edited, no user images/assets/external social posts obtained, no subagents delegated, no website publication, no new recurring workflow, no outreach, no review solicitation, no paid media or tracking changes. The production-brief source correction was respected: cb030.html is not used or labeled as a general small-business/COI guide.

## References

Factual source checked November 16, 2026 from the actual official page, not a search snippet. TDI says home coverages vary by company and directs readers to their policy or agent for exact coverage. That is the narrow factual point used in Monday copy. Other lists and questions are original preparation prompts, not required reporting instructions or recommendations for a particular product. Recheck before delivery if retaining sourced wording. [1]

[1]: https://www.tdi.texas.gov/pubs/consumer/cb025.html "Texas Department of Insurance — Homeowners insurance guide"
