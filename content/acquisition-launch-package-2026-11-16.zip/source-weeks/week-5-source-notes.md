# Week 5 source notes — checked November 16, 2026

Read production-brief.md. Parent correction: https://www.tdi.texas.gov/pubs/consumer/cb030.html is TDI’s Workers’ compensation guide, not a general small-business or COI guide. It is not used in week 5.

[1] https://www.tdi.texas.gov/pubs/consumer/cb020.html — Auto insurance guide. Actual page read November 16, 2026. In “Deductibles and dollar limits,” TDI states that the declaration page summarizes coverages, dollar limits and deductibles. Week 5 uses only that narrow fact; no legal minimums, savings claims, deductible examples or individual coverage conclusions.

[2] https://www.tdi.texas.gov/tips/shop-smart.html — How to shop smart for insurance. Actual page read November 16, 2026. It discusses shopping, discounts, complaints and deductibles. No additional claim from it is needed in the final week-5 copy; do not cite it as authority for office privacy procedures or availability.

Generic question-list, privacy-boundary and timing prompts are original editorial preparation guidance, not claims about coverage or a TDI-approved agency process. Morrison staff must approve the practical handoff language. No holiday hours, closures or response time were verified or asserted.

Production brief supplies existing guide routes as already live. New /start-here, /prepare-for-a-conversation and /what-to-expect are planned, unverified and release-held. No website, profile link, provider inventory or authentic media checked in this copy-only assignment. Parent owns those gates. No external posts, assets or delegated jobs created.
