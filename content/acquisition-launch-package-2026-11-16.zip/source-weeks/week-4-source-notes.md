# Week 4 source findings — checked November 16, 2026

https://www.tdi.texas.gov/certificates/faq.html — Successfully read. TDI FAQ 4 says a certificate cannot refer to insurance requirements in another contract; FAQ 12 says a certificate cannot say something different from the policy; FAQ 19 says the certificate holder box cannot imply new rights beyond the policy or executed endorsement; FAQ 23 says a certificate cannot alter, amend or extend policy coverage. Use only the plain-language COI limitation, not a contract-compliance promise or a specific additional-insured conclusion.

https://www.tdi.texas.gov/certificates/documents/s722397.pdf — Successfully read official TDI-hosted liability certificate. Opening text says the certificate is informational, does not amend, extend or alter coverage/terms/exclusions/conditions, and does not represent a contract with the holder. No form image will be used in public assets.

https://www.tdi.texas.gov/tips/what-insurance-do-i-need-to-run-a-business-from-home.html — Successfully read. Identifies equipment/inventory, deliveries and hiring as business activity topics to discuss with an agent. Week 4 uses these as questions, not conclusions about any reader's policy.

https://www.tdi.texas.gov/pubs/consumer/cb030.html — Successfully read, but currently titled Workers' compensation insurance guide, not the small-business guide named in the production brief. Do not cite it as a general small-business guide. No workers' compensation legal claims are needed in this bundle.

https://www.tdi.texas.gov/commercial/certificates.html — Extraction failed. Not cited or used. The successfully read official FAQ and official form supply the needed support.

Existing Morrison guide routes are supplied as live in the production brief, not independently reverified by this subtask. Parent must recheck public destinations at release. The three planned utility pages remain unpublished/unverified in this bundle.
