# Week 3 source notes — checked November 16, 2026

Only official Texas Department of Insurance pages were used to verify insurance facts. No external social posts, images, customer assets or website files were used or changed.

[1] https://www.tdi.texas.gov/pubs/consumer/cb020.html — Automobile insurance guide. The declarations page summarizes coverages, dollar limits and deductibles. TDI advises asking an agent or reading the policy to learn who is covered and whether anyone is excluded. A deductible is the amount of a claim the policyholder pays. These points support Monday's comparison questions and Wednesday's assumptions questions. Do not infer any particular reader's coverage.

[2] https://www.tdi.texas.gov/consumer/auto-insurance-shopping-guide.html — How to shop smart for auto insurance. TDI's checklist asks about liability, other coverages, use of the car, exclusions, deductibles and whether price differs when paying in advance. Its shopping tips say: “Don’t cancel your current policy until you get your new policy or a written statement that proves you have coverage.” These points support Wednesday's use question, Friday's payment-comparison questions and Sunday's written-coverage step. Confirm actual start/end dates and any applicable times with the relevant insurer; the source is not a guarantee that any proposed date is effective.

Existing Morrison guide destinations are live according to the supplied production brief. This subtask did not independently test their public delivery. Parent must recheck each selected public URL and preview before release. Planned /start-here, /prepare-for-a-conversation and /what-to-expect remain unreleased unless parent verifies deployment and explicitly approves their use.

Recheck the two TDI pages close to December 7–13, 2026 and resolve changed wording before approving the affected copy. No cancellation-notice deadlines, minimum-limit figures, discount claims, savings claims or customer outcomes are used.
