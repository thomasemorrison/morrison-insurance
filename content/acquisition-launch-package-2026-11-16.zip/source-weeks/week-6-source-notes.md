# Week 6 source findings — checked November 16, 2026

TDI Automobile insurance guide: https://www.tdi.texas.gov/pubs/consumer/cb020.html. Actual page says the declaration page summarizes coverages, dollar limits and deductibles. No January price or trend assertions are used.

TDI How to shop smart for auto insurance: https://www.tdi.texas.gov/consumer/auto-insurance-shopping-guide.html. Actual page includes the question “Does the policy cover how I use my car or are there any exclusions?” and says not to cancel the current policy until obtaining the new policy or a written statement proving coverage. Week 6 uses the use question and that specific cancellation precaution only.

TDI Homeowners insurance guide: https://www.tdi.texas.gov/pubs/consumer/cb025.html. Actual page says coverages vary by company and readers should read their policy or talk to their agent about exact coverages. It also identifies the declarations page as a summary of coverages, dollar limits and deductibles. Week 6 offers changed-use questions, not answers about a particular property.

Brief correction: https://www.tdi.texas.gov/pubs/consumer/cb030.html was fetched and is titled Workers’ compensation insurance guide, not small-business insurance guide. Do not cite it for general business changes or certificate conclusions. Business copy uses suggested conversation preparation, with no legal, contractual, certificate or coverage assertion.

Existing Morrison guides are live according to the supplied production brief. Public links must still be rechecked by the parent close to delivery. /start-here, /prepare-for-a-conversation and /what-to-expect are planned, not verified live in this task. They must not appear as available public destinations until release is verified. No website files, user images, asset acquisition, external posting or agent delegation occurred.
