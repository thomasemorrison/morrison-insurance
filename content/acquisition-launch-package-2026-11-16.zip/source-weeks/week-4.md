# Week 4 — December 14–20, 2026

**Theme:** Business paperwork, certificates of insurance and changing operations; no contractual promises. **Status:** Review-ready candidates only, not scheduled or published. This bundle contains full exact copy; all instructions, hooks, citations and gates outside the copy blocks are production notes.

## Capacity and protected commitments

Proposed days only. Parent assigns times after fresh per-channel capacity and commitment checks. Four acquisition placements on Monday, Wednesday, Friday and Sunday, plus preserved Tuesday sports, Thursday fishing and Saturday award/community lane, normally seven placements per channel if each anchor has one placement. Count actual existing commitments; do not assume one. Target total 7–10 weekly per channel, maximum two per channel per day. If existing commitments use the space, hold these candidates or substitute an explicitly approved uncommitted placement; do not remove approved items or the archive.

Each video is a replacement creative for its matching acquisition placement, not an additional post. Do not publish the still and video version of the same topic as two placements. Optional three-frame sequence substitutes for one approved acquisition placement on the selected channel; not extra volume. Count any platform/provider items separately and preserve the two-per-channel daily ceiling.

GBP candidates require separate approval and current GBP capacity checks. LinkedIn candidates remain manual holds; they are not part of a scheduled FB/IG batch.

- **Tuesday 2026-12-15 — Existing five-school sports:** Preserve; researched close to delivery by its owner. No invented results, fixtures or school posts in this bundle.
- **Thursday 2026-12-17 — Existing fishing:** Preserve; researched close to delivery by its owner. No invented weather, catches or conditions in this bundle.
- **Saturday 2026-12-19 — Existing committed award/community first:** Preserve. Use the optional local prompt only after verifying no committed award/community placement would be displaced.

Default IG copy is self-contained; no bio-link placement is assumed. The three planned pages `/start-here`, `/prepare-for-a-conversation` and `/what-to-expect` remain unverified and unpublished for this bundle. Parent owns all website release work. No website files, user images, assets or external posts were changed or created. No delegation or recurring publisher was used.

## Release, recheck and approval gates

- G1 — Obtain explicit owner approval of the exact copy, channel, destination and chosen creative; this bundle does not authorize publication.
- G2 — Immediately before scheduling, read current provider commitments separately for FB and IG, including library, awards, sports and fishing. Enforce maximum two per channel per day and target 7–10 weekly per channel without deleting approved commitments. Parent assigns times only after this check.
- G3 — Publicly verify the intended destination after any site release: real rendered page, correct route, readable mobile page, contact route and relevant metadata/preview. /start-here, /prepare-for-a-conversation and /what-to-expect are not live until verified. Until then use the exact default live-guide copy or hold; never promote an unpublished route.
- G4 — Reopen cited official TDI sources near publication and confirm the COI limitation still matches the source. Do not convert editorial preparation questions into policy-specific or contract-compliance conclusions. No promise of issuance, approval, additional-insured status, turnaround or contractual satisfaction.
- G5 — Capture only authentic consenting staff and office visuals after approval. Inspect backgrounds, reflections and audio for screens, documents, customer/employee data and third-party identities. No real customer papers, mock COIs, generated staff or fabricated testimonials. No assets have been produced by this subtask.
- G6 — Videos require real staff recording, timed read, verbatim subtitle check and final human approval. Keep duration 25–40 seconds by rerecording or adjusting pace, not adding claims. Story and video are substitutes, not extra placements.
- G7 — Saturday prompt is eligible only if no committed award/community placement exists. Preserve any existing commitment; no fabricated award winner or future event information.
- G8 — GBP uses Update type, <=1500-character exact copy, no phone/URL/domain/hashtags in the text, authentic approved photo and separately verified button destination. LinkedIn remains manual hold pending account-owner approval and manual posting.
- G9 — If parent later authorizes scheduling, read back each provider's saved channel, exact text, destination, creative, time and timezone. Reconcile final daily counts separately for FB and IG. No automatic publisher or recurring workflow is created here.
- G10 — Do not publish customer identities, partner names or document details without separate consent. No holiday hours, closures, availability, response-time, price, savings, coverage or claim guarantees. Existing posted hours are not a holiday promise.

## Four independent Facebook / Instagram topic pairs

### Monday — A COI request arrived: what should I clarify first?

**Proposed day only:** Monday, 2026-12-14. Parent assigns time after capacity checks.

**Useful hook:** Start with the request, not a stack of paperwork.

**Default destination path:** `/resources/certificate-of-insurance-shelby-county-tx`. Existing guide is live per brief; recheck publicly at release.

**Facebook exact copy — 132 words:**

```text
Someone asked your business for a certificate of insurance. What should you have ready for the first conversation?

Start with the request itself: who is asking, what they want to receive, and the date they gave you. Keep any written instructions available privately. You do not need to post them here or explain your whole business in a comment.

A certificate of insurance, often called a COI, provides information about a policy; it does not change the policy’s coverage. That makes one question especially useful: “What information do you need to look at this request?”

Morrison’s local guide offers a plain-language starting point. Read it when it is useful, then bring the question that is still unclear.

https://morrison-ins.net/resources/certificate-of-insurance-shelby-county-tx

Please keep names, policy numbers and contract pages out of comments and social messages.
```

**Instagram exact copy — 85 words:**

```text
Asked for a certificate of insurance? Start with three questions: Who is asking? What did they request? What date did they give you?

A certificate, often called a COI, provides policy information. It does not change the policy’s coverage.

Keep the written request for a private conversation, not the comments. A useful opening question is: “What information do you need to look at this request?”

No need to share policy numbers, names or contract pages here. One clear question is a good place to begin.
```

**Authentic visual / filming brief:** Authentic staff hands at a cleared Morrison office desk with three newly written editorial prompt cards: Who is asking? / What is requested? / What date? Cards contain no names, numbers, contract text or policy details. Warm green, cream and amber; casual office clothing; no suits or carrier branding. This is a preparation prop, not a customer example or COI. No image is supplied.

**Alt text:** Three question cards on a clear desk: who is asking, what is requested, and what date.

**Claim support:** [1] [2]. Official sources were read November 16, 2026; recheck near publication. These citations are production notes, not appended to the exact social caption.

**Privacy-safe response:** Use `coi_request` below. **Required gates:** G1, G2, G3, G4, G5, G9, G10.

### Wednesday — The business changed: how can I describe what is different?

**Proposed day only:** Wednesday, 2026-12-16. Parent assigns time after capacity checks.

**Useful hook:** Describe the work now, not just the business name.

**Default destination path:** `/resources/certificate-of-insurance-shelby-county-tx`. Existing guide is live per brief; recheck publicly at release.

**Planned destination, held:** `/prepare-for-a-conversation` is not live until verified. Do not use an unpublished route. The default full copy below remains usable with the rechecked existing guide.

**Facebook exact copy — 136 words:**

```text
If your business does something different now, how would you describe the change in two sentences?

Try this on your own blank sheet: “We used to ____. Now we ____.” Then note when the change started, or when you expect it to start.

Perhaps you have added delivery work, moved equipment, or changed where customers meet you. These are conversation topics, not answers about what a policy covers. You do not need to decide the insurance question before asking it.

Keep the note general. Leave out customer names, addresses, employee details and financial information. Your next question can be: “What else would you need to understand this change?”

For business paperwork questions, Morrison’s existing COI guide is a starting point:
https://morrison-ins.net/resources/certificate-of-insurance-shelby-county-tx

A clearer description is useful even when you are not ready to make a decision.
```

**Instagram exact copy — 81 words:**

```text
Does your business description still match the work you do?

On a blank sheet, try: “We used to ____. Now we ____.” Add when the change began or is expected. Delivery work, equipment and customer visits can be useful conversation topics—not coverage conclusions.

Keep customer names, addresses and employee details off the note you share socially.

Your next question can be simple: “What else would you need to understand this change?” You do not have to solve the policy question first.
```

**Held release alternate:** Replace only the two default guide sentences and URL with: “Use Morrison’s ungated preparation page to organize the questions you want to bring:
https://morrison-ins.net/prepare-for-a-conversation” — only after G3 and renewed exact-copy approval. All remaining copy stays unchanged.

**Authentic visual / filming brief:** Photograph a consenting real staff member at a cleared office table, pointing to two blank index cards headed Before and Now. Do not fill in a fictional business story. Keep computer screens off-camera. Cream paper, green shirt or background accent and amber pencil. No external business locations or customers.

**Alt text:** A staff member points to two empty cards labeled Before and Now on a clear table.

**Claim support:** [3]. Official sources were read November 16, 2026; recheck near publication. These citations are production notes, not appended to the exact social caption.

**Privacy-safe response:** Use `operations` below. **Required gates:** G1, G2, G3, G4, G5, G9, G10.

### Friday — Can requested certificate wording change the policy?

**Proposed day only:** Friday, 2026-12-18. Parent assigns time after capacity checks.

**Useful hook:** A wording request is a question, not a coverage change.

**Default destination path:** `/resources/certificate-of-insurance-shelby-county-tx`. Existing guide is live per brief; recheck publicly at release.

**Facebook exact copy — 133 words:**

```text
What if a business paperwork request says, “Please add this wording to the certificate”?

Keep the exact request available for a private conversation. A useful question is: “Does this wording match what is actually in the policy?” You do not need to interpret it yourself or paste it into a public comment.

A certificate of insurance cannot change or extend the policy’s coverage. Adding words to the certificate is not a substitute for understanding the underlying policy.

Morrison’s COI guide can help you get familiar with the paperwork before you ask your next question:
https://morrison-ins.net/resources/certificate-of-insurance-shelby-county-tx

Whether a business agreement meets your needs is a separate question for the appropriate adviser. This post does not confirm contract compliance, approval or coverage for any particular job. Keep contract pages and identifying details off social media.
```

**Instagram exact copy — 84 words:**

```text
Asked to add wording to a certificate of insurance? Keep the request for a private conversation.

Try asking: “Does this wording match what is actually in the policy?”

A certificate cannot change or extend the policy’s coverage. Extra words are not a substitute for understanding the policy.

Please do not paste contract pages, policy numbers or customer names here. This post is a starting question—not confirmation that a job is covered or an agreement meets its requirements. Contract questions belong with the appropriate adviser.
```

**Authentic visual / filming brief:** Real consenting staff member holding two editorial cards labeled Request and Policy, with no other text. Shoot in the actual office against a plain warm-green/cream background. No policy pages or sample certificates. Caption overlay uses the approved hook only. No contractual stamp, checkmark of approval or completed-document imagery.

**Alt text:** A staff member holds two simple cards labeled Request and Policy.

**Claim support:** [1] [2]. Official sources were read November 16, 2026; recheck near publication. These citations are production notes, not appended to the exact social caption.

**Privacy-safe response:** Use `wording` below. **Required gates:** G1, G2, G3, G4, G5, G9, G10.

### Sunday — Where should business documents go, and what belongs in a first message?

**Proposed day only:** Sunday, 2026-12-20. Parent assigns time after capacity checks.

**Useful hook:** Ask where to send it before attaching it.

**Default destination path:** `/resources/certificate-of-insurance-shelby-county-tx`. Existing guide is live per brief; recheck publicly at release.

**Planned destination, held:** `/what-to-expect` is not live until verified. Do not use an unpublished route. The default full copy below remains usable with the rechecked existing guide.

**Facebook exact copy — 132 words:**

```text
Before attaching business paperwork to a message, ask where it should go.

You can begin without sending a document: “I have a business paperwork question. It concerns a certificate request, and I would like to confirm the next step.” If there is a requested date, mention it during your direct conversation and ask about timing rather than assuming a turnaround.

A public comment or social inbox is not the place for policy numbers, signatures, contract pages, customer lists or employee information. Ask Morrison’s team to confirm the appropriate document-sharing method before sending anything sensitive.

You can also read the existing COI guide first, at your own pace:
https://morrison-ins.net/resources/certificate-of-insurance-shelby-county-tx

One general question is enough to start. You do not have to assemble every piece of paperwork before asking how the conversation should proceed.
```

**Instagram exact copy — 83 words:**

```text
Have business paperwork to discuss? Ask where to send it before attaching it.

A first message can stay general: “I have a certificate request and would like to confirm the next step.”

Leave policy numbers, signatures, customer lists and contract pages out of comments and social messages. Ask Morrison’s team to confirm the appropriate document-sharing method.

Mention any requested date in the direct conversation and ask about timing; do not assume a turnaround. You can start with one question, not a full folder.
```

**Held release alternate:** Replace only the two default guide sentences and URL with: “Read how to prepare a useful first message and ask about next steps:
https://morrison-ins.net/what-to-expect” — only after G3 and renewed exact-copy approval. All remaining copy stays unchanged.

**Authentic visual / filming brief:** Authentic staff hand beside a face-down, fully blank cream folder on a cleared office desk; the folder contains no documents. Add one editorial card: Ask where to send it. Do not display an email app, chat screenshot, form or a fabricated customer exchange.

**Alt text:** A blank closed folder sits beside a card that says Ask where to send it.

**Claim support:** Original editorial preparation or privacy wording; no policy, outcome or local-event factual claim.

**Privacy-safe response:** Use `handoff` below. **Required gates:** G1, G2, G3, G5, G9, G10.

## Two Google Business Profile Update candidates

### W4-GBP-1 — A certificate request: three things to clarify.

**Proposed day only:** Monday, 2026-12-14. Parent assigns time after capacity checks.

**Useful hook:** A certificate request: three things to clarify.

**Default destination path:** `/resources/certificate-of-insurance-shelby-county-tx`. Button metadata only; recheck the existing public guide at release.

**Type / hold:** Update; Approval hold; authentic photo required. **Text length:** 663 characters including spaces and line breaks; limit 1,500. No phone, URL, domain or hashtag in the following exact text.

```text
Asked for a certificate of insurance for your business? Start by noting who is asking, what they requested and the date they gave you. Keep the written instructions available for a private conversation.

A certificate of insurance provides policy information; it does not change the policy’s coverage. A useful first question is: “What information do you need to look at this request?”

Ask our team to confirm the appropriate way to share documents before sending them. Please keep policy numbers, signatures, contract pages and customer details out of public questions and social messages. You can begin with a general question, not a complete paperwork folder.
```

**Separate button metadata:** Proposed “Learn more” button to [/resources/certificate-of-insurance-shelby-county-tx](https://morrison-ins.net/resources/certificate-of-insurance-shelby-county-tx). URL is button metadata only, not part of Update copy. Recheck public destination and actual available provider button type.

**Required authentic image:** New approved photograph of consenting real Morrison staff hands arranging three editorial cards on a clear office desk: Who is asking? / What is requested? / What date? No customer or mock certificate papers, screens, third-party identities or numbers. Natural office light, green/cream/amber. Photograph not yet captured.

**Alt text:** Three preparation question cards arranged on a clear office desk.

**Claim support:** [1] [2]. Official sources were read November 16, 2026; recheck near publication. These citations are production notes, not appended to the exact social caption.

**Privacy-safe response:** Use `gbp_safe` below if a separately approved GBP response is needed. coi_request provides the topic boundary for other channels. **Required gates:** G1, G3, G4, G5, G8, G9, G10.

### W4-GBP-2 — Explain the work that changed.

**Proposed day only:** Wednesday, 2026-12-16. Parent assigns time after capacity checks.

**Useful hook:** Explain the work that changed.

**Default destination path:** `/resources/certificate-of-insurance-shelby-county-tx`. Button metadata only; recheck the existing public guide at release.

**Type / hold:** Update; Approval hold; authentic photo required. **Text length:** 641 characters including spaces and line breaks; limit 1,500. No phone, URL, domain or hashtag in the following exact text.

```text
Does your business do something different now? Before a conversation, write one general sentence about the work you did before and one about the work you do now. Note when the change began or when you expect it to begin.

Delivery work, equipment and customer visits can be useful topics to discuss. They are not, by themselves, answers about your policy.

Try asking: “What else would you need to understand this change?” Keep customer names, addresses, employee details and financial information out of social messages. Ask our team to confirm an appropriate way to share any documents and discuss next-step timing during the conversation.
```

**Separate button metadata:** Proposed “Learn more” button to [/resources/certificate-of-insurance-shelby-county-tx](https://morrison-ins.net/resources/certificate-of-insurance-shelby-county-tx). Default is existing business-paperwork guide. Switch button only after new page public verification and explicit approval. No URL in Update text.

**Held alternate button path:** `/prepare-for-a-conversation`; use only after G3 and explicit destination approval.

**Required authentic image:** New approved photograph of a consenting actual staff member gesturing to two blank cards headed Before and Now on a cleared office table. No invented business details, customers, equipment belonging to outside businesses or visible computer screens. Warm green/cream with amber pencil; genuine office setting, no stock or generated people. Photograph not yet captured.

**Alt text:** A staff member gestures toward empty Before and Now cards on a clear table.

**Claim support:** [3]. Official sources were read November 16, 2026; recheck near publication. These citations are production notes, not appended to the exact social caption.

**Privacy-safe response:** Use `gbp_safe` below if a separately approved GBP response is needed. operations provides the topic boundary for other channels. **Required gates:** G1, G3, G4, G5, G8, G9, G10.

## Two LinkedIn manual holds

### W4-LI-1 — Keep the certificate question separate from the contract question.

**Proposed day only:** Friday, 2026-12-18. Parent assigns time after capacity checks.

**Useful hook:** Keep the certificate question separate from the contract question.

**Default destination path:** `/resources/certificate-of-insurance-shelby-county-tx`. Existing guide is live per brief; recheck publicly at release.

**Status:** MANUAL HOLD — account owner must approve and post; not scheduled. **Exact copy — 92 words:**

```text
When a business receives a request for specific certificate wording, a useful next question is: “Does this match the policy?”

A certificate of insurance cannot change or extend the policy’s coverage. That question is separate from whether a business agreement meets your needs; contract interpretation belongs with the appropriate adviser.

Keep the exact request for a private conversation. Please do not share contract pages, policy numbers or customer details in comments or social messages.

Morrison’s existing COI guide is a plain-language starting point, not a confirmation of coverage or contract compliance:
https://morrison-ins.net/resources/certificate-of-insurance-shelby-county-tx
```

**Visual brief:** Optional authentic office photograph of editorial Request and Policy cards only; no external jobsite, people or papers. Owner can choose text-only manual posting. No generated or supplied asset.

**Claim support:** [1] [2]. Official sources were read November 16, 2026; recheck near publication. These citations are production notes, not appended to the exact social caption.

**Privacy-safe response:** Use `wording` below. **Required gates:** G1, G3, G4, G5, G8, G10.

### W4-LI-2 — Make the first business message useful without attaching everything.

**Proposed day only:** Sunday, 2026-12-20. Parent assigns time after capacity checks.

**Useful hook:** Make the first business message useful without attaching everything.

**Default destination path:** `/resources/certificate-of-insurance-shelby-county-tx`. Existing guide is live per brief; recheck publicly at release.

**Planned destination, held:** `/what-to-expect` is not live until verified. Do not use an unpublished route. The default full copy below remains usable with the rechecked existing guide.

**Status:** MANUAL HOLD — account owner must approve and post; not scheduled. **Exact copy — 90 words:**

```text
A useful first business message can be short: “I have a certificate request and would like to confirm the next step.”

Start with the topic, not a document attachment. Ask the team to confirm an appropriate document-sharing method before sending policy numbers, signatures, contract pages or employee information. Keep those details out of social messages and comments.

If someone has given you a requested date, discuss it directly and ask about next-step timing rather than assuming a turnaround.

Morrison’s existing COI guide is available to read before that conversation:
https://morrison-ins.net/resources/certificate-of-insurance-shelby-county-tx
```

**Held release alternate:** Replace only the final guide sentence and URL with: “Morrison’s first-conversation page explains useful message preparation and privacy boundaries:
https://morrison-ins.net/what-to-expect” — only after G3 and renewed exact-copy approval.

**Visual brief:** Text-only is preferred for this manual hold. If the account owner chooses a photo, capture an authentic cleared office desk and blank closed folder; no chat screenshot, customer material or staged case exchange.

**Claim support:** Original editorial preparation or privacy wording; no policy, outcome or local-event factual claim.

**Privacy-safe response:** Use `handoff` below. **Required gates:** G1, G3, G5, G8, G10.

## Two authentic staff-recording scripts

### W4-VIDEO-1 — What should I clarify when someone asks for a COI?

**Proposed day only:** Monday, 2026-12-14. Parent assigns time after capacity checks.

**Useful hook:** What should I clarify when someone asks for a COI?

**Default destination path:** `/resources/certificate-of-insurance-shelby-county-tx`. Existing guide is live per brief; recheck publicly at release.

**Status:** Awaiting authentic consenting staff recording and approval; not finished footage. Replace the Monday still creative on any approved channel; use that topic's exact full FB/IG captions, not an extra placement.

**Duration:** Planned 35-second shot sequence; 78 spoken words, approximately 33.4 seconds at the stated pace. Final authentic read must be timed and approved within 25–40 seconds.

**Verbatim staff script:**

```text
Asked for a certificate of insurance? Start with three things: who is asking, what they requested, and the date they gave you. Keep the written request for a private conversation. A certificate gives policy information; it does not change the policy’s coverage. Your first question can be: What information do you need to look at this request? Please keep policy numbers and contract pages out of comments and social messages. Ask our team how to share documents appropriately.
```

**Precise shot / caption plan:**

- **00:00–00:05:** Vertical 9:16 medium shot of actual consenting Morrison staff in casual office clothing. Cleared background; look toward camera. Spoken words / verbatim subtitle: “Asked for a certificate of insurance? Start with three things:” Top overlay: “Asked for a COI?”.
- **00:05–00:10:** Cut to the same staff member's hands pointing in sequence at three editorial question cards; no document facsimile. Spoken words / verbatim subtitle: “who is asking, what they requested, and the date they gave you.” Top overlay: “Who • What • Requested date”.
- **00:10–00:14:** Return to staff medium shot; natural pace, no urgency effect. Spoken words / verbatim subtitle: “Keep the written request for a private conversation.” Top overlay: “Keep the request private”.
- **00:14–00:20:** Continue the same shot; no claims-oriented imagery or approval graphic. Spoken words / verbatim subtitle: “A certificate gives policy information; it does not change the policy’s coverage.” Top overlay: “A COI does not change coverage”.
- **00:20–00:26:** Slightly closer framing on the same authentic speaker. Spoken words / verbatim subtitle: “Your first question can be: What information do you need to look at this request?” Top overlay: “Ask what information is needed”.
- **00:26–00:35:** Stay with speaker to finish; no additional end-card seconds. Spoken words / verbatim subtitle: “Please keep policy numbers and contract pages out of comments and social messages. Ask our team how to share documents appropriately.” Top overlay: “Ask how to share documents”.

**Publishing captions:** Use the corresponding W4-MON Facebook or Instagram full caption verbatim. Subtitles must reproduce every spoken word above in order, split into readable short lines. Lower-middle subtitle area, high-contrast cream on dark green, not over faces; title overlays at top, no kinetic fear effects. No added promises, music claims or holiday-hour text.

**Recording requirements:** Original staff recording only; no generated staff, avatar, voice imitation or stock person. Staff participation consent first. Record clean speech in actual office; no customer voices, real documents, screens or unapproved background identities. Target approximately 140 spoken words per minute, then time the authentic read and keep final runtime 25–40 seconds.

**Claim support:** [1] [2]. Official sources were read November 16, 2026; recheck near publication. These citations are production notes, not appended to the exact social caption.

**Privacy-safe response:** Use `coi_request` below. **Required gates:** G1, G2, G3, G4, G5, G6, G9, G10.

### W4-VIDEO-2 — Can extra certificate wording change coverage?

**Proposed day only:** Friday, 2026-12-18. Parent assigns time after capacity checks.

**Useful hook:** Can extra certificate wording change coverage?

**Default destination path:** `/resources/certificate-of-insurance-shelby-county-tx`. Existing guide is live per brief; recheck publicly at release.

**Status:** Awaiting authentic consenting staff recording and approval; not finished footage. Replace the Friday still creative on any approved channel; use that topic's exact full FB/IG captions, not an extra placement.

**Duration:** Planned 35-second shot sequence; 79 spoken words, approximately 32.7 seconds at the stated pace. Final authentic read must be timed and approved within 25–40 seconds.

**Verbatim staff script:**

```text
If someone asks you to add wording to a certificate, keep the exact request for a private conversation. Ask: Does this wording match what is actually in the policy? A certificate of insurance cannot change or extend the policy’s coverage. This is not confirmation that a contract’s requirements are met. Contract interpretation belongs with the appropriate adviser. Please do not paste contract pages or policy numbers into social messages. Ask our team to confirm how to share the request.
```

**Precise shot / caption plan:**

- **00:00–00:08:** Vertical 9:16 authentic staff medium shot in cleared office. A small editorial Request card is visible, with no real or mock contract. Spoken words / verbatim subtitle: “If someone asks you to add wording to a certificate, keep the exact request for a private conversation.” Top overlay: “Asked to add wording?”.
- **00:08–00:14:** Cut to same staff hands placing Request and Policy cards side by side. Both cards contain only their headings. Spoken words / verbatim subtitle: “Ask: Does this wording match what is actually in the policy?” Top overlay: “Does the wording match the policy?”.
- **00:14–00:20:** Return to authentic speaker, neutral plain office background. Spoken words / verbatim subtitle: “A certificate of insurance cannot change or extend the policy’s coverage.” Top overlay: “A COI cannot extend coverage”.
- **00:20–00:26:** Continue speaker shot; no approval stamp or contract checkmark. Spoken words / verbatim subtitle: “This is not confirmation that a contract’s requirements are met. Contract interpretation belongs with the appropriate adviser.” Top overlay: “Contract questions are separate”.
- **00:26–00:35:** Same speaker closes naturally; no appended end-card time. Spoken words / verbatim subtitle: “Please do not paste contract pages or policy numbers into social messages. Ask our team to confirm how to share the request.” Top overlay: “Keep document details off social”.

**Publishing captions:** Use the corresponding W4-FRI Facebook or Instagram full caption verbatim. Burn in the complete verbatim spoken subtitles, including the contract boundary; do not replace them with abbreviated overlays. Cream/high-contrast dark-green subtitles lower-middle, top overlays, no face obstruction. No invented staff name or license claim.

**Recording requirements:** Authentic consenting Morrison staff and original audio only, no generated staff or synthesized voice. Cleared background and props, no real customer material or outside business identity. Target approximately 145 spoken words per minute; time the recorded take and retain a 25–40-second final runtime.

**Claim support:** [1] [2]. Official sources were read November 16, 2026; recheck near publication. These citations are production notes, not appended to the exact social caption.

**Privacy-safe response:** Use `wording` below. **Required gates:** G1, G2, G3, G4, G5, G6, G9, G10.

## Optional three-frame Story — substitute, not extra

**Proposed day only:** Sunday, 2026-12-20. Parent assigns time after capacity checks.

**Useful hook:** Before sending business paperwork

**Default destination path:** `/resources/certificate-of-insurance-shelby-county-tx`. Existing guide is live per brief; recheck publicly at release.

**Status:** Optional substitute only; approval and capacity hold. Use instead of, not alongside, the Sunday acquisition placement on the chosen channel. Parent verifies provider handling of all three frames and available capacity; if the sequence exceeds the channel's daily item ceiling, do not use it. Do not displace committed awards, sports or fishing.

### Frame 1 — 6 seconds

**Exact on-screen copy:**

```text
Before sending business paperwork…
Start with one general question.
“I have a certificate request. What is the next step?”
```

**Authentic visual:** Fresh authentic photograph of a cleared office desk and blank cream card; green/amber accents. No documents or personal details. No customer example.

**Alt text:** A blank card on a clear desk behind a prompt to start with a general question.

### Frame 2 — 6 seconds

**Exact on-screen copy:**

```text
Ask where to send it.
Keep policy numbers, signatures and contract pages out of comments and social messages.
```

**Authentic visual:** Fresh authentic close-up of an empty closed folder, no labels or papers; approved office background. Text clear and large.

**Alt text:** An empty closed folder behind a reminder to keep sensitive paperwork off social media.

### Frame 3 — 7 seconds

**Exact on-screen copy:**

```text
Mention any requested date in the direct conversation.
Ask about next-step timing.
Read our COI guide when it is useful.
```

**Authentic visual:** Authentic office tabletop photograph with a single blank card; leave a lower safe-zone space for the verified guide link sticker. No office-hours message.

**Alt text:** A blank card behind a prompt to ask about timing and read the COI guide.

**Link sticker, after destination check:** “Read the COI guide” → [https://morrison-ins.net/resources/certificate-of-insurance-shelby-county-tx](https://morrison-ins.net/resources/certificate-of-insurance-shelby-county-tx). No planned utility-page link.

**Claim support:** Original editorial preparation or privacy wording; no policy, outcome or local-event factual claim.

**Privacy-safe response:** Use `handoff` below. **Required gates:** G1, G2, G3, G5, G6, G9, G10.

## Saturday local prompt — only if no committed award/community placement

**Proposed day only:** Saturday, 2026-12-19. Parent assigns time after capacity checks.

**Useful hook:** What practical question helps you plan a first visit?

**Destination:** On-platform comments only; no website path.

**Status:** Conditional hold — only if there is no committed award/community placement. The absence of a commitment has not been verified by this subtask. If a commitment exists, retain it and do not publish this substitute.

**Facebook exact copy — 131 words:**

```text
For neighbors visiting a local business for the first time, what practical question helps you plan the visit?

Maybe you want to know whether an appointment is needed, which entrance visitors should use, or where to ask about accessibility. Pick one question—not a business name, address or customer story—and share it below if you would like.

The aim is a useful set of questions anyone can take to the business they plan to visit in Center or Shelby County. Details can change, so confirm arrangements directly with that business rather than relying on a comment thread.

Please leave private contact information, appointment details and personal accessibility or health information out of comments. No need to tag someone or recommend a business. A general question is enough to help a neighbor prepare.
```

**Instagram exact copy — 79 words:**

```text
What practical question helps you prepare for a first visit to a local business?

Appointment needed? Which entrance should visitors use? Where can someone ask about accessibility?

Share one general question, not a business name or customer story. Neighbors in Center and Shelby County can take those questions to the business they plan to visit and confirm details directly.

Please leave private contact, appointment and personal health information out of comments. No tags or recommendations needed—just a useful question.
```

**Visual brief:** Text-only community prompt is sufficient. If a visual is wanted, capture a new authentic blank notebook on a cleared Morrison office desk; overlay only the approved hook. Do not use outside storefronts, crowds, business names, fabricated notices, awards or holiday-hours information.

**Alt text:** A blank notebook behind the question: What practical question helps you plan a first visit?

**Claim support:** Original editorial preparation or privacy wording; no policy, outcome or local-event factual claim.

**Privacy-safe response:** Use `community` below. **Required gates:** G1, G2, G5, G7, G9, G10.

## Exact privacy-safe response templates

Use these only in response to an actual interaction, not as outreach or fabricated conversation. Do not ask for documents or personal details in social comments or inboxes. Phone-bearing variants are not GBP Update copy.

### `coi_request` — Public reply to a general COI request

```text
Thanks for asking. Please keep the request, policy numbers and any names out of comments and social messages. A general description of your question is enough to begin. Contact Morrison directly at (936) 598-2791 and ask the team to confirm what information is needed and how to share it appropriately.
```

### `operations` — Public reply about changed operations

```text
That is a useful topic to bring to a direct conversation. Please do not share customer names, addresses or employee details here. You can describe the change generally, then ask what else is needed to understand it. This thread cannot determine what your policy covers.
```

### `wording` — Public reply asking if certificate wording meets contract requirements

```text
We cannot confirm coverage or contract compliance in a comment. Please do not paste the wording or contract pages here. Contact Morrison directly and ask how to share the request appropriately. Whether an agreement meets your needs is a separate question for the appropriate adviser.
```

### `handoff` — Public reply asking where to send documents

```text
Please hold off on attaching documents here or in social messages. Contact Morrison directly at (936) 598-2791 and ask the team to confirm the appropriate document-sharing method. You can start with the general topic and discuss any requested date during that conversation.
```

### `timing` — Request with a deadline or demand for same-day issuance

```text
Please discuss the requested date directly with the team and ask about next-step timing. We cannot promise issuance, acceptance or turnaround in this thread. Keep policy details and the written request off social media; ask how to share them appropriately.
```

### `social_inbox` — Initial private social message without documents

```text
Thanks for reaching out. Please keep this social message general and do not attach policy documents, contract pages, signatures or personal information. You can contact Morrison directly at (936) 598-2791 to ask about the next step and an appropriate document-sharing method. Please confirm timing during that conversation.
```

### `sensitive_content` — Someone has posted or sent sensitive information

```text
For your privacy, please remove the document or identifying details from this thread if you can. We will not repeat them here. Please contact Morrison directly and ask how to share the information appropriately instead of reposting it in comments or social messages.
```

**Account-owner action, not public copy:** Do not quote, screenshot, forward or restate the sensitive content. Authorized account owner handles hiding/removal according to existing policy; do not promise deletion or secure handling by a social platform.

### `community` — Reply to the Saturday general-question prompt

```text
Thank you—that is a practical question to ask the business directly before a visit. Please keep names, appointment details and personal information out of the thread. We are collecting general questions, not confirming any business’s arrangements.
```

### `gbp_safe` — If a GBP response is appropriate and separately approved

```text
Thank you for the question. Please keep policy numbers, documents and identifying details out of public questions. Start with the general topic and ask our team to confirm the appropriate way to share information and discuss next steps. This public reply does not determine coverage or promise timing.
```

**Use note:** No phone, URL, domain or hashtag; use this no-contact variant on GBP. The Update itself is not a document intake channel.

## References

The brief’s corrected `cb030.html` link is the TDI workers’ compensation guide, not a general business or COI guide. No workers’ compensation legal claims are used here. Generic preparation questions are original editorial prompts, not quotations or invented customer examples. Only the successfully read official TDI sources below support insurance-specific claims. Existing Morrison guide availability is supplied by the brief and still requires release-time public verification.

**[1] Source support:** FAQ 4: no reference to other contract requirements on a certificate. FAQ 12: certificate statements must match the policy. FAQ 19: holder box cannot imply additional rights beyond policy or executed endorsement. FAQ 23: certificate cannot alter, amend or extend policy coverage. Checked 2026-11-16.

[1]: https://www.tdi.texas.gov/certificates/faq.html "TDI Certificates of Insurance Frequently Asked Questions"

**[2] Source support:** Opening text: certificate is informational, does not amend, extend or alter policy coverage, terms, exclusions or conditions, and does not represent a contract with the holder. Research source only; do not photograph or reproduce the form. Checked 2026-11-16.

[2]: https://www.tdi.texas.gov/certificates/documents/s722397.pdf "TDI-hosted Certificate of Insurance for Liability"

**[3] Source support:** Equipment/inventory, deliveries and hiring are activity topics to discuss with an agent. Used as prompts only, not conclusions about a reader's coverage. Checked 2026-11-16.

[3]: https://www.tdi.texas.gov/tips/what-insurance-do-i-need-to-run-a-business-from-home.html "TDI What insurance do I need to run a business from home?"
