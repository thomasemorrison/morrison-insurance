# Week 6 · December 28, 2026–January 3, 2027

**Theme:** New-year changes and renewal questions; no January price or trend predictions. **Status:** Review-ready drafts only; not approved, scheduled, published, or recorded.

Week 6 content only. No website files owned or changed. No user images used, assets acquired or created, external posts made, or agents delegated.

## Placement and release rules

Parent assigns times only after fresh capacity checks and approval.

7–10 total placements per channel for the week, including preserved commitments; never more than two per channel per day. This is a planning target, not a verified count or permission to fill occupied slots.

Videos are alternative formats for Monday and Friday topic-pair placements, not extra posts. The optional Story sequence replaces Sunday’s acquisition placement on the selected channel; it does not add volume. GBP candidates are separate channel candidates, not automatic cross-posts. LinkedIn remains manual hold.

- Tuesday 2026-12-29: existing five-school sports lane; preserve, research close to delivery, do not write invented future results.
- Thursday 2026-12-31: existing fishing lane; preserve, research close to delivery, do not invent future conditions or fishing reports.
- Existing approved/active awards and old review-ready library remain intact. Check every day for those commitments before adding these candidates.
- Saturday 2027-01-02: use the committed award/community placement if one exists. The optional local prompt is eligible only if no award/community commitment occupies that lane.

### Approval, capacity, privacy and source gates

- Owner must approve the final exact copy, chosen channel, day, destination and authentic visual before any scheduling or publication; these files grant no automatic publication permission.
- Parent must freshly read Facebook and Instagram capacity separately, including active/approved awards, Tuesday sports, Thursday fishing and old-library posts. Maximum two per channel per day. Preserve commitments and defer a new candidate rather than displace one without separate authorization.
- After any separately approved scheduling, read back provider day/time, channel, exact caption, destination and media. Do not treat a draft, local file or submitted request as confirmed scheduling.
- Use only existing guide destinations listed here until an actual public release is verified. /start-here, /prepare-for-a-conversation and /what-to-expect are planned and not verified live in this task. Any later destination swap requires public release verification, matching revised CTA copy and separate approval.
- Before release, check each selected destination’s public page and mobile experience. For Instagram captions that mention the profile link, verify that the approved profile/link landing path really exposes that exact guide; otherwise hold the candidate until a specific revised CTA is approved. Do not silently claim a planned page or current bio destination is live.
- Reopen the cited official TDI pages close to the proposed delivery day and recheck the narrow claims used. No January prices, rate trends, new legal deadlines, coverage answers, savings, guarantees or claim outcomes are asserted.
- Do not infer January 1 or other holiday office availability from posted Monday–Friday contact hours. Confirm actual availability separately before adding an hours statement or invitation implying same-day service; this bundle makes none.
- All photo and staff-video briefs await new authentic capture and consent. No generated staff, stock customer scenes, real customer documents, testimonial/case claims, visible screens, identities or private business details. Review reflections and background audio before approval.
- Do not publish any customer/partner identity, including Boles Feed, without separate explicit consent. Do not ask for policy numbers, dates of birth, license numbers, full addresses, account details, documents or claim details in comments or social messages.
- LinkedIn candidates require a manual account/channel check and individual approval; do not auto-publish or create a recurring lane. GBP requires authentic photo review, Update preview and matching approved button destination; never paste metadata URLs into the GBP body.
- No paid-media, tracking, form, consent, GA4/GTM/Ads/HubSpot, recurring automation, outreach, review solicitation or artificial lead submission changes. Clicks/followers are not qualified leads.

### Destination status

- [/resources/car-insurance-quote-checklist-center-tx](https://morrison-ins.net/resources/car-insurance-quote-checklist-center-tx): Already live per supplied brief; parent rechecks public release and relevance before use.
- [/resources/farm-insurance-vs-homeowners-insurance](https://morrison-ins.net/resources/farm-insurance-vs-homeowners-insurance): Already live per supplied brief; parent rechecks public release and relevance before use.
- [/resources/switch-car-insurance-texas-without-gap](https://morrison-ins.net/resources/switch-car-insurance-texas-without-gap): Already live per supplied brief; parent rechecks public release and relevance before use.
- [/resources/certificate-of-insurance-shelby-county-tx](https://morrison-ins.net/resources/certificate-of-insurance-shelby-county-tx): Already live per supplied brief; used as background reading, not a certificate or contract promise; parent rechecks before use.

`/start-here`, `/prepare-for-a-conversation` and `/what-to-expect` are planned, not verified live. No publishable CTA in this bundle sends readers to them. Any swap requires verified public release, revised CTA copy and separate approval.

**Source correction:** https://www.tdi.texas.gov/pubs/consumer/cb030.html currently opens the **Workers’ compensation insurance guide**, checked 2026-11-16. Not used as a general small-business or certificate source. Sunday and LinkedIn business prompts are original editorial preparation suggestions, not statements of coverage, legal requirements or contractual sufficiency.

## Four independent acquisition topic pairs

### Monday · 2026-12-28 — Same car. Different routine?

**Reader question:** What has changed about how I use my car, and what should I ask about that change?

A changed-use note, rather than another price-comparison or generic renewal reminder.

**Destination:** [/resources/car-insurance-quote-checklist-center-tx](https://morrison-ins.net/resources/car-insurance-quote-checklist-center-tx). Proposed day only; no assigned time.

#### Facebook — 129 words

```text
Same car. Different routine?

Before a renewal conversation, ask yourself: has the way I use my car changed? A different commute, a change in who drives, or plans for work-related driving can give you a specific question to bring—not an answer to guess.

Try this opening: “My driving routine is changing. What should we discuss, and what information do you need from me?” Texas insurance guidance includes asking whether a policy covers how you use your car and whether there are exclusions.

Keep a general note for yourself. Please leave names, policy numbers, driver information, and documents out of comments and social messages. When you contact Morrison, ask how to share anything needed and confirm next-step timing.

Our auto quote checklist can help you organize that first question:
https://morrison-ins.net/resources/car-insurance-quote-checklist-center-tx
```

#### Instagram — 77 words

```text
Same car. Different routine?

A changed commute, different driver, or possible work-related use gives you a question to bring to a renewal conversation.

Try: “My driving routine is changing. What should we discuss, and what information do you need?”

Keep the specifics in your own notes—not in comments or DMs. Ask Morrison how to share any needed information and confirm next-step timing.

Our auto quote checklist is a useful starting point. Find it through the profile link.
```

**Authentic filming/visual brief:** Authentic, newly captured close-up of a consenting Morrison staff member’s hand placing an unfilled cream note card reading ‘What changed about my driving?’ beside a pen on a clear office desk. Warm green/cream/amber accents, everyday clothes if visible. No keys with identifying tags, vehicle plates, customer paperwork or screen. Compose separate 4:5 feed crops with comfortable text-safe space. Alt text: ‘A blank question card and pen on a clear desk.’ Video W6-VIDEO-1 can replace this still using these exact captions.

**Source support:** The policy-use/exclusions question is supported by TDI [1]. Changed-routine examples and suggested opening are editorial questions, not coverage or pricing claims.

**Privacy-safe replies:** GENERAL, AUTO_CHANGE, SENSITIVE; exact responses are below.

**Additional holds:** Verify the approved Instagram profile route exposes this exact checklist. No response-time or January-premium inference; staff must confirm the real next step during the conversation.

### Wednesday · 2026-12-30 — What will that space be used for?

**Reader question:** Is a planned use of my home or rural-property space different from how it is used today?

Separates a planned change from current use so the reader can ask a useful home/rural-property question without self-diagnosing coverage.

**Destination:** [/resources/farm-insurance-vs-homeowners-insurance](https://morrison-ins.net/resources/farm-insurance-vs-homeowners-insurance). Proposed day only; no assigned time.

#### Facebook — 137 words

```text
What will that space be used for?

If your new-year plans involve a room, shed, or another part of your property, separate two things in your own notes: how you use it today, and what you are considering next. You do not have to turn a possibility into a finished plan before asking a question.

A useful opening is: “I’m thinking about using this space differently. What should I explain before we discuss my policy?”

Texas insurance guidance reminds readers that home coverages vary by company. Reading your policy or asking your agent is better than assuming a general article answers your situation.

Our home-versus-farm guide offers background for that conversation:
https://morrison-ins.net/resources/farm-insurance-vs-homeowners-insurance

Please keep property addresses, household details, photos, and documents out of comments and DMs. Ask Morrison what information is needed and how to share it.
```

#### Instagram — 77 words

```text
What will that space be used for?

For a room, shed, or other property space, make two private notes: “used for this now” and “considering this next.”

Then ask: “What should I explain before we discuss my policy?” A plan is a question to discuss, not a coverage answer.

Our home-versus-farm guide offers background through the profile link. Keep addresses, household details, photos, and paperwork out of comments and DMs. Ask Morrison how to share anything needed.
```

**Authentic filming/visual brief:** Authentic new staff-hands photograph at a cleared Morrison desk. Two empty cream cards have only the headings ‘Today’ and ‘Considering next’; place a pen between them. Do not fill in a real property story or depict a customer’s home. No satellite maps, addresses, family photos, files or screens. Warm green/cream/amber, plain tabletop, separate 4:5 crops. Alt text: ‘Two unfilled cards labeled Today and Considering next.’

**Source support:** The company-specific coverage reminder is supported by TDI [2]. Room/shed planning is an original question prompt; no home, farm or business coverage determination is made.

**Privacy-safe replies:** PROPERTY, SENSITIVE, GENERAL; exact responses are below.

**Additional holds:** Verify the guide remains public and relevant; do not replace it with an unreleased utility page. Verify the Instagram profile route to this guide and approve authentic photo capture.

### Friday · 2027-01-01 — A new calendar. Your own policy dates.

**Reader question:** What are my actual policy dates, and which detail needs explaining before a renewal or switch?

Uses January 1 as a personal planning cue, not an invented renewal deadline, holiday-hours notice or price trend.

**Destination:** [/resources/switch-car-insurance-texas-without-gap](https://morrison-ins.net/resources/switch-car-insurance-texas-without-gap). Proposed day only; no assigned time.

#### Facebook — 134 words

```text
A new calendar. Your own policy dates.

If you are thinking about an auto renewal or a possible switch, start with the dates on your own paperwork—not a guess based on January 1. Write them in a private reminder, then add one question about a detail you want explained, such as a deductible or coverage limit.

If you are considering switching, Texas insurance guidance says not to cancel your current policy until you have the new policy or a written statement that proves you have coverage.

Our guide can help you prepare questions about the handoff:
https://morrison-ins.net/resources/switch-car-insurance-texas-without-gap

Please do not post policy dates, numbers, or paperwork here. When you contact Morrison, ask what information is needed, how to share it, and when to follow up. This is a planning prompt, not a holiday-hours announcement.
```

#### Instagram — 81 words

```text
A new calendar. Your own policy dates.

Thinking about an auto renewal or switch? Make a private reminder from your actual paperwork, then choose one detail you want explained.

Texas insurance guidance says not to cancel your current policy until you have the new policy or a written statement proving coverage.

Our switching guide is available through the profile link. Keep dates, policy numbers, and documents out of comments and DMs. Confirm next-step timing directly; this is not a holiday-hours notice.
```

**Authentic filming/visual brief:** Authentic close-up captured later at the Morrison office: consenting staff hand beside a blank planner page and an unfilled note headed ‘My policy dates / My question’. Do not insert a real date, renewal notice, insurer logo or January premium. A small ‘2027’ paper calendar tab may be an ordinary prop, but it must not imply every policy renews on January 1. No customer paperwork, screen or holiday-open signage. Warm green/cream/amber, 4:5 crops. Alt text: ‘An unfilled planner and a card for a policy-date question.’ Video W6-VIDEO-2 may replace the still with these exact captions.

**Source support:** The cancellation precaution is supported by TDI [1]. TDI [3] identifies the declaration page as a summary of coverages, limits and deductibles. No specific effective date, renewal obligation or January pricing claim is made.

**Privacy-safe replies:** DATES, HOURS, PRICE, SENSITIVE; exact responses are below.

**Additional holds:** Recheck TDI’s switching precaution immediately before approval. Do not imply the office is open or responding on January 1. Verify the Instagram profile route exposes the switching guide.

### Sunday · 2027-01-03 — What is decided—and what is still a possibility?

**Reader question:** For a business paperwork conversation, which change is confirmed, which is tentative, and what should happen next?

Helps a business owner distinguish confirmed operations from tentative new-year plans and ask about the handoff, rather than promising a certificate outcome.

**Destination:** [/resources/certificate-of-insurance-shelby-county-tx](https://morrison-ins.net/resources/certificate-of-insurance-shelby-county-tx). Proposed day only; no assigned time.

#### Facebook — 137 words

```text
What is decided—and what is still a possibility?

For a small business planning its next few months, that distinction can make the first insurance conversation easier to follow. In your private notes, separate a confirmed change in your work from an idea you are still considering. Then add the question you want answered.

If someone has asked for insurance paperwork, try: “I have a request to discuss. What information do you need, how should I share it, and when should I follow up?” You can explain the general purpose first without posting a contract or identifying a customer.

Our certificate-of-insurance guide offers background reading:
https://morrison-ins.net/resources/certificate-of-insurance-shelby-county-tx

Keep customer names, contract details, financial information, and documents out of comments and DMs. Confirm the actual next step with Morrison; a social post cannot settle a specific paperwork or coverage question.
```

#### Instagram — 78 words

```text
What is decided—and what is still a possibility?

For a business conversation, separate confirmed changes from ideas you are considering. Add one question in your own notes.

For a paperwork request, ask: “What information do you need, how should I share it, and when should I follow up?”

Our certificate-of-insurance guide offers background through the profile link. Keep customer names, contracts, financial details, and documents out of comments and DMs. Confirm the actual next step directly with Morrison.
```

**Authentic filming/visual brief:** Authentic new photograph of a consenting Morrison staff member’s hand setting down three blank note cards headed ‘Confirmed’, ‘Considering’, and ‘Next question’. Clear office desk, no contract, real certificate, customer name, account number or computer display. Plain-spoken service look, not a suited sales scene. Warm green/cream/amber, 4:5 crops. Alt text: ‘Three unfilled cards for confirmed plans, possible plans, and a next question.’

**Source support:** Original editorial preparation questions, not coverage, legal or contractual claims. The existing Morrison guide is a destination only. The supplied cb030 URL is correctly identified as workers’ compensation and is not used here.

**Privacy-safe replies:** BUSINESS, GENERAL, SENSITIVE; exact responses are below.

**Additional holds:** Do not promise certificate issuance, contractual acceptance, licensed review or turnaround time. Verify the approved Instagram profile route exposes the existing guide. If the Story is chosen instead, replace this placement on that channel rather than adding another.

## Two GBP Update candidates

Only the fenced Update body is publishable copy. Destination URLs below are button metadata, never body text. All visual briefs await authentic photography.

### W6-GBP-1 · Monday 2026-12-28 — Has your driving routine changed?

GBP Update candidate; manual approval hold. Proposed day only. **Body length:** 644 characters.

```text
Has your driving routine changed? Before a renewal conversation, make a private note about what is different: a commute, who drives, or work-related use you are considering.

Try asking: “What should we discuss about this change, and what information do you need?” Texas insurance guidance includes asking whether a policy covers how you use your car and whether there are exclusions.

The auto quote checklist offers a starting point for organizing your question. Keep policy numbers, driver details, and documents out of public replies and social messages. Ask our team how to share anything needed, then confirm the next step and its timing.
```

**Button:** Learn more; destination [/resources/car-insurance-quote-checklist-center-tx](https://morrison-ins.net/resources/car-insurance-quote-checklist-center-tx). Button metadata only; URL must not be placed in Update body.

**Required authentic image:** Required new real photo of consenting Morrison staff hands with an unfilled ‘What changed about my driving?’ card on a clean office desk. No generated people, stock image, customer material, vehicle plate or screen. Capture landscape with central crop-safe card and no promotional phone or domain overlay. Alt text: ‘A question card on a clear office desk.’

**Source support:** Policy-use/exclusions question supported by TDI [1]. No coverage answer or January premium assertion.

**Privacy-safe replies:** AUTO_CHANGE, GENERAL, SENSITIVE.

**Holds:** Authentic photo and consent required; body contains no phone, URL, domain or hashtag. Check current GBP Update preview and matching public button path; approval is separate from FB/IG. Parent assigns time only after relevant provider/account checks; no automatic publication.

### W6-GBP-2 · Friday 2027-01-01 — Use your own policy dates as the planning cue.

GBP Update candidate; manual approval hold. Proposed day only. **Body length:** 660 characters.

```text
A new calendar is a useful reminder to find your own policy dates and write down one question you want explained. Keep that note private; you do not need to share a renewal notice in a public reply or social message.

If you are considering an auto insurance switch, Texas insurance guidance says not to cancel your current policy until you have the new policy or a written statement that proves you have coverage.

Our switching guide offers background for a conversation about next steps. Ask what information is needed, how to share it, and when to follow up. This is a planning reminder, not a statement about January prices or holiday office availability.
```

**Button:** Learn more; destination [/resources/switch-car-insurance-texas-without-gap](https://morrison-ins.net/resources/switch-car-insurance-texas-without-gap). Button metadata only; URL must not be placed in Update body.

**Required authentic image:** Required new authentic office photo: staff hand next to an unfilled planner and ‘My dates / My question’ card. No real renewal notice, filled date, personal calendar, screen, insurer logo or signage implying the office is open on January 1. Landscape crop with clear neutral background. Alt text: ‘An unfilled planner and a card for a policy question.’

**Source support:** Specific cancellation precaution supported by TDI [1]; calendar planning and handoff questions are editorial prompts.

**Privacy-safe replies:** DATES, HOURS, PRICE, SENSITIVE.

**Holds:** Recheck cited TDI precaution close to delivery and selected public guide. Authentic image and preview approval required; no phone, URL, domain or hashtag in body. No inferred January 1 availability; parent assigns time after separate approval.

## Two LinkedIn manual-hold candidates

### W6-LI-1 · Wednesday 2026-12-30 — Confirmed change or possible plan?

Manual hold; no scheduling or publication authorization. Proposed day only. **Copy:** 94 words.

```text
A useful new-year business question: what is confirmed, and what is still a possibility?

Before an insurance conversation, separate those two categories in private notes. Add the general purpose of any paperwork request and the question you need to discuss. You can start there without putting a customer’s name or contract into a social message.

Our certificate-of-insurance guide offers background: https://morrison-ins.net/resources/certificate-of-insurance-shelby-county-tx

Ask what information is needed, how it should be shared, and when to follow up. Confirm the actual next step directly with Morrison; a post cannot settle a particular contract or coverage question.
```

**Destination path:** `/resources/certificate-of-insurance-shelby-county-tx`.

**Visual brief:** Optional authentic new staff-hands photo of empty ‘Confirmed / Considering’ cards on a cleared office desk. No customer identity, real request, contract or certificate. Text-only manual post is acceptable if no approved authentic photo exists.

**Source support:** Original editorial preparation prompt. No workers’ compensation, certificate sufficiency, contract or coverage claim.

**Privacy-safe replies:** BUSINESS, SENSITIVE.

**Holds:** Verify account ownership, approved audience/channel, public guide and preview manually. Separate individual approval; no auto-cross-posting or recurring LinkedIn lane. No promised certificate, licensed review, timing or outcome.

### W6-LI-2 · Sunday 2027-01-03 — Make the next step part of the question.

Manual hold; no scheduling or publication authorization. Proposed day only. **Copy:** 100 words.

```text
One useful question for a new-year renewal conversation is about the handoff itself: “What do you need from me next, how should I share it, and when should I follow up?”

That gives you a practical starting point without making a public post into a paperwork exchange. Keep policy numbers, documents, customer details, and financial information out of comments and social messages.

For an auto conversation, our quote checklist offers background: https://morrison-ins.net/resources/car-insurance-quote-checklist-center-tx

Start with the general question you want explained. Confirm the actual next step and timing directly with Morrison rather than assuming a response window from a social post.
```

**Destination path:** `/resources/car-insurance-quote-checklist-center-tx`.

**Visual brief:** Optional newly captured authentic staff hand beside a blank card headed ‘What / How / When’. Clean desk, warm cream/green accents, no paperwork or screen. Use text-only if no approved authentic photo is available.

**Source support:** Original editorial service-preparation and privacy wording; no response-time or coverage assertion.

**Privacy-safe replies:** GENERAL, SENSITIVE, HOURS.

**Holds:** Manual account/channel and destination check, exact-copy approval and preview required. No automatic publication, instant-quote implication or response-time guarantee.

## Two authentic-staff recording scripts

These are scripts, not generated staff, finished footage, or permission to record a particular person. Each video is a format replacement for its named acquisition placement; use that topic’s exact Facebook/Instagram caption.

### W6-VIDEO-1 · Monday 2026-12-28 — Start with the changed routine.

**Status:** Verbatim script awaiting authentic staff consent, recording and approval; no finished footage. **Duration target:** 33 seconds; final measured duration must be 25–40 seconds. **Spoken words:** 69.

**Replacement:** W6-MON still-image acquisition placement on the chosen channel; use its exact FB/IG caption, not an additional post.

**Destination:** `/resources/car-insurance-quote-checklist-center-tx`; no assigned time.

#### Verbatim spoken script

```text
Before a renewal conversation, try one question: what has changed about how I use my car? Maybe your commute is different, or you’re considering work-related driving. Write a general note for yourself. Keep names, policy numbers, and documents out of comments and messages. When you call Morrison, ask what information is needed and how to share it. Start with the question, then confirm the next step and its timing.
```

#### Precise shot, heading and caption plan

**0–7 seconds.** Consenting actual Morrison staff member, eye-level chest-up vertical shot in an ordinary office corner cleared of screens and files; speak to camera.

On-screen heading: **What changed about my driving?**.

Exact spoken subtitle for this segment:
```text
Before a renewal conversation, try one question: what has changed about how I use my car?
```

**7–14 seconds.** Cut to the same staff member’s hands putting an unfilled ‘My question’ card beside a pen; record the same staff voice, not synthetic narration.

On-screen heading: **A general note for yourself**.

Exact spoken subtitle for this segment:
```text
Maybe your commute is different, or you’re considering work-related driving. Write a general note for yourself.
```

**14–21 seconds.** Return to the same staff member, calm natural delivery. No customer area visible and no other voice audible.

On-screen heading: **Keep personal details private**.

Exact spoken subtitle for this segment:
```text
Keep names, policy numbers, and documents out of comments and messages.
```

**21–33 seconds.** Continue direct-to-camera and end on the same real staff member; no stock ending or implied immediate response.

On-screen heading: **Ask what, how, and when**.

Exact spoken subtitle for this segment:
```text
When you call Morrison, ask what information is needed and how to share it. Start with the question, then confirm the next step and its timing.
```

**Recording and caption requirements:** Record vertical 1080×1920, steady camera, quiet private office, ordinary clothing and natural light. No customer names, policy paperwork, screens, reflections, background conversations, synthetic staff or generated footage. Burn in the exact spoken words, split into readable two-line subtitle chunks inside central safe area; headings sit above subtitles and stay out of platform controls. Record a stopwatch rehearsal at a natural pace, aiming for 33 seconds; revise and reapprove if the actual full cut falls outside 25–40 seconds. No music needed. No promise of licensed review or availability.

**Source support:** TDI [1] supports asking about how the car is used. Script otherwise provides editorial preparation and privacy steps, not a coverage answer.

**Privacy-safe replies:** AUTO_CHANGE, GENERAL, SENSITIVE.

**Holds:** Confirm actual staff participation/consent; no staff name or license claim invented. Review recorded voice, all frames and exact subtitles; measure final duration. Replace rather than add to W6-MON and use its verified destination/profile-route gate.

### W6-VIDEO-2 · Friday 2027-01-01 — The calendar is a reminder, not your policy paperwork.

**Status:** Verbatim script awaiting authentic staff consent, recording and approval; no finished footage. **Duration target:** 34 seconds; final measured duration must be 25–40 seconds. **Spoken words:** 72.

**Replacement:** W6-FRI still-image acquisition placement on the chosen channel; use its exact FB/IG caption, not an additional post.

**Destination:** `/resources/switch-car-insurance-texas-without-gap`; no assigned time.

#### Verbatim spoken script

```text
Turning the calendar to January doesn’t answer a renewal question. For your own notes, find the policy dates and write down one detail you want explained. If you’re considering a switch, Texas insurance guidance says not to cancel your current policy until you have the new policy or a written statement that proves you have coverage. Keep paperwork private. Call Morrison with the general question, and confirm what happens next and when.
```

#### Precise shot, heading and caption plan

**0–5 seconds.** Consenting actual Morrison staff member in cleared office, eye-level vertical medium close-up. Use no ‘open today’ sign or holiday-hour overlay.

On-screen heading: **Your dates. Your question.**.

Exact spoken subtitle for this segment:
```text
Turning the calendar to January doesn’t answer a renewal question.
```

**5–13 seconds.** Same staff member’s hand touches an unfilled planner and an empty ‘My question’ card; real voice continues.

On-screen heading: **Keep the note private**.

Exact spoken subtitle for this segment:
```text
For your own notes, find the policy dates and write down one detail you want explained.
```

**13–27 seconds.** Back to the same real staff member. Hold a steady shot through the complete precaution so it is not cut off or shortened.

On-screen heading: **Considering a switch? Ask first.**.

Exact spoken subtitle for this segment:
```text
If you’re considering a switch, Texas insurance guidance says not to cancel your current policy until you have the new policy or a written statement that proves you have coverage.
```

**27–34 seconds.** Continue direct-to-camera, calm finish; no simulated customer interaction or promise of same-day help.

On-screen heading: **Confirm the next step and timing**.

Exact spoken subtitle for this segment:
```text
Keep paperwork private. Call Morrison with the general question, and confirm what happens next and when.
```

**Recording and caption requirements:** Record vertical 1080×1920 with ordinary clothing, natural light and a quiet cleared office background. No real planner entries, customer documents, screen, reflections or private audio. Exact spoken subtitles burned in, readable two-line chunks inside central safe area; keep the full switching precaution in captions and voice. Actual consenting staff only; no generated staff or synthetic voice. Target 34 seconds, check stopwatch rehearsal and final full cut; hold any cut outside 25–40 seconds for revision and approval. No music needed. Recording may happen before the proposed day; the content does not establish January 1 office availability.

**Source support:** Cancellation precaution supported by TDI [1]; recheck that narrow statement before recording approval and release.

**Privacy-safe replies:** DATES, HOURS, SENSITIVE.

**Holds:** Recheck official source, authentic staff consent, exact spoken precaution and caption fidelity. Measure actual duration and inspect all background details. Replace rather than add to W6-FRI; retain its holiday-hours and destination gates.

## Optional three-frame Story — substitute, not extra

**Proposed day:** Sunday 2027-01-03. **Hook:** Separate the plan from the question.

W6-SUN acquisition placement on the selected FB or IG channel; do not run both the feed candidate and this sequence as extra volume without separate capacity and approval.

**Destination:** [/resources/certificate-of-insurance-shelby-county-tx](https://morrison-ins.net/resources/certificate-of-insurance-shelby-county-tx). No assigned time.

### Frame 1 · 6 seconds

```text
New-year business plans?

What is confirmed?
What are you still considering?

Make two private notes.
```

**Visual plan:** Later production: clean cream background, warm green type and small amber divider. Large text with safe margins; no customer imagery or filled example.

### Frame 2 · 7 seconds

```text
For a paperwork conversation, ask:

“What information do you need, how should I share it, and when should I follow up?”
```

**Visual plan:** Same restrained type-only visual treatment. Break the question into three readable lines; no faux certificate, contract or customer story.

### Frame 3 · 7 seconds

```text
Keep names, contracts, and documents out of DMs.

Read our certificate-of-insurance guide for background.

Confirm the actual next step with Morrison.
```

**Exact link-sticker label:** Paperwork background.

**Visual plan:** Same cream/green layout, amber CTA underline. Place a single approved link sticker to the existing guide below text, clear of platform controls. No promise of certificate issuance.

**Source support:** Original editorial preparation sequence; no coverage, legal or contract assertion. Existing guide is the destination only.

**Privacy-safe replies:** BUSINESS, SENSITIVE.

**Holds:** No Story assets created in this task; parent approves later production and preview. Verify the public existing guide and supported clickable sticker on the selected channel; if unavailable, hold until a specific approved CTA is supplied. Replace Sunday’s selected acquisition placement, not add volume. Check existing commitments first.

## Saturday local-engagement prompt — only if no committed award

**Proposed day:** Saturday 2027-01-02. **Status:** Conditional local-engagement candidate only if no committed award/community placement exists.

**Hook:** A useful public resource for a new neighbor. **Question:** What public local resource would you point a new neighbor toward for everyday information?

### Facebook — 120 words

```text
Center and Shelby County neighbors: what public local resource would you point a new neighbor toward for everyday information?

Think of a public organization’s information about community activities, county services, or where to ask a general question. Share the organization’s public name and the kind of information it offers—not a person’s contact details or a private situation.

A useful reply can be as simple as: “This organization is a place to look for information about this topic.” Please check its official information before relying on an address, schedule, or service.

Keep household details, personal stories, and customer names out of the thread. This is a space for helpful starting points, not reviews, endorsements, insurance advice, or assumptions about holiday availability.
```

### Instagram — 68 words

```text
Center and Shelby County neighbors: what public local resource would you point a new neighbor toward for everyday information?

Share a public organization’s name and the general topic it helps people find information about. Leave out personal contact details, private situations, and customer names.

Please check official information before relying on an address, schedule, or service. We’re collecting helpful starting points—not reviews, endorsements, or assumptions about holiday availability.
```

**Destination:** Native moderated comment thread only; no website CTA or fabricated local recommendation. A useful community prompt does not require a website destination.

**Visual brief:** No asset created. If approved later, an authentic new photo of an unfilled ‘Useful local information’ note card on a clean office desk; no map pin, specific organization’s logo, private property or identifiable neighbor. Text-only posting is acceptable.

**Source support:** A question, not an assertion that a particular organization, service or event exists. No external posts were read or amplified in this task.

**Privacy-safe replies:** COMMUNITY, SENSITIVE.

**Holds:** Check the current awards/community calendar; if any committed placement occupies the lane, omit this prompt and preserve it. Check separate daily capacity and approval; do not ask for reviews or imply a partnership. Moderate suggestions and verify named organization/service/schedule through its official information before any separate amplification; do not invent closures or availability.

## Privacy-safe exact response templates

These are optional, situation-matched replies awaiting normal moderation approval, not automated responses. Do not paste phone-bearing replies into a GBP Update body. Contact by phone avoids collecting sensitive information in social channels; no answer or response time is guaranteed.

### GENERAL — Reader wants to begin or asks how the handoff works.

```text
You can start with the general question you want explained. Please keep policy numbers, documents, and personal details out of comments and DMs. Call Morrison at (936) 598-2791 to ask what information is needed, how to share it, and what next-step timing to expect.
```

**Internal handling:** No promised reply window. The office confirms actual timing and the appropriate sharing method during contact.

### AUTO_CHANGE — Reader describes a driving-use change or asks whether it is covered.

```text
That is a useful question to discuss directly. A general post cannot tell you how a particular policy handles a change in driving. Please do not share driver details or paperwork here. Call Morrison at (936) 598-2791 and ask what information is needed and how to share it.
```

**Internal handling:** Do not answer eligibility, premium or coverage in-thread; do not collect license numbers or driver identities in DM.

### PROPERTY — Reader asks about a room, shed, home business or rural-property use.

```text
You can begin by explaining the general change you are considering. Please leave addresses, household details, photos, and documents out of comments and DMs. Call Morrison at (936) 598-2791 to ask what information is needed for that conversation and how to share it. A general guide is not a coverage answer for your property.
```

**Internal handling:** No home/farm/business coverage conclusion, site-visit promise or property-data request in social channels.

### DATES — Reader asks for a renewal deadline or switching date.

```text
Please keep the dates and details on your paperwork private. For your specific renewal or switching question, call Morrison at (936) 598-2791 and ask what information is needed, how to share it, and when to follow up. We cannot confirm a policy’s timing from a social comment.
```

**Internal handling:** Do not invent a universal January deadline or suggest cancellation from a comment. Route to real conversation.

### BUSINESS — Reader has a certificate or other business paperwork request.

```text
You can start with the general purpose of the request, without naming a customer or sharing a contract here. Please keep documents and business details out of comments and DMs. Call Morrison at (936) 598-2791 to ask what information is needed, how to share it, and what the actual next step will be.
```

**Internal handling:** No certificate issuance, acceptance, licensed review, contractual sufficiency or turnaround promise. No partner/customer identity without separate consent.

### SENSITIVE — Someone posts or offers sensitive information in comments or messages.

```text
For your privacy, please remove any personal or policy details from this thread and do not send documents here. Please call Morrison at (936) 598-2791 to ask how to share anything needed through the appropriate channel. We will not repeat those details in our reply.
```

**Internal handling:** Do not quote, screenshot, export or reuse the details. If details have already been sent privately, do not ask for more. An authorized moderator follows existing removal/hiding and retention policy; do not invent a privacy guarantee or new retention rule.

### HOURS — Reader asks about January 1, holiday hours or visiting.

```text
Please confirm the schedule directly with Morrison at (936) 598-2791 before making a trip. This post is not a holiday-hours notice, and we do not want to guess about availability or next-step timing.
```

**Internal handling:** Use verified current office guidance only if separately supplied and approved. Posted weekday hours do not establish holiday availability.

### PRICE — Reader asks about January prices, increases, trends or savings.

```text
We are not making January price predictions or savings promises here. If you have a renewal or comparison question, please keep your paperwork private and call Morrison at (936) 598-2791 to ask what information is needed for a conversation about your own details.
```

**Internal handling:** No future trends, blanket premium assertions, savings or comparative outcome claims.

### COMMUNITY — Reader offers a public local resource in the optional Saturday thread.

```text
Thank you for sharing a public starting point. Please leave out personal contact details and private situations. Anyone considering it should check the organization’s official information for current services and scheduling before relying on the suggestion.
```

**Internal handling:** Do not imply Morrison endorsement, partnership, award or verified availability. Any separate amplification requires official-source verification and approval.

## Final handoff checks

- Four independent topic pairs: Monday changed car use; Wednesday current versus planned property use; Friday actual policy-date planning; Sunday confirmed versus tentative business changes and paperwork handoff.
- All FB topic captions 100–180 words and all IG topic captions 60–100 words; counts include displayed destination URLs as one token. GBP bodies no more than 1,500 characters and contain no phone, URL, domain or hashtag. LinkedIn 80–120 words.
- Two staff scripts have exact spoken text and matching shot/subtitle segments; actual duration must be measured after recording, not assumed from estimates.
- No January prices/trends, product push, fear, guarantees, savings, testimonial/case claims, fabricated local facts or closures, customer identity, legal/coverage conclusions or holiday-hour claims.
- No supporting new utility page is advertised as live. Existing guide CTA and Instagram profile paths must pass release/recheck gates.
- No scheduling, publishing, website changes or asset production performed. Parent owns timing and all release/approval decisions.

**Counts:** Whitespace-separated words; each displayed URL counts as one token. Character counts include body line breaks. Staff timing is a recording target, not a measured finished-video duration.

## References

Official pages were opened and read November 16, 2026; recheck the narrow statements close to the proposed release day. Business, handoff and community questions are original editorial prompts, not external factual claims.

[1]: https://www.tdi.texas.gov/consumer/auto-insurance-shopping-guide.html "TDI — How to shop smart for auto insurance"
[2]: https://www.tdi.texas.gov/pubs/consumer/cb025.html "TDI — Homeowners insurance guide"
[3]: https://www.tdi.texas.gov/pubs/consumer/cb020.html "TDI — Automobile insurance guide"
