# Week 1 — November 23–29, 2026

**Theme:** Bring one renewal question; a first conversation without paperwork overload.

**Status:** Review-ready copy only; no assets acquired or created; no external drafts, schedules, publication or website changes.

Prepared November 16, 2026. None. Parent owns all website integration, release verification and destination acceptance. Proposed days only. All times remain null. Parent assigns times only after a fresh channel-by-channel capacity check and approvals. All proposed days are local to America/Chicago. No times have been assigned and no capacity has been checked in this task.

## Placement rules and preserved anchors

Count active schedules, same-day published placements omitted by the planner, old-library placements and authorized reservations separately for FB and IG. Four acquisition pairs plus preserved Tuesday sports and Thursday fishing provide six potential placements per channel; a genuinely open Saturday community slot would provide a seventh. Existing commitments can already satisfy the weekly target. Do not invent volume or move/delete old content to hit a target. Check applicable cross-network capacity too before GBP or any separately approved LinkedIn placement.

Videos replace the matching Monday or Friday topic placement; they are not additional placements. The optional Story replaces one Wednesday IG placement after explicit format approval, never adds one. Its three frames count as one sequence and must not run alongside the replaced feed placement. Keep the separate Wednesday FB placement only if its own capacity permits.

This file does not authorize publication, scheduling, a recurring task, outreach, collaboration, paid changes or tracking-setting changes.

**Tuesday 2026-11-24:** Preserved five-school sports lane. No scores, fixtures or future sports copy produced here; research close to delivery under its existing approval gates.

**Thursday 2026-11-26:** Preserved fishing lane. No fishing conditions or future report produced here; research close to delivery under its existing approval gates.

**Saturday 2026-11-28:** Award/community inventory unknown. Preserve any committed award/community placement. The optional prompt below is unusable until parent confirms no committed award and an open placement.

Caption links are not described as clickable. Any caption saying ‘through the website link in our profile’ is held until parent verifies the actual profile link offers a clear reachable route to that named page. Do not edit the profile without separate authorization.

## Destination release status

**`/start-here`:** Planned; not live until parent verifies actual public release. Hold W1-MON, W1-GBP-1 and W1-V1 as written. Do not imply this page exists or redirect silently. Required gate: G2.

**`/prepare-for-a-conversation`:** Planned; not live until parent verifies actual public release and printable ungated checklist behavior. Hold W1-WED, W1-LI-1 and W1-STORY as written. Any live-guide replacement requires separately reviewed exact copy, not an improvised link swap. Required gate: G2.

**`/what-to-expect`:** Planned; not live until parent verifies actual public release and team/process accuracy. Hold W1-SUN and W1-LI-2 as written. Required gate: G2.

**`/resources/car-insurance-quote-checklist-center-tx`:** Existing live guide per production brief, not a new page. Recheck exact public destination before activation. Hold W1-FRI, W1-GBP-2 and W1-V2 if the guide is unavailable or mismatched. Required gate: G3.

The exact captions below mention the planned pages for use only after release. They are finished candidate copy, not statements that those pages are live today. Hold the whole affected candidate rather than silently swapping a link or making a premature “now available” claim. The existing auto checklist is already live per the supplied brief and is not awaiting new-page production, but its exact destination still needs a near-activation recheck.

## Four independent acquisition topic pairs

### W1-MON — Choose the one renewal question you want answered first

**Proposed day:** Monday, 2026-11-23. **Time:** unassigned. **Destination path:** `/start-here`.

**Hook:** One question is a useful place to start.

#### Facebook — 140 words

> If your renewal is on your mind, what is the one question you would like to ask first?
>
> It might be, ‘Which part of this renewal should I look at first?’ Or, ‘What would you need from me to talk through this?’ You do not have to turn that first question into a polished explanation. Write it in your own words on a note you keep for yourself.
>
> When you contact Morrison Insurance, begin with the general topic and ask what information would be useful next. Keep policy numbers and document photos out of public comments. A first message is a starting point, not a request to post your paperwork.
>
> Our Start Here page helps you choose a starting route for your question: https://morrison-ins.net/start-here
>
> No need to share your renewal details here. Keep your question handy for a direct conversation.

#### Instagram — 78 words

> A renewal question does not need a polished introduction.
>
> Try writing one sentence for yourself: ‘Which part should I look at first?’ or ‘What would you need from me next?’ Keep it in your own words.
>
> Begin a direct conversation with the general topic, not a photo of your paperwork. Please leave policy numbers and personal details out of comments.
>
> Find Start Here through the website link in our profile, then choose the route that fits your question.

**Authentic visual brief:** Await an authorized authentic photo in the real Morrison office: staff hand writing only ‘One renewal question’ on a fresh blank note beside an empty cream tabletop. No customers, policy papers, computer screen or identifying text. Warm natural light, plain green/cream/amber accents, everyday clothing if a person is visible. Frame 4:5 for FB/IG with room for the short hook. No asset produced in this task.

**Exact optional overlay:** One renewal question

**Alt text candidate, verify after capture:** A hand writes ‘One renewal question’ on a blank note at a clear office table.

**Sources and scope:** [2], the supplied production brief. Question examples are original editorial prompts, not real customer quotes. No coverage or price claim. Start Here functionality is proposed and must pass G2.

**Required gates:** G1, G2, G3, G4, G5, G9, G10. **Privacy-safe response:** R1 below.

### W1-WED — Ask what information is needed next before sending paperwork

**Proposed day:** Wednesday, 2026-11-25. **Time:** unassigned. **Destination path:** `/prepare-for-a-conversation`.

**Hook:** Do I need to send all my paperwork first?

#### Facebook — 136 words

> Do you need to send every page of your renewal just to ask where to begin?
>
> Try a smaller first step: ‘I have an auto renewal question. What information would be useful for our conversation?’ That gives you a way to ask about preparation without putting your documents into a comment or social message.
>
> Before you make contact, jot down the part you want explained. If you already have paperwork, keep it with you and ask the team which pages they need and how they want you to share them. Do not assume a social inbox is the right place for policy or identity information.
>
> Our ungated preparation page offers a checklist you can use for your own notes: https://morrison-ins.net/prepare-for-a-conversation
>
> Start with the question. Let the actual conversation establish what comes next, including any documents needed.

#### Instagram — 81 words

> ‘What information would be useful for our conversation?’ is a practical first question.
>
> You can write down what you want explained before deciding what paperwork to share. Keep documents with you, and ask the team which pages they need and how to provide them. Please do not put policy or identity details into comments or social messages.
>
> For an ungated checklist, open Prepare for a Conversation through the website link in our profile. Preparation can begin with your own short note.

**Authentic visual brief:** Await an authorized real-office photo of an empty chair and a blank notepad with the single staff-written question ‘What would be useful next?’ No renewal packets, document piles, customer belongings or visible screens. Everyday, welcoming working space, not a staged carrier advertisement. Crop 4:5; preserve readable contrast. No claim of office hours or staff availability.

**Exact optional overlay:** Ask what is useful next

**Alt text candidate, verify after capture:** A blank notepad beside an empty office chair carries the question ‘What would be useful next?’

**Sources and scope:** the supplied production brief. Original editorial preparation suggestion, not a promise that quoting or policy review needs no documents. Checklist is not claimed live until G2 passes.

**Required gates:** G1, G2, G3, G4, G5, G9, G10. **Privacy-safe response:** R2 below.

### W1-FRI — Find the coverages, limits and deductibles before asking a comparison question

**Proposed day:** Friday, 2026-11-27. **Time:** unassigned. **Destination path:** `/resources/car-insurance-quote-checklist-center-tx`.

**Hook:** Where do I find the details I want explained?

#### Facebook — 140 words

> If you are looking at an auto renewal, where do you find the details you want explained?
>
> The Texas Department of Insurance says the declarations page summarizes your coverages, dollar limits and deductibles. That gives you a place to look for the wording behind your question, without trying to work through every page at once.
>
> Keep that page for your own reference. Pick one heading you would like explained and write down a question such as, ‘Can you help me understand this deductible?’ If you are comparing another quote, ask which details should be lined up before you compare the price.
>
> Our existing auto quote checklist is here: https://morrison-ins.net/resources/car-insurance-quote-checklist-center-tx
>
> Please do not post your declarations page or policy details. Ask the team how to share any needed information directly. A general explanation is not a decision about your particular coverage.

#### Instagram — 79 words

> Looking at an auto renewal? Start by finding the details behind your question.
>
> The Texas Department of Insurance says the declarations page summarizes coverages, dollar limits and deductibles. Keep it for your own reference and choose one heading you want explained.
>
> Try: ‘Can you help me understand this deductible?’ Do not post the page or policy details here. Ask how to share anything needed directly.
>
> Find our auto quote checklist in Resources through the website link in our profile.

**Authentic visual brief:** Await an authentic staff photo at the real office holding three plain cards staff has handwritten ‘Coverages’, ‘Limits’ and ‘Deductibles’. Cards are topic labels, not mock policies. Show no real or imitation declarations page, customer paperwork, names, numbers or screens. Keep everyday clothing and soft natural light. 4:5 crop; short question above cards if approved.

**Exact optional overlay:** Which heading needs explaining?

**Alt text candidate, verify after capture:** Staff-held cards read ‘Coverages’, ‘Limits’ and ‘Deductibles’ at a clear office table.

**Sources and scope:** [1], [2], the supplied production brief. The declarations-page sentence is supported by S1. Comparison and deductible questions are prompts, not matched-coverage or savings claims. Do not expand this sentence into an assertion that a declarations page contains every exclusion or proves coverage.

**Required gates:** G1, G3, G4, G5, G9, G10. **Privacy-safe response:** R3 below.

### W1-SUN — Ask who handles the next step and confirm timing in the real conversation

**Proposed day:** Sunday, 2026-11-29. **Time:** unassigned. **Destination path:** `/what-to-expect`.

**Hook:** How will I know what happens next?

#### Facebook — 138 words

> After asking your first renewal question, how will you know what happens next?
>
> Keep a second question ready: ‘What is the next step, and who should I speak with about it?’ You can also ask what information would be useful and when to check back. Confirm that timing during the actual conversation rather than assuming a social post describes today's availability.
>
> A helpful first message can be simple: ‘I would like to talk about a renewal. My question is where to begin.’ Keep specific policy details for the direct conversation and ask how any needed documents should be provided.
>
> Our What to Expect page explains the starting conversation and the privacy boundaries: https://morrison-ins.net/what-to-expect
>
> You do not need to put your whole situation in the comments. Save your question and use it when you are ready to make contact.

#### Instagram — 81 words

> One useful question to keep for the end of a first conversation: ‘What is the next step, and who should I speak with?’
>
> Ask what information is needed and when to check back. Confirm timing directly; this post is not an office-hours or response-time promise.
>
> Keep policy details and documents out of comments and social messages.
>
> Find What to Expect through the website link in our profile for a plain-language look at getting started. Save your question for the actual conversation.

**Authentic visual brief:** Await an authorized authentic Morrison staff photo at a cleared office table with a handwritten note containing only ‘Next step?’ and ‘When should I check back?’ No clock, schedule, calendar, customer, paperwork or implied staffed-on-Sunday message. Natural light; everyday office context. 4:5 crop. Capture date need not be the proposed posting day; do not imply it is.

**Exact optional overlay:** Ask about the next step

**Alt text candidate, verify after capture:** A note on a clear office table reads ‘Next step?’ and ‘When should I check back?’

**Sources and scope:** the supplied production brief. Original editorial handoff questions. No named staff, response time, licensed review, availability or policy outcome is asserted. What to Expect claims depend on G1 and G2 acceptance.

**Required gates:** G1, G2, G3, G4, G5, G9, G10. **Privacy-safe response:** R4 below.

## Two GBP Update candidates

Visible copy only is quoted below. Metadata and source notes are not part of the visible body. Both bodies are within 1,500 characters and contain no phone number, URL/domain or hashtag. No authentic photo exists yet. These are Updates, not Events or Offers.

### W1-GBP-1 — Start with one renewal question.

**Proposed day:** Monday, 2026-11-23. **Time:** unassigned. **Destination path:** `/start-here`.

**Type:** Update. **Visible body:** 710 characters, including whitespace.

> Have one renewal question you would like explained? Write it in your own words before deciding what paperwork to share.
>
> A useful starting question is, ‘What information would help us talk about this?’ Keep your note for yourself, then begin a direct conversation with the general topic. Ask the team which documents they need and how they want you to provide them.
>
> Please keep policy numbers, identity details and document photos out of public comments and social messages.
>
> Start Here offers a way to choose a starting route for a renewal or another insurance question. Confirm any next-step timing during the actual conversation. You do not need to tell your whole story in public to find a place to begin.

**Separate CTA metadata, not body text:** Learn more → `https://morrison-ins.net/start-here`. Separate supported button field only; never visible body text. Held until new-page release and individual button-only preview. A body-URL conversion workaround needs separate current approval and an individual unsaved full-preview gate; do not use an earlier exception.

**Authentic image brief:** Await a newly authorized authentic photo taken inside the real Morrison office of a staff hand and a blank note reading only ‘One question’. Use the actual cleared table and natural light; no user asset, stock photo, generated scene, customer, document, phone screen, schedule or personally identifying detail. Capture with staff permission; no face/name is required. Use the approved real photo only after checking what is actually in frame. No photo is produced or sourced here.

**Alt text candidate, verify after capture:** A hand rests beside a note reading ‘One question’ on a clear office table.

**Sources and scope:** [2], the supplied production brief. Original question-led preparation, not a coverage claim; proposed Start Here utility requires verified release.

**Required gates:** G1, G2, G4, G5, G6, G9, G10. **Privacy-safe response:** R1 below.

### W1-GBP-2 — Choose one auto renewal heading to ask about.

**Proposed day:** Friday, 2026-11-27. **Time:** unassigned. **Destination path:** `/resources/car-insurance-quote-checklist-center-tx`.

**Type:** Update. **Visible body:** 726 characters, including whitespace.

> Not sure which part of an auto renewal to ask about first?
>
> The Texas Department of Insurance says the declarations page summarizes your coverages, dollar limits and deductibles. Keep that page for your own reference and choose one heading you would like explained.
>
> You might ask, ‘What does this deductible mean?’ If you are also looking at a quote, ask which details to line up before comparing the price. These are starting questions, not conclusions about your coverage.
>
> Our auto quote checklist offers a place to organize your questions. Please do not post policy pages, policy numbers or identity details. Ask the team how to provide any documents needed for a direct conversation, and confirm the next step with them.

**Separate CTA metadata, not body text:** Learn more → `https://morrison-ins.net/resources/car-insurance-quote-checklist-center-tx`. Separate supported button field only; never visible body text. Held until existing-guide recheck and individual button-only preview. A body-URL conversion workaround needs separate current approval and an individual unsaved full-preview gate; do not use an earlier exception.

**Authentic image brief:** Await a newly authorized real Morrison-office photo of staff handwriting only ‘Coverages / Limits / Deductibles’ on a blank cream notepad. The note is a set of topic headings, not a mock declarations page. Clear all customer documents, computer displays, IDs and other identifying details from the shot. Natural everyday office setting; no stock/generated local substitute. Obtain staff permission and approve the actual photo before use. No photo is produced or sourced here.

**Alt text candidate, verify after capture:** A notepad on a clear office table lists ‘Coverages’, ‘Limits’ and ‘Deductibles’.

**Sources and scope:** [1], [2], the supplied production brief. S1 supports only the declarations-page summary sentence. Price comparison is framed as a question, with no savings or equivalent-coverage assertion.

**Required gates:** G1, G3, G4, G5, G6, G9, G10. **Privacy-safe response:** R3 below.

## Two LinkedIn manual-hold candidates

Manual copy only. No external drafts or schedules. The actual profile, established 50+ follower gate and separate current manual-post approval remain unchecked. A sufficient follower count alone is not authority.

### W1-LI-1 — A first question is different from a document submission.

**Proposed day:** Wednesday, 2026-11-25. **Time:** unassigned. **Destination path:** `/prepare-for-a-conversation`.

**Status:** Manual hold; no external draft or schedule. **Length:** 96 words.

> A useful first insurance conversation can begin with a preparation question: ‘What information would be helpful for us to talk about this renewal?’
>
> That question lets you ask about the process before deciding which documents to share. Keep policy and identity details out of public comments and social messages. Ask the team which pages they need and how they want to receive them.
>
> Morrison Insurance's ungated preparation page is a place to organize general questions for yourself: https://morrison-ins.net/prepare-for-a-conversation
>
> Preparation is not a coverage decision. Let the actual conversation establish what information and next steps are needed.

**Visual option:** Optional authentic office notepad photo from a separately approved capture; clean blank surface, no documents or people without consent. Copy can remain text-only if manually approved. No asset obtained here.

**Sources and scope:** the supplied production brief. Original editorial question/process suggestions, not coverage conclusions. Proposed page behavior needs release and agency acceptance.

**Required gates:** G1, G2, G3, G4, G5, G7, G9, G10. **Privacy-safe response:** R2 below.

### W1-LI-2 — Make the next step a question, not an assumption.

**Proposed day:** Sunday, 2026-11-29. **Time:** unassigned. **Destination path:** `/what-to-expect`.

**Status:** Manual hold; no external draft or schedule. **Length:** 100 words.

> When you finish an initial renewal conversation, consider asking: ‘What happens next, who should I speak with, and when should I check back?’
>
> Those questions make room to confirm the handoff directly. A social post cannot establish today's availability or promise a response time.
>
> Morrison Insurance's What to Expect page explains getting started and keeping personal information out of public channels: https://morrison-ins.net/what-to-expect
>
> A short first message can identify the general topic without attaching policy documents. Ask how any needed information should be provided. Keep your notes for the real conversation, where you can confirm the next step and its timing.

**Visual option:** Optional approved authentic photograph of an empty office chair and a note reading only ‘Next step?’ No Sunday-staffing implication, calendar, clock or customer material. Text-only is an acceptable manual variant if approved; no asset obtained here.

**Sources and scope:** the supplied production brief. Original editorial question/process suggestions, not coverage conclusions. Proposed page behavior needs release and agency acceptance.

**Required gates:** G1, G2, G3, G4, G5, G7, G9, G10. **Privacy-safe response:** R4 below.

## Two authentic-staff video scripts

These are verbatim scripts, not generated staff, completed footage or already-recorded testimonials. Use authentic consenting staff and clear all private material. Each replaces its matching topic placement; neither increases volume. No staff identity, title, licensed review or response-time claim has been invented.

### W1-V1 — One note, one starting question

**Proposed day:** Monday, 2026-11-23. **Time:** unassigned. **Destination path:** `/start-here`.

**Hook:** Bring one question, not a public paperwork photo.

**Placement:** Substitute for W1-MON FB/IG where approved; use the exact W1-MON channel caption. Not a second post. If only one channel approves video, that channel substitutes while the other may use the original approved visual.

**Duration:** 34-second target; required finished duration 25–40 seconds. 74 spoken words. The actual timed read remains pending.

#### Full verbatim spoken script

> Have a renewal question, but not sure where to begin? Write down the one thing you want explained. Your first question can be: ‘What information would be useful for our conversation?’ Keep policy numbers and document photos out of comments and social messages. Ask the team which information they need and how to provide it. Start Here offers a starting route for your question. Confirm the next step and timing during the actual conversation.

#### Precise shot and open-caption plan

**0–5 seconds:** Authentic consenting staff member, chest-up at the real cleared office table; look into camera. Plain everyday clothing; no names/titles on screen unless independently approved.

Verbatim speech and subtitle transcript for this shot:

> Have a renewal question, but not sure where to begin?

**Exact additional overlay:** One renewal question

**5–13 seconds:** Cut to the same staff hand writing only ‘One question’ on a blank note. Continue the same authentic recorded voice; do not show a filled policy or a customer example.

Verbatim speech and subtitle transcript for this shot:

> Write down the one thing you want explained. Your first question can be: ‘What information would be useful for our conversation?’

**13–25 seconds:** Return to staff chest-up. Table remains clear. No social inbox or private documents appear.

Verbatim speech and subtitle transcript for this shot:

> Keep policy numbers and document photos out of comments and social messages. Ask the team which information they need and how to provide it.

**25–34 seconds:** Stay with staff; end with a short natural pause. Do not suggest immediate availability. Only after destination release may the final lower-third name Start Here.

Verbatim speech and subtitle transcript for this shot:

> Start Here offers a starting route for your question. Confirm the next step and timing during the actual conversation.

**Exact additional overlay:** Start Here · Website link in profile

**Recording and caption specifications:** Vertical 9:16, 1080×1920 delivery if the approved format supports it. Phone/camera stationary at eye level, soft natural light, clear authentic staff voice. No generated staff, TTS, cloned voice, music or sourced assets. Burn in the exact spoken words as open captions, 1–2 short lines at a time inside safe margins; break lines for readability without deleting words. Time blocks are editing targets, not guaranteed speech speed: test the actual full read for 25–40 seconds before approving. For FB final lower-third use ‘Start Here · Link in this post’ instead; captions stay word-for-word identical to speech. For IG verify profile route. Do not record a screen walkthrough of an unreleased page.

**Sources and scope:** [2], the supplied production brief. Original general preparation guidance; proposed Start Here mention makes the whole as-written video release-dependent.

**Required gates:** G1, G2, G3, G4, G5, G8, G9, G10. **Privacy-safe response:** R1 below.

### W1-V2 — Three headings, one explanation question

**Proposed day:** Friday, 2026-11-27. **Time:** unassigned. **Destination path:** `/resources/car-insurance-quote-checklist-center-tx`.

**Hook:** Find the heading behind your question.

**Placement:** Substitute for W1-FRI FB/IG where approved; use the exact W1-FRI channel caption. Not an additional video placement.

**Duration:** 36-second target; required finished duration 25–40 seconds. 75 spoken words. The actual timed read remains pending.

#### Full verbatim spoken script

> Looking at an auto renewal? The Texas Department of Insurance says the declarations page summarizes your coverages, dollar limits and deductibles. Keep that page for your own reference. Choose one heading and ask, ‘Can you help me understand this?’ Please do not post your policy pages or personal details. Ask how to provide anything needed directly. Our auto quote checklist can help you organize questions. An explanation here is not a decision about your coverage.

#### Precise shot and open-caption plan

**0–10 seconds:** Authentic consenting staff member, chest-up in the real cleared office. Speak to camera; show no actual or imitation declarations page.

Verbatim speech and subtitle transcript for this shot:

> Looking at an auto renewal? The Texas Department of Insurance says the declarations page summarizes your coverages, dollar limits and deductibles.

**Exact additional overlay:** One heading to ask about

**10–18 seconds:** Cut to staff hand arranging three plain cards handwritten ‘Coverages’, ‘Limits’ and ‘Deductibles’. Keep authentic recorded voice. These are labels only, not fabricated customer or policy examples.

Verbatim speech and subtitle transcript for this shot:

> Keep that page for your own reference. Choose one heading and ask, ‘Can you help me understand this?’

**18–27 seconds:** Return to staff at the clear table, hands relaxed; no device displays, papers or customer material.

Verbatim speech and subtitle transcript for this shot:

> Please do not post your policy pages or personal details. Ask how to provide anything needed directly.

**27–36 seconds:** Stay with staff; finish naturally. Optional final lower-third only after the existing guide and profile route recheck.

Verbatim speech and subtitle transcript for this shot:

> Our auto quote checklist can help you organize questions. An explanation here is not a decision about your coverage.

**Exact additional overlay:** Auto quote checklist · Resources via profile link

**Recording and caption specifications:** Vertical 9:16, 1080×1920 if approved; camera stationary at eye level. Natural consenting staff voice only, no generated media/music or user assets. Exact spoken script is the open-caption transcript; show 1–2 readable lines at a time with safe margins and sufficient contrast. Test actual read and final cut for 25–40 seconds; shot ranges are a 36-second target, not a fabricated recording duration. FB lower-third variant: ‘Auto quote checklist · Link in this post’. No outcome claims or policy determinations. Final media needs separate review.

**Sources and scope:** [1], [2], the supplied production brief. S1 supports the exact declarations-page summary statement; no specific coverage, matched quote or savings claim.

**Required gates:** G1, G3, G4, G5, G8, G9, G10. **Privacy-safe response:** R3 below.

## Optional three-frame Story — substitute, not extra

**Proposed day:** Wednesday, 2026-11-25. **Time:** unassigned. **Destination path:** `/prepare-for-a-conversation`.

**Placement:** Replace one Wednesday IG acquisition feed placement, W1-WED, only after parent approves the substitution and checks capacity. Three frames form one sequence. Do not also run W1-WED on IG. No automatic FB cross-post; any separately approved FB Story must replace its own FB placement.

**Hook:** A question before a document.

### Frame 1 — 5 seconds

Exact on-screen copy:

> Renewal on your mind?
> Write one question for yourself.
> No policy details needed here.

**Visual plan:** Authentic authorized photo of a blank cream note on the real cleared office table; text overlay in warm green with high contrast. No user asset acquired.

**Alt text candidate:** A blank note on a clear office table under a prompt to write one renewal question.

### Frame 2 — 6 seconds

Exact on-screen copy:

> Try asking:
> ‘What information would be useful for our conversation?’
> Keep your paperwork private.

**Visual plan:** Second crop from an approved authentic capture showing staff hand beside the blank note, no private material. No poll, question sticker, document upload invitation or fabricated example.

**Alt text candidate:** A hand beside a blank note with a suggested preparation question.

### Frame 3 — 6 seconds

Exact on-screen copy:

> Prepare for a Conversation
> An ungated checklist for your own notes.
> Ask how to share any documents needed.

**Visual plan:** Approved authentic photo of the empty office tabletop; reserve a central area for an accessible link sticker. Do not show an unreleased checklist or invent its live behavior.

**Alt text candidate:** A clear office table beneath text introducing a preparation checklist.

**Separate sticker:** Preparation checklist → `https://morrison-ins.net/prepare-for-a-conversation`. Add only after G2 public release, checklist-behavior verification and sticker preview.

**Accessibility and privacy:** 9:16 layout; high-contrast readable text within Story safe margins. No audio required, no generated assets, no social question sticker that invites policy details. Keep all prompts general. Any replies use R2 or R6. Approve actual images, visible text and functioning sticker separately.

**Sources and scope:** the supplied production brief. Original editorial question/process suggestions, not coverage conclusions. Proposed page behavior needs release and agency acceptance.

**Required gates:** G1, G2, G3, G4, G5, G8, G9, G10. **Privacy-safe response:** R2 below.

## Saturday community prompt — conditional fallback only

**Proposed day:** Saturday, 2026-11-28. **Time:** unassigned. **Destination:** on-platform only; no website path.

**Status:** Unselected, conditional fallback only; no award inventory checked.

**Use only if:** Parent confirms no committed award placement and this is a genuinely open community slot after all current commitments and each channel's separate capacity are checked. If an award is committed, do not use this prompt or rewrite the award. No local event, business recommendation, partnership or holiday opening is asserted.

**Hook:** What is worth asking before you make a trip?

### Facebook — 136 words

> Before making a trip to a local business in Center or Shelby County, what general question is useful to ask first?
>
> ‘What should I have ready?’ can be a helpful place to start. Depending on the task, you might also ask whether an appointment is needed or which part of your question the business can help with. Confirm the details directly before you go; this post is not a statement about anyone's hours or availability.
>
> If you have a simple preparation question that could help a neighbor, you are welcome to share just the wording below. Please leave out names, addresses, account numbers, paperwork photos and private situations. No business tags are needed.
>
> For your own next errand, keep that one question somewhere handy. Asking what is useful first can make the conversation easier to begin.

### Instagram — 76 words

> Before a local errand in Center or Shelby County, what general question helps you get ready?
>
> Try: ‘What should I have ready?’ or ‘Do I need an appointment?’ Confirm details with the business itself; this is not an hours or availability notice.
>
> If you share a useful question below, share only the wording. Please leave out names, account details, addresses and paperwork photos. No business tags needed.
>
> Keep one practical question for your own next trip.

**Authentic visual brief:** Optional newly authorized authentic Morrison-office photo of a blank note reading only ‘What should I have ready?’ on a cleared table. No business logos/tags besides independently approved own-office context, customers, trip footage or implied community event. No asset accessed or produced here.

**Alt text candidate:** A note on a clear table asks ‘What should I have ready?’

**Sources and scope:** the supplied production brief. Timeless original editorial prompt; no local factual claim beyond the supplied geographic service context. Not tied to an asserted event or holiday opening.

**Required gates:** G1, G4, G5, G9, G10. **Privacy-safe response:** R5 below.

## Privacy-safe response templates

Use only after agency approval of the actual contact/moderation process. Do not solicit sensitive information through public comments, social DMs or an unverified general form. These templates do not authorize outreach or document handling; do not copy customer information into content or analytics records. “Verified website contact route” means the actual current route checked by the parent, not an unverified planned page.

### R1 — General renewal question in a public comment

> That is a useful starting question. Please keep policy numbers, document photos and personal details out of the comments. For a question about your own renewal, use Morrison's verified website contact route and ask what information the team needs next. No need to explain your whole situation here.

**Use gate:** Confirm the actual website contact route is reachable before replying. Do not solicit private documents by social DM.

### R2 — Reader asks what paperwork to send, including Story replies

> Please do not send policy pages or identity information through comments or social messages. Start with the general question using the verified website contact route, then ask the team which information they need and how to provide it. We cannot determine that from a public thread.

**Use gate:** Agency approves actual handling process; do not describe ordinary email, DM or a form as a secure document channel.

### R3 — Reader asks for a policy-specific explanation or offers a declarations-page photo

> The general guide can help you find the headings, but we cannot decide what your policy covers in a comment. Please do not post the page or any policy details. Use the verified website contact route to ask how the team can discuss your question and receive any information they need.

**Use gate:** Do not read or interpret personal policy detail in public; no guarantee of review or result.

### R4 — Availability, holiday-hours, response-time or next-step question

> Please confirm current availability and next-step timing directly through Morrison's verified website contact route. This post is not an office-hours or response-time notice. Keep policy and personal details out of this thread.

**Use gate:** No invented Thanksgiving/Sunday hours, closures, callbacks or response deadlines.

### R5 — Useful general community question

> Thank you for sharing the question. Please keep the discussion general and leave out private situations or account details. Anyone planning a visit should confirm preparation, appointments and current availability directly with the business.

**Use gate:** Do not endorse, tag or repeat a named customer/business relationship or private situation.

### R6 — A public comment or social message already contains private information

> For your privacy, please remove the personal or policy information from this comment or message if you can. We will not repeat it here. Use the verified website contact route to ask the team how to provide any needed information directly; please do not send more documents through social messages.

**Use gate:** Do not quote, screenshot, forward or copy private detail into this content bundle. Follow the agency's approved moderation procedure; no deletion, access or secure-channel guarantee is implied.

### R7 — Price, savings, coverage or claim-outcome request

> That depends on the details and cannot be established here. Please keep policy and personal information out of this thread. Use the verified website contact route to ask how to discuss your question directly. This post does not promise a price, savings, coverage or claim result.

**Use gate:** No public policy interpretation, quote, testimonial or case outcome.

### R8 — Reader reports a planned utility-page link is missing

> Thank you for flagging the link. Please use the contact route on Morrison's main website for a general starting question, and keep policy details and documents out of comments or social messages. We are checking the page; we are not asking you to upload paperwork here.

**Use gate:** Only say ‘we are checking’ after the agency actually accepts the check. Parent pauses linked materials, verifies the main website/contact route, and obtains approval for any correction; do not improvise a different CTA.

## Release, recheck and approval gates

### G1 — Exact-copy and service-process approval

**Current state:** Pending. Agency/parent approves these exact channel captions, reply templates and staff wording. Confirm first-contact wording matches real practice. No licensed review is claimed. Do not promise that a quote/review can be completed without documents; copy invites a general starting question and asks what is needed next.

### G2 — Separate new-page release

**Current state:** Pending; new pages not verified live. Parent independently verifies /start-here, /prepare-for-a-conversation and /what-to-expect on the actual public site and both public domains: correct route-specific content, raw crawler metadata/canonical, useful links, mobile/desktop and accessibility. For preparation page, confirm ungated printing and checkboxes without text entry, upload, personal data or localStorage. Push/preview/checkpoint and HTTP 200 alone are not release evidence. Linked captions remain held until their exact destination passes. Indexing is separate and never claimed here.

### G3 — Destination and profile-link recheck

**Current state:** Pending near activation. Recheck the existing auto checklist's exact live content and link; check all chosen destinations and mobile link behavior. For IG verify the real profile-link route reaches the named resource; caption URLs are not clickable CTAs. Do not change profile, site or tracking configuration under this handoff.

### G4 — Fresh capacity and preserved commitments

**Current state:** Not checked; parent owns. Before assigning any times or scheduling, parent inventories each proposed local day across channels, counts active, published, old-library and reserved placements separately, preserves Tuesday sports, Thursday fishing and committed awards/community content, and enforces max two/day separately for FB and IG and current applicable cross-network limits. Weekly 7–10/channel is inclusive of commitments. If full, defer or use an approved substitute; never stack or cancel existing material. No future sports/fishing/holiday facts are supplied here.

### G5 — Authentic media and privacy

**Current state:** No assets; awaiting authorized recording/photo. Use only authentic, separately approved Morrison staff/local photos or staff footage with consent and usage rights. Frame out customers, IDs, addresses, screens, calendars, policy/VIN/claim/payment details and real documents. No user assets accessed, AI staff, stock-as-local, customer stories or staged filled policy documents. Verify actual shot and alt text after capture. Record no staff name/title unless verified and approved.

### G6 — GBP Update and button-only preview

**Current state:** Pending. Use Update, not Offer/Event. Each visible body must remain <=1500 characters with no phone, URL/domain or hashtags. Keep ‘Learn more’ destination in a supported separate CTA field only after its page release and authentic photo approval. Individually inspect full body/button/media preview. If the tool only converts a pasted URL into a button, hold and seek explicit current approval for that named input-method test; do not inherit earlier permission or paste a URL into forbidden body input.

### G7 — LinkedIn manual hold

**Current state:** Manual hold. Copy only. Do not create a draft or schedule. Parent checks the actual profile and established 50+ follower gate, fresh applicable capacity, and current exact-copy/manual-post approval. Follower count alone is not publication authority.

### G8 — Recording and substitute approval

**Current state:** Scripts only. Authentic staff records each exact script; timed read and finished cut must be 25–40 seconds, with verbatim accurate subtitles, approved consent and no invented service timing. Approve finished media separately. Videos substitute Monday/Friday, and Story substitutes Wednesday IG; neither adds volume. If timing fails, adjust pauses or request a revised exact script approval, not an unreviewed ad-lib.

### G9 — Factual and date-sensitive recheck

**Current state:** Sources read 2026-11-16; activation recheck pending. Keep source support narrow and use official TDI pages for insurance facts. Original question prompts are editorial suggestions, not coverage conclusions or witnessed customer dialogue. Recheck any retained factual claim near activation. Do not publish fabricated local events, awards, outcomes, weather, fishing/sports data, Thanksgiving hours/closures or January trends. Confirm next-step timing in the actual conversation.

### G10 — Activation and independent readback

**Current state:** Not authorized or performed. Parent obtains separate approval for exact content, destinations, assets, channels and assigned times before external writes. Any authorized activation requires fresh provider readback of correct copy/media/destination/channel/date/time/timezone, no duplicates and counts. PENDING means scheduled, not published; verify accessible live output after provider publication. Never infer live release from a preview. No analytics/Ads/GTM/form configuration changes or lead claims based on clicks.

## Production checks and source scope

Passed 2026-11-16: all FB/IG/LinkedIn ranges, GBP character and prohibited-content checks, and verbatim script/subtitle continuity. Actual video duration awaits authentic recording.

Word counts use whitespace-separated tokens in the exact caption; a URL counts as one token. Source notes, hooks, overlays, visual briefs and gates are excluded. GBP counts include body whitespace. Source notes must stay outside GBP body. Video shot transcripts concatenate exactly to their respective full spoken scripts; actual pacing must be verified after authentic recording.

Authentic capture briefs only. No images, assets or finished footage exist in this task. Only official TDI pages were searched/read for insurance facts. No external social posts accessed or written. No agents delegated. Parent handles final capacity inventory, assigned times, page release/recheck, authentic media, exact approval, any authorized scheduling, preview and provider/live readback.

Only the declarations-page summary sentence is a material insurance fact in the publishable copy. TDI’s auto guide supports it in its “Deductibles and dollar limits” section.[1] TDI’s shopping checklist provides question-led background, not a guarantee that a first inquiry can produce a quote or policy review without paperwork.[2] The general shop-smart page was read as background; its pricing and discount suggestions are not used in these captions.[3] All example questions are original editorial prompts, not real customer dialogue. The source cb030.html is deliberately not used: it is a workers’ compensation guide, not a general small-business or COI guide.

## References

[1]: https://www.tdi.texas.gov/pubs/consumer/cb020.html "TDI Automobile insurance guide"
[2]: https://www.tdi.texas.gov/consumer/auto-insurance-shopping-guide.html "TDI How to shop smart for auto insurance"
[3]: https://www.tdi.texas.gov/tips/shop-smart.html "TDI How to shop smart for insurance"

Official pages above were read directly November 16, 2026; retained claims require the near-activation recheck in G9. The general shop-smart page displays an October 6, 2025 update date.

Internal supplied production brief: `/home/ubuntu/research/acquisition-build-2026-11-16/production-brief.md`. It establishes the brand/context and existing-guide status, not public-release evidence for new pages or independent confirmation of individual policy coverage.

