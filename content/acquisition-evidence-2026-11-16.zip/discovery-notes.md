# Discovery notes — 2026-11-16

Read-only, bounded public search sample, not a geo-controlled Google/local-pack rank audit.

Intent 1 query: `insurance agency Center TX`. Results included Morrison's Progressive carrier-directory profile, M & M, Masterson/Germania, John Burns/Farmers, Sandy Cox/State Farm, Shoop, and Chris Mayfield/State Farm. Morrison's own website did not appear in the returned sample. Do not convert this to an exact rank or absence from all search results.

Intent 2 query: `independent auto insurance Center Texas`. Returned mostly statewide/unrelated independent agencies and Texas Department of Insurance; no Center local agency in this returned sample. Query ambiguity around the word Center may affect this sample; one local-order variant will be checked before selecting the two competitor sources.

URLs discovered:
- https://www.progressiveagent.com/local-agent/texas/center/morrison-insurance-agency-llc-75935/
- https://mm-ins.com/
- https://www.shoopins.com/
- https://sandycoxinsurance.com/
- https://cmayfield.com/

Internal direction read: /home/ubuntu/projects/morrison-insurance-a17cb1d7/website-content-design-direction.md. It prioritizes local human paths, one useful verified question at a time, independent choice explained without rate/coverage guarantees, and qualified inquiries rather than content volume.

Second-intent variant `Center TX independent auto insurance` returned Morrison's Progressive directory, Sandy Cox, John Burns, Chris Mayfield, Tomlin Facebook and Shoop's Travelers local listing. Selected only two recurring competitor homepage sources: Shoop, which appeared as homepage on first intent and a Travelers Center listing on second variant; Sandy Cox, recurring in both locally resolved intent samples.

Opened source https://www.progressiveagent.com/local-agent/texas/center/morrison-insurance-agency-llc-75935/ in browser. CAPTCHA reported but extracted page text available: address 125 Shelbyville St, Center TX; phone 936-598-2791; website https://morrison-ins.net/; directory hours 8:30–4:00 weekdays. Treat directory hours as source claims, not confirmed agency operating hours.

Shoop homepage source https://www.shoopins.com/: separate Auto/Home/Commercial/Recreational quote entry points, staff shopping among many carriers, visible carrier-logo names, and email/call/appointment options. Articles highlighted workers' comp and earthquake damage. Testimonial is credited to `Example Client`, not credible specific proof. No claim these are effective or accurate; acquisition clarity can be compared without endorsing guarantee-like wording.

Sandy Cox homepage source https://sandycoxinsurance.com/: address 621 Tenaha St, Center; landmark directions; review link displaying 4.9/5 from 65 Google reviews; product-specific quote selector; items-needed-for-quote label; separate claim/payment/ID-card routes; named staff and license numbers; English/Spanish listed. The 24-hour contact claim is competitor wording, not a verified service standard or a proposed Morrison promise.

Morrison homepage https://morrison-ins.net/ read via browser and fetch: title `Morrison Insurance | Center, TX Since 1923`; local street-scene hero, visible century/independent/local team positioning; source describes three generations, office at 125 Shelbyville, independent comparison process, attributed testimonials naming staff, and 2026 Light and Champion local reader-choice awards. Awards and testimonials are onsite proof claims, not independently verified outcomes. Carrier image alt labels on fetch include Allstate, Foremost, Liberty Mutual, Progressive and Travelers. Do not claim missing carrier logos or missing people. Several repeating trust/process sections and free-app choices.

Morrison auto page https://morrison-ins.net/auto-insurance browser title `Car Insurance in Center, TX | Morrison Insurance`. Explicit Center heading and Shelby County service area; rural commutes, personal/work-use trucks, farm/ranch use, teens, deer and recreational vehicles. Coverage types, deductible choice, common gaps, multiple-carrier comparison, five-step process, quote/local-agent/coverage-review links all lead to /contact; related quote-prep and independent-agent guides linked. Generic auto/recreational mix may blur separate policies, though FAQ explicitly asks whether auto covers boat/ATV. On extracted text, several categorical phrases need internal review rather than endorsement: `comprehensive coverage pays for the damage`, `comprehensive coverage handles it`, `We'll make sure nothing falls through the cracks`, and `We review your policy regularly`. Need inspect live FAQ before calling comparison guidance absent.
