Five-school sports — November 16–22, 2026

Produced for review; not scheduled.
Order: Tenaha, Timpson, Shelbyville, Center, Joaquin.
Timpson display: 5:00 without AM/PM, team-confirmed.

Five 1080 × 1350 JPEGs plus self-contained editable HTML. Original HTML-rendered artwork, not editable Canva templates. Full channel copy, source notes, media/alt mapping and capacity snapshot included.

Recommended November 17: Facebook noon; Instagram 12:15 PM Central. Refresh time/capacity before activation. No existing posts, GBP, LinkedIn, website, Ads, email or recurring workflow changed.
