Five-school sports — November16–22,2026

ACTIVELY SCHEDULED, not yet published at12:04:59PM readback.
Facebook November17 at12:10PM CST, ID431825601.
Instagram November17 at12:15PM CST, ID431825642.

Order: Tenaha, Timpson, Shelbyville, Center, Joaquin. Timpson display5:00 withoutAM/PM. Five1080x1350JPEGs and editableHTML, originalHTMLcards not Canva edits. Exactfullcopy, media/altmapping, capacity and currentreceipt included.

Readback confirms both nondraft/autoPublishtrue, providerPENDING, InstagramAI disclosure. Today2/2each; six actualweeklyeach plus separate source-gatedfishingreservation oneeach. Existingposts,GBP,LinkedIn,website,Ads,tracking,email and recurringworkflows unchanged.
