Five-school sports carousel — November 10, 2026

Order: 01 Joaquin, 02 Tenaha, 03 Timpson, 04 Shelbyville, 05 Center.
Five JPEGs are exactly 1080x1350. HTML source is editable but is not a Canva design.
Timpson uses only JV vs Gary at 6PM; conflicting varsity information is excluded.
Facebook scheduled noon CST, Instagram12:15PM CST; both were providerPENDING at9:58AM.
See the attached Markdown receipt and JSON planner record for exact media, captions, dates and source links.
